//
//  MasterViewTableCell.h
//  Cell Leaders Mobile
//
//  Created by ehiss on 3/28/13.
//
//

#import <UIKit/UIKit.h>

@interface MasterViewTableCell : UITableViewCell{
    
    
}

@property (nonatomic, weak) IBOutlet UILabel *nameLabel;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage2;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage3;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage4;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage5;
@property (nonatomic, weak) IBOutlet UIImageView *memberImage;

@end
