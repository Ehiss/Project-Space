//
//  AddNewMemberViewController.h
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/1/13.
//
//

#import <UIKit/UIKit.h>
//#import "CSCommentPageViewController.h"
#import "ValueSelectionViewController.h"

@protocol SubmissionCompleteDelegate

-(void)submissionCompleted:(NSNumber*)theCountry theUserFirstname:(NSString*)theFirstname theUserLastname:(NSString*)theLastname;


-(void)addRecordToTable:(NSString*)theFirstname theUserLastname:(NSString*)theLastname theUserTitle:(NSString*)theTitle;

-(void)activateTheIndicator;

-(void)deActivateTheIndicator;

@end


@interface AddNewMemberViewController : UIViewController<UIPopoverControllerDelegate, CountryUpdaterDelegate, NSURLConnectionDelegate, UIAlertViewDelegate>{
    
    
    id <SubmissionCompleteDelegate> delegate;
    
    __weak IBOutlet UIButton *bornagainButton;
    __weak IBOutlet UIButton *statusButton;
    __weak IBOutlet UIButton *genderButton;
    __weak IBOutlet UIButton *yearButton;
    //__weak IBOutlet UIButton *monthButton;
   // __weak IBOutlet UIButton *dayButton;
    __weak IBOutlet UITextField *firstName;
    
    __weak IBOutlet UITextField *midleName;
    __weak IBOutlet UITextField *lastName;
    
    __weak IBOutlet UILabel *country;
    __weak IBOutlet UILabel *gender;
    __weak IBOutlet UILabel *theTitle;
   // __weak IBOutlet UILabel *birthDay;
    
    __weak IBOutlet UILabel *bornAgainStatus;
    __weak IBOutlet UITextField *followUpLabel;
    __weak IBOutlet UITextField *emailField;
   // __weak IBOutlet UILabel *birthMonth;
    
    NSString *theValue;
    NSMutableData *webData;
     NSString *encodedusername;
     NSString *theEntityValue;
    NSString *theentityname;
    int theURLRequestChecker;
    NSMutableDictionary *theTitleAndObject;
    NSMutableDictionary *theCountryAndObject;
    NSMutableArray *theTitlesArray;
    NSMutableArray *theGenderArray;
    NSMutableArray *theCountryArray;
    NSArray* entitySpecification;
    NSNumber *theEntityID;
    
    BOOL theError;
}

@property (nonatomic, retain) UIPopoverController *popoverController2;
@property (retain) id delegate;

-(IBAction)selectorDependencies:(id)sender;

- (void)initForCreate;

- (void)interpreteTheData:(NSMutableData*)theData;

- (void)interpretePostData:(NSMutableData*)theData;

-(void) clearTheFields;

@end
