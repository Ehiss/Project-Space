//
//  LoginViewController.m
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/5/13.
//
//

#import "LoginViewController.h"

#import <Availability.h>

#import <CommonCrypto/CommonHMAC.h>
//#import "Base64.h"

@interface LoginViewController ()

@end

/**static char base64EncodingTable[64] = {
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
    'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
    'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
    'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
};**/

@implementation LoginViewController

/**-(NSData *)base64DataFromString: (NSString *)string
{
    unsigned long ixtext, lentext;
    unsigned char ch, inbuf[4], outbuf[3];
    short i, ixinbuf;
    Boolean flignore, flendtext = false;
    const unsigned char *tempcstring;
    NSMutableData *theData;
    
    if (string == nil)
    {
        return [NSData data];
    }
    
    ixtext = 0;
    
    tempcstring = (const unsigned char *)[string UTF8String];
    
    lentext = [string length];
    
    theData = [NSMutableData dataWithCapacity: lentext];
    
    ixinbuf = 0;
    
    while (true)
    {
        if (ixtext >= lentext)
        {
            break;
        }
        
        ch = tempcstring [ixtext++];
        
        flignore = false;
        
        if ((ch >= 'A') && (ch <= 'Z'))
        {
            ch = ch - 'A';
        }
        else if ((ch >= 'a') && (ch <= 'z'))
        {
            ch = ch - 'a' + 26;
        }
        else if ((ch >= '0') && (ch <= '9'))
        {
            ch = ch - '0' + 52;
        }
        else if (ch == '+')
        {
            ch = 62;
        }
        else if (ch == '=')
        {
            flendtext = true;
        }
        else if (ch == '/')
        {
            ch = 63;
        }
        else
        {
            flignore = true;
        }
        
        if (!flignore)
        {
            short ctcharsinbuf = 3;
            Boolean flbreak = false;
            
            if (flendtext)
            {
                if (ixinbuf == 0)
                {
                    break;
                }
                
                if ((ixinbuf == 1) || (ixinbuf == 2))
                {
                    ctcharsinbuf = 1;
                }
                else
                {
                    ctcharsinbuf = 2;
                }
                
                ixinbuf = 3;
                
                flbreak = true;
            }
            
            inbuf [ixinbuf++] = ch;
            
            if (ixinbuf == 4)
            {
                ixinbuf = 0;
                
                outbuf[0] = (inbuf[0] << 2) | ((inbuf[1] & 0x30) >> 4);
                outbuf[1] = ((inbuf[1] & 0x0F) << 4) | ((inbuf[2] & 0x3C) >> 2);
                outbuf[2] = ((inbuf[2] & 0x03) << 6) | (inbuf[3] & 0x3F);
                
                for (i = 0; i < ctcharsinbuf; i++)
                {
                    [theData appendBytes: &outbuf[i] length: 1];
                }
            }
            
            if (flbreak)
            {
                break;
            }
        }
    }
    
    return theData;
}**/


/**- (NSString *) base64StringFromData: (NSData *)data length: (int)length {
    unsigned long ixtext, lentext;
    long ctremaining;
    unsigned char input[3], output[4];
    short i, charsonline = 0, ctcopy;
    const unsigned char *raw;
    NSMutableString *result;
    
    lentext = [data length];
    if (lentext < 1)
        return @"";
    result = [NSMutableString stringWithCapacity: lentext];
    raw = [data bytes];
    ixtext = 0;
    
    while (true) {
        ctremaining = lentext - ixtext;
        if (ctremaining <= 0)
            break;
        for (i = 0; i < 3; i++) {
            unsigned long ix = ixtext + i;
            if (ix < lentext)
                input[i] = raw[ix];
            else
                input[i] = 0;
        }
        output[0] = (input[0] & 0xFC) >> 2;
        output[1] = ((input[0] & 0x03) << 4) | ((input[1] & 0xF0) >> 4);
        output[2] = ((input[1] & 0x0F) << 2) | ((input[2] & 0xC0) >> 6);
        output[3] = input[2] & 0x3F;
        ctcopy = 4;
        switch (ctremaining) {
            case 1:
                ctcopy = 2;
                break;
            case 2:
                ctcopy = 3;
                break;
        }
        
        for (i = 0; i < ctcopy; i++)
            [result appendString: [NSString stringWithFormat: @"%c", base64EncodingTable[output[i]]]];
        
        for (i = ctcopy; i < 4; i++)
            [result appendString: @"="];
        
        ixtext += 3;
        charsonline += 4;
        
        if ((length > 0) && (charsonline >= length))
            charsonline = 0;
    }     
    return result;
}**/

+ (NSString*)base64forData:(NSData*)theData {
    const uint8_t* input = (const uint8_t*)[theData bytes];
    NSInteger length = [theData length];
    
    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    
    NSMutableData* data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t* output = (uint8_t*)data.mutableBytes;
    
    NSInteger i;
    for (i=0; i < length; i += 3) {
        NSInteger value = 0;
        NSInteger j;
        for (j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger theIndex = (i / 3) * 4;
        output[theIndex + 0] = table[(value >> 18) & 0x3F];
        output[theIndex + 1] = table[(value >> 12) & 0x3F];
        output[theIndex + 2] = (i + 1) < length ? table[(value >> 6) & 0x3F] : '=';
        output[theIndex + 3] = (i + 2) < length ? table[(value >> 0) & 0x3F] : '=';
    }
    
    return [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
}


+ (NSString *)base64String:(NSString *)str
{
    NSData *theData = [str dataUsingEncoding: NSASCIIStringEncoding];
    const uint8_t* input = (const uint8_t*)[theData bytes];
    NSInteger length = [theData length];
    
    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    
    NSMutableData* data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t* output = (uint8_t*)data.mutableBytes;
    
    NSInteger i;
    for (i=0; i < length; i += 3) {
        NSInteger value = 0;
        NSInteger j;
        for (j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger theIndex = (i / 3) * 4;
        output[theIndex + 0] =                    table[(value >> 18) & 0x3F];
        output[theIndex + 1] =                    table[(value >> 12) & 0x3F];
        output[theIndex + 2] = (i + 1) < length ? table[(value >> 6)  & 0x3F] : '=';
        output[theIndex + 3] = (i + 2) < length ? table[(value >> 0)  & 0x3F] : '=';
    }
    
    return [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
}

-(void)theConnectionFunction:(NSString *)theConnectionUrlValue{
    
    @try{
        [passwordField resignFirstResponder];
        [theLoginIndicator startAnimating];
        
        NSLog(@"authorisation value is %@", theConnectionUrlValue);
        // In body data for the 'application/x-www-form-urlencoded' content type,
        // form fields are separated by an ampersand. Note the absence of a
        // leading ampersand.
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=Login", theConnectionUrlValue];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://162.242.238.123/portal/"]];
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://166.78.9.139/portal/"]];
        
        //local
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.101:8000/portal/"]];
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
    
    NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
    
    if(conn) {
        
        webData = [NSMutableData data] ;
    }
    
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    
    
    
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    
    [webData appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    //NSLog(@"ERROR with theConnection");
   // NSLog(@"%@", error);
    
    NSString *title = @"There is an issue connecting to the internet at this time, please try again. Thank You";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];
    
     [theLoginIndicator stopAnimating];
}

-(void)connectionDidFinishLoading:(NSURLConnection *) connection{
    [theLoginIndicator stopAnimating];
    NSString *theValue;
    NSString *theReportValue;
    
    NSLog(@"DONE, recieved Bytes: %d", [webData length]);
    NSString *theXML = [[NSString alloc] initWithBytes:[webData mutableBytes] length:[webData length] encoding:NSUTF8StringEncoding];
    NSLog(@"this is the feed back: %@", theXML);
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:webData options:kNilOptions error:nil];
    
    NSString* statusValue = [json objectForKey:@"result"];
    NSString* falseValue = [json objectForKey:@"fault"];
    NSString* username = [json objectForKey:@"user_name"];
    NSNumber* theUserId = [json objectForKey:@"userId"];
    
    //NSLog(@"this is the user id %@", theUserId);
    
     NSArray* latestLoans = [json objectForKey:@"screens"];
    NSArray* theRoles = [json objectForKey:@"roles"];
    
    for(NSDictionary* entityOptions in latestLoans){
        
        NSString *theStringEntity = [entityOptions objectForKey:@"label"];
        NSString *entityLink = [entityOptions objectForKey:@"link"];
        
        if([theStringEntity isEqualToString:@"Cell Reports"] || [theStringEntity isEqualToString:@"Weekly Cell Reports"] ){
            
            theReportValue = entityLink;
            NSLog(@"the report value entity is %@", theReportValue);
        }
        else
            if([theStringEntity isEqualToString:@"Cell Members"] || [theStringEntity isEqualToString:@"Members"]){
                
                theValue = entityLink;
                
            }
    }
    
   //cellMemberScreen = [latestLoans objectAtIndex:1];
    //cellReportScreen = [latestLoans objectAtIndex:0];
    
    //NSString *theValue =[cellMemberScreen objectForKey:@"link"];
    //NSString *theReportValue =[cellReportScreen objectForKey:@"link"];
    
    
    NSLog(@"this is the screen value %@", theValue);
    
     NSLog(@"this is the username value %@", username);
    
    if ([statusValue isEqualToString:@"true"]) {
        
        theLoginMarker = 1;
        //NSLog(@"login is successfull");
        
        [[NSUserDefaults standardUserDefaults] setValue:username forKey: @"username"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[NSUserDefaults standardUserDefaults] setValue:theValue forKey: @"screenentity"];
        [[NSUserDefaults standardUserDefaults] synchronize];

        [[NSUserDefaults standardUserDefaults] setValue:theReportValue forKey: @"reportscreenentity"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[NSUserDefaults standardUserDefaults] setInteger:theLoginMarker forKey: @"loginindicator"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[NSUserDefaults standardUserDefaults] setInteger:theLoginMarker forKey: @"loginindicator_master"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[NSUserDefaults standardUserDefaults] setValue:theUserId forKey: @"theuserid"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        if([theRoles count] == 1){
            
        [[NSUserDefaults standardUserDefaults] setValue:[theRoles objectAtIndex:0] forKey: @"mainrole"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        }
        else{
        [[NSUserDefaults standardUserDefaults] setValue:[theRoles objectAtIndex:0] forKey: @"mainrole"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [[NSUserDefaults standardUserDefaults] setValue:[theRoles objectAtIndex:1] forKey: @"subrole"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        }
        
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    }
    else
    {
        NSString *title = falseValue;
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Please try again" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
    }
    
    
}

-(IBAction)performLogin:(id)sender{
    
    theUserName = nameField.text;
   thePassword = passwordField.text;
    
NSString *theStringToSend = [[theUserName stringByAppendingString:@":"] stringByAppendingString:thePassword];
    //NSString *theStringToSend = @"sysadmin:mashal81";
    //NSString *encodedString = [NSData base64EncodedString];
    
    NSLog(@"this is the concated string %@", theStringToSend);
    
    
    /**NSString* key = @"dodo";
    NSString* data = theStringToSend;
    
    const char *cKey = [key cStringUsingEncoding:NSASCIIStringEncoding];
    const char *cData = [data cStringUsingEncoding:NSASCIIStringEncoding];
    unsigned char cHMAC[CC_SHA256_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA256, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    NSData *hash = [[NSData alloc] initWithBytes:cHMAC length:sizeof(cHMAC)];
    
    NSLog(@"hash value is %@", hash);**/
    
    NSString* theEncodedString = [LoginViewController base64String:theStringToSend];
    NSLog(@"the string value is %@",theEncodedString);
    
   // NSString *theURLString = [NSString stringWithFormat:@"http://166.78.9.139:80/auth/", theEncodedString];
    
   // [self insertIntoDataBase];
    
    [[NSUserDefaults standardUserDefaults] setValue:theEncodedString forKey: @"encodedlogindetails"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self theConnectionFunction:theEncodedString];
    
    
    //[self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

-(void)createDataBase{
    
    NSString *docsDir;
    NSArray *dirPaths;
    
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    docsDir = dirPaths[0];
    
    // Build the path to the database file
    _databasePath = [[NSString alloc]
                     initWithString: [docsDir stringByAppendingPathComponent:
                                      @"contacts.db"]];
    
    NSFileManager *filemgr = [NSFileManager defaultManager];
    
    if ([filemgr fileExistsAtPath: _databasePath ] == NO)
    {
        const char *dbpath = [_databasePath UTF8String];
        
        if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK)
        {
            char *errMsg;
            const char *sql_stmt =
            "CREATE TABLE IF NOT EXISTS CONTACTS (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)";
            
            if (sqlite3_exec(_contactDB, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK)
            {
                NSLog(@"Failed to create table") ;
            }
            else{
                NSLog(@"Database has been correctly reated");
            }
            sqlite3_close(_contactDB);
        }
        else {
            
            NSLog(@"Failed to open/create database") ;
           
        }
    }
}
-(void)insertIntoDataBase{
   
    sqlite3_stmt    *statement;
    const char *dbpath = [_databasePath UTF8String];
    
    if (sqlite3_open(dbpath, &_contactDB) == SQLITE_OK)
    {
        
        NSString *insertSQL = [NSString stringWithFormat:
                               @"INSERT INTO CONTACTS (username, password) VALUES (\"%@\", \"%@\")",
                               theUserName, thePassword];
        
        const char *insert_stmt = [insertSQL UTF8String];
        sqlite3_prepare_v2(_contactDB, insert_stmt,
                           -1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE)
        {
            NSLog(@"values have been entered correctly");
        } else {
             NSLog(@"values could not be entered correctly");
        }
        sqlite3_finalize(statement);
        sqlite3_close(_contactDB);
    }
    
}

- (void)viewDidLoad
{
    animationMarker = 0;
    self.navigationController.navigationBarHidden = YES;
    
    [self getFrameForRotation];
    
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
	[[NSNotificationCenter defaultCenter]
	 addObserver:self selector:@selector(orientationChange:) name:@"UIDeviceOrientationDidChangeNotification" object:nil];

    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)orientationChange:(NSNotification *)object{
	UIDeviceOrientation deviceOrientation = [[object object] orientation];
	//if ([rotationSwitch isEqualToString:@"ON"]){
    
    if (deviceOrientation == UIInterfaceOrientationPortrait || deviceOrientation == UIInterfaceOrientationPortraitUpsideDown) {
        
        orientationCheck = @"potrait";
        
        theLogoViewLogo.center = CGPointMake(384, 280);
    }
    else
        if(deviceOrientation == UIInterfaceOrientationLandscapeLeft || deviceOrientation == UIInterfaceOrientationLandscapeRight)
        {
           orientationCheck = @"landscape";
            
            theLogoViewLogo.center = CGPointMake(494, 130);
            
        }
    
	//}
	
	
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)animateTheTextFieldForEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    //animationMarker = 1;
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                     animations:^{
                         
                        theLoginView.center = CGPointMake(516, 236);
                         
                     }
                     completion:^(BOOL finished){
                         NSLog(@"Move to left done");
                     }];
    

    
}

- (void)animateReturnofTheTextFieldAfterEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    //animationMarker = 0;
    
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                     animations:^{
                         if([orientationCheck isEqualToString:@"landscape"]){
                        theLoginView.center = CGPointMake(516, 376);
                         }
                         
                         else
                             if([orientationCheck isEqualToString:@"potrait"]){
                                 
                                theLoginView.center = CGPointMake(386, 505);
                             }
                         
                     }
                     completion:^(BOOL finished){
                         NSLog(@"Move to left done");
                     }];
    

    
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    
    if([orientationCheck isEqualToString:@"landscape"] && animationMarker == 0){
        [self animateTheTextFieldForEditing:nil finished:nil context:nil];
        animationMarker = 1;
    }
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
   
    if(/**[orientationCheck isEqualToString:@"landscape"] &&**/ textField.tag == 2){
        
        [self animateReturnofTheTextFieldAfterEditing:nil finished:nil context:nil];
        animationMarker = 0;
    }
    
}

- (void)getFrameForRotation
{
    if (self.interfaceOrientation == UIInterfaceOrientationPortrait || self.interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) {

		orientationCheck = @"potrait";
        theLogoViewLogo.center = CGPointMake(494, 230);
        
		
		
    }
	else
		if(self.interfaceOrientation == UIInterfaceOrientationLandscapeLeft || self.interfaceOrientation == UIInterfaceOrientationLandscapeRight)
		{
			
            orientationCheck = @"landscape";
			theLogoViewLogo.center = CGPointMake(494, 130);
            
		}
	
	
}



@end
