//
//  MasterViewController.m
//  Cell Leaders Mobile
//
//  Created by imm(content 2 mobile) on 3/22/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "MasterViewController.h"

//#import "DetailViewController.h"

@implementation MasterViewController

//@synthesize detailViewController = _detailViewController;
@synthesize theDetailTable, mcellMembersNameArray;

-(IBAction)editTable:(id)sender{
    
    NSString *theValue = [[sender titleLabel] text];
    
    if([theValue isEqualToString:@"prev"]){
        
        if(thePageValue < 1 || thePageValue == 1){
            
            NSString *title = @"You are currently on the first page, please select the next button to proceed to the next page. Thank You";
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            
            [alert show];
            
        }
        
        else{
            
            thePageValue-=10 ;
            
            NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
            
            [self retrieveCellMembers:thePageSizeValue theCounerValue:thecounter];
            
            [[NSUserDefaults standardUserDefaults] setInteger:thePageValue forKey: @"thesetpagevalue_master"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
        }

        
        
    }
    else
        if([theValue isEqualToString:@"next"]){
            
            thePageValue+=10 ;
            
            NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
            
            [self retrieveCellMembers:thePageSizeValue theCounerValue:thecounter];
            
            [[NSUserDefaults standardUserDefaults] setInteger:thePageValue forKey: @"thesetpagevalue_master"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
        }
    
}

-(IBAction)refreshTable:(id)sender{
    
    NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
    
    [self retrieveCellMembers:thePageSizeValue theCounerValue:thecounter];
    
    /**NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmembernames.txt"];
     mcellMembersNameArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName];
    
    
    [theDetailTable reloadData];**/
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"", @"Master");
    
        self.contentSizeForViewInPopover = CGSizeMake(350.0, 800.0);
    }
    return self;
}
							
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    thePageSizeValue = @"10";
    thePageValue = [[NSUserDefaults standardUserDefaults] integerForKey: @"thesetpagevalue_master"];
    
    if(thePageValue == 0){
        thePageValue = 1;
        
    }

    
    
    self.navigationController.navigationBarHidden = YES;
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
   // [self.tableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionMiddle];
}


-(void)retrieveCellMembers:(NSString*)pageSize theCounerValue:(NSString*)conter{
    
    
    NSError* error;
    theURLRequestChecker_master = 1;
    
    [theDetailIndicator startAnimating];
    
    @try{
        
        //NSArray *entitySpecValue = [[NSArray alloc] initWithObjects:@"first_name", @"last_name",@"title", nil];
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:pageSize,
                              @"pageSize", conter,@"firstCount", @"id", @"sortField", @"desc", @"sort", nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=read&content=%@", encodedusername_master, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123:80/%@/read/", theEntityValue_master]]];
        
        
        //local
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.101:8000/%@/read/", theEntityValue_master]]];
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData_master = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    
    
    
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData_master setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    
    [webData_master appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    NSLog(@"ERROR with theConnection");
    NSLog(@"%@", error);
    
    NSString *title = @"There is an issue connecting to the internet at this time, please try again. Thank You";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];
    
    [theDetailIndicator stopAnimating];
}

-(void)connectionDidFinishLoading:(NSURLConnection *) connection{
    
    NSLog(@"DONE, recieved Bytes: %d", [webData_master length]);
    
    [theDetailIndicator stopAnimating];
    
    if (theURLRequestChecker_master == 1) {
        [self interpreteTheReadCellMembers:webData_master];
    }
    
    /**if (theURLRequestChecker == 3) {
        [self interpreteTheReadData:webData];
    }
    
    if (theURLRequestChecker == 4) {
        [self interpreteCellReportReadData:webData];
    }
    
    if (theURLRequestChecker == 5) {
        
        [self interpreteDetailCellReportRead:webData];
    }
    
    if (theURLRequestChecker == 6) {
        
        [self interpreteUpdatedCellReport:webData];
    }**/
    
    
    
}

- (void)interpreteTheReadCellMembers:(NSMutableData*)theData{
   
    mcellMembersNameArray = [[NSMutableArray alloc] init];
    mcellMembersIdArray = [[NSMutableArray alloc] init];
    
    NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmembernames_master.txt"];
    
    NSString *fileName2 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmemberid_master.txt"];
    
    NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    
    NSLog(@"this is the read feed back: %@", theXML);
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    NSArray *cellMembersQuerry = [json objectForKey:@"resultSet"];
    
    NSString *resultValue = [json objectForKey:@"result"];
    
    if ([resultValue isEqualToString:@"true"]){
        
        for(NSDictionary* cellrecord in cellMembersQuerry){
            
            NSString *theTitle = [cellrecord objectForKey:@"title"];
            
            NSString *theName = [cellrecord objectForKey:@"name"];
            
            NSString *theId = [cellrecord objectForKey:@"id"];
            
            NSString * theCombinedRecord = [theTitle stringByAppendingString:[NSString stringWithFormat:@" %@", theName]];
            
            [mcellMembersNameArray addObject:theCombinedRecord];
            [mcellMembersIdArray addObject:theId];
            
            
            
        }
        [mcellMembersNameArray writeToFile:fileName atomically:YES];
        [mcellMembersIdArray writeToFile:fileName2 atomically:YES];
        autocomplete = [[Autocomplete alloc] initWithArray:mcellMembersNameArray];
        //MVC =[[MasterViewController alloc] init];
        //MVC.mcellMembersNameArray = [[NSMutableArray alloc] initWithArray:cellMembersNameArray copyItems:YES];
        [theDetailTable reloadData];
        //[MVC.theDetailTable reloadData];
        // [MVC viewDidAppear:YES];
    }
    
    // NSLog(@"this is the result %@", resultValue);
    
}


- (void)viewDidAppear:(BOOL)animated
{
    
userHasLogedIn_master =  [[NSUserDefaults standardUserDefaults] integerForKey: @"loginindicator_master"];
    encodedusername_master = [[NSUserDefaults standardUserDefaults] valueForKey: @"encodedlogindetails"];
theEntityValue_master = [[NSUserDefaults standardUserDefaults] valueForKey: @"screenentity"];
    
    if(userHasLogedIn_master == 1){
        
         NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
        
        [self retrieveCellMembers:thePageSizeValue theCounerValue:thecounter];
        userHasLogedIn_master = 2;
        
        [[NSUserDefaults standardUserDefaults] setInteger:userHasLogedIn_master forKey: @"loginindicator_master"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }

    
    else{
    NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmembernames_master.txt"];
        
        NSString *fileName4 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmemberid_master.txt"];
        
    NSString *fileName2 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmemberimages.txt"];
    NSString *fileName3 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmemberrankings.txt"];
    
    
    
   // if(mcellMembersNameArray == nil){
        mcellMembersNameArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName];
        
        mcellMembersIdArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName4];
   // }
    
    //if(mcellMembersImageArray == nil){
        mcellMembersImageArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName2];
        
    //}
    
    //if(mcellMembersRankingArray == nil){
        mcellMembersRankingArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName3];
    //}
    }
    
    
    [super viewDidAppear:animated];
    
    [theDetailTable reloadData];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [mcellMembersNameArray count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //static NSString *CellIdentifier = @"Cell";
    
    static NSString *simpleTableIdentifier = @"masterViewDemoCell";
    
    cell = (MasterViewTableCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MasterViewTableCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
   /** UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }**/

    // Configure the cell.
    cell.nameLabel.text = [mcellMembersNameArray objectAtIndex:indexPath.row];
    cell.memberImage.image = [UIImage imageNamed:@"pix_icon.png"];
    cell.rankingImage.image = [UIImage imageNamed:@"ic_star_on.png"];
    cell.rankingImage2.image = [UIImage imageNamed:@"ic_star_off.png"];
    cell.rankingImage3.image = [UIImage imageNamed:@"ic_star_off.png"];
    cell.rankingImage4.image = [UIImage imageNamed:@"ic_star_off.png"];
    cell.rankingImage5.image = [UIImage imageNamed:@"ic_star_off.png"];
    
    return cell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString* selectedRegion = [mcellMembersNameArray objectAtIndex:indexPath.row];
    
    NSString* idRegion = [mcellMembersIdArray objectAtIndex:indexPath.row];
    
   // NSLog(@"the selected value is %@ and the id is %@", selectedRegion, idRegion);
    
   CellMemberDetailsViewController *CMD = [[CellMemberDetailsViewController alloc] initWithNibName:@"CellMemberDetailsViewController" bundle:[NSBundle mainBundle]];
    
    CMD.theCellMemberName = selectedRegion;
    CMD.theCellMemberId = idRegion;
    CMD.theEntityValue_cellMember = theEntityValue_master;
    CMD.encodedusername_cellMember = encodedusername_master;
    
    [self.navigationController pushViewController:CMD animated:YES];
    
   
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 78;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    
	
	NSLog(@"You want to search for %@", theSearchBar.text);
	
	
	
}


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
	
	//[suggestions release];
	//suggestions = [[NSMutableArray alloc] initWithArray:[autocomplete GetSuggestions:theSearchBarForSearching.text]];
	//[searchResult.tableView reloadData];
    
    mcellMembersNameArray = [[NSMutableArray alloc] initWithArray:[autocomplete GetSuggestions:theSearchBar.text]];
    
    [theDetailTable reloadData];
	
    // NSLog(@"the text is changing");
}



@end
