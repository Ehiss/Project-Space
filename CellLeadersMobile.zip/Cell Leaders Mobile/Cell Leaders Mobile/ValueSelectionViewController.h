//
//  ValueSelectionViewController.h
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/8/13.
//
//

#import <UIKit/UIKit.h>
//#import "ValueSelectionViewController.h"

@protocol CountryUpdaterDelegate

-(void)updateCountry:(NSString*)theCountry;

@end

@interface ValueSelectionViewController : UITableViewController{
    
    //NSMutableArray *regionItems;
    //AppDelegate *theDelegate;
    
    id <CountryUpdaterDelegate> delegate;
    
}
@property (retain) id delegate;
@property NSString *theResource;
@property NSMutableArray *regionItems;

@end