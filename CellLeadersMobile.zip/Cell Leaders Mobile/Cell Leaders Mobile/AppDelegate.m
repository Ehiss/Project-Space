//
//  AppDelegate.m
//  Cell Leaders Mobile
//
//  Created by imm(content 2 mobile) on 3/22/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"

#import "MasterViewController.h"



@implementation AppDelegate

@synthesize window = _window;
@synthesize splitViewController = _splitViewController, detailViewController;


- (void) saveState{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *fileName = [documentsDirectory stringByAppendingPathComponent:@"cellmembernames.txt"];
    NSString *fileName2 = [documentsDirectory stringByAppendingPathComponent:@"cellmemberimages.txt"];
    NSString *fileName3 = [documentsDirectory stringByAppendingPathComponent:@"cellmemberrankings.txt"];
    
   // NSString *fileName4 = [documentsDirectory stringByAppendingPathComponent:@"cellreportsarchive.txt"];
    
    BOOL fileCreationSuccess = [fileManager createFileAtPath:fileName contents:nil attributes:nil];
    BOOL fileCreationSuccess2 = [fileManager createFileAtPath:fileName2 contents:nil attributes:nil];
    BOOL fileCreationSuccess3 = [fileManager createFileAtPath:fileName3 contents:nil attributes:nil];
   // BOOL fileCreationSuccess4 = [fileManager createFileAtPath:fileName4 contents:nil attributes:nil];
    
    if(fileCreationSuccess == YES || fileCreationSuccess2 == YES || fileCreationSuccess3 == YES /**|| fileCreationSuccess4 == YES**/){
        
        NSLog(@"Directorys %@  created successfully!", fileName);
        
        [detailViewController.cellMembersNameArray writeToFile:fileName atomically:YES];
        [detailViewController.cellMembersImageArray writeToFile:fileName2 atomically:YES];
        [detailViewController.cellMembersRankingArray writeToFile:fileName3 atomically:YES];
        
    }
}



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmembernames.txt"];
NSString *fileName2 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmemberimages.txt"];
NSString *fileName3 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmemberrankings.txt"];
    
  NSString *fileName4 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmembernames_master.txt"];
    
    NSString *fileName5 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmemberid_master.txt"];
    
    NSString *fileName6 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk1.txt"];
    
    NSString *fileName7 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk2.txt"];
    
    NSString *fileName8 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk3.txt"];
    
    NSString *fileName9 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk4.txt"];
    
    NSString *fileName10 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk5.txt"];
    
    NSString *fileName11 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellreportarchive.txt"];
    
    if (![fileManager fileExistsAtPath:fileName]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName atomically:YES];
		}
	}
    
    if (![fileManager fileExistsAtPath:fileName2]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName2 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName2 atomically:YES];
		}
	}
    
    if (![fileManager fileExistsAtPath:fileName3]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName3 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName3 atomically:YES];
		}
	}
    
    
    if (![fileManager fileExistsAtPath:fileName4]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName4 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName4 atomically:YES];
		}
	}


    if (![fileManager fileExistsAtPath:fileName5]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName5 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName5 atomically:YES];
		}
	}
    
    if (![fileManager fileExistsAtPath:fileName6]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName6 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName6 atomically:YES];
		}
	}
    
    if (![fileManager fileExistsAtPath:fileName7]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName7 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName7 atomically:YES];
		}
	}
    
    if (![fileManager fileExistsAtPath:fileName8]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName8 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName8 atomically:YES];
		}
	}
    
    if (![fileManager fileExistsAtPath:fileName9]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName9 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName9 atomically:YES];
		}
	}
    
    if (![fileManager fileExistsAtPath:fileName10]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName10 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName10 atomically:YES];
		}
	}
    
    
    if (![fileManager fileExistsAtPath:fileName11]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName11 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			NSLog(@"Directory %@ created successfully!", fileName11);
			[initialiser writeToFile:fileName11 atomically:YES];
		}
	}
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.

    MasterViewController *masterViewController = [[MasterViewController alloc] initWithNibName:@"MasterViewController" bundle:nil];
    UINavigationController *masterNavigationController = [[UINavigationController alloc] initWithRootViewController:masterViewController];

    detailViewController = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
    UINavigationController *detailNavigationController = [[UINavigationController alloc] initWithRootViewController:detailViewController];

    self.splitViewController = [[UISplitViewController alloc] init];
    self.splitViewController.delegate = detailViewController;
    self.splitViewController.viewControllers = [NSArray arrayWithObjects:masterNavigationController, detailNavigationController, nil];
    self.window.rootViewController = self.splitViewController;
    [self.window makeKeyAndVisible];
    
    
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
    return YES;
}



- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)devToken {
//#if !TARGET_IPHONE_SIMULATOR
    // Get Bundle Info for Remote Registration (handy if you have more than one app)
   // NSString *appName = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"];
   // NSString *appVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
    // Check what Notifications the user has turned on.  We registered for all three, but they may have manually disabled some or all of them.
  

	
	
    // Get the users Device Model, Display Name, Unique ID, Token & Version Number
	
    UIDevice *dev = [UIDevice currentDevice];
	
   // NSUUID *deviceUuid = identifierForVendor;
	
    NSString *deviceName = dev.name;
	
    NSString *deviceModel = dev.model;
	
    //NSString *deviceSystemVersion = dev.systemVersion;
	
	
	
    // Prepare the Device Token for Registration (remove spaces and < >)
	
    NSString *deviceToken = [[[[devToken description]
							   
							   stringByReplacingOccurrencesOfString:@"<"withString:@""]
							  
							  stringByReplacingOccurrencesOfString:@">" withString:@""]
							 
							 stringByReplacingOccurrencesOfString: @" " withString: @""];
    
    
    NSLog(@"this is the device token %@, Device UDID, device name %@, device model %@", deviceToken, deviceName, deviceModel);
    
    
    [[NSUserDefaults standardUserDefaults] setValue:deviceToken forKey: @"thedevicetoken"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:deviceName forKey: @"thedevicename"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [[NSUserDefaults standardUserDefaults] setValue:deviceModel forKey: @"thedevicemodel"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
	
//#endif
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
	
	
//#if !TARGET_IPHONE_SIMULATOR
    
	/**NSLog(@"Error in registration. Error: %@", error);
	
	NSString *title = @"Your device can not register for remote notification at this time. Thank You";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];**/
//#endif
}

/**
 125
 * Remote Notification Received while application was open.
 126
 */

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
	
	
	
#if !TARGET_IPHONE_SIMULATOR
	
	
	
    NSLog(@"remote notification: %@",[userInfo description]);
	
    NSDictionary *apsInfo = [userInfo objectForKey:@"aps"];
	
	
	
    NSString *alert = [apsInfo objectForKey:@"alert"];
	
    NSLog(@"Received Push Alert: %@", alert);
	
	
	
    NSString *sound = [apsInfo objectForKey:@"sound"];
	
    NSLog(@"Received Push Sound: %@", sound);
	
    //AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
	
	
	
    NSString *badge = [apsInfo objectForKey:@"badge"];
	
    NSLog(@"Received Push Badge: %@", badge);
	
    application.applicationIconBadgeNumber = [[apsInfo objectForKey:@"badge"] integerValue];
	
	
	
#endif
	
}






- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    detailViewController.rateChecker++ ;
    
   [self saveState];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    
    [detailViewController determineWeek];
    
    detailViewController.hasRated = [[NSUserDefaults standardUserDefaults] integerForKey: @"hasRatedCheck"];
    
    if(detailViewController.rateChecker == 1 || detailViewController.rateChecker == 3 || detailViewController.rateChecker == 5 || detailViewController.rateChecker == 7 || detailViewController.rateChecker == 9 || detailViewController.rateChecker == 11){
        
        if(detailViewController.hasRated != 1){
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Kindly Rate The Cell Leader's App!"
                                                            message:@"We would like you to kindly rate this App on the App Store. Thank You"
                                                           delegate:detailViewController
                                                  cancelButtonTitle:@"Rate Later"
                                                  otherButtonTitles:@"Rate Now", nil];
            [alert show];
            //[alert release];
            
        }
    }

    
    
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    [self saveState];
}

@end
