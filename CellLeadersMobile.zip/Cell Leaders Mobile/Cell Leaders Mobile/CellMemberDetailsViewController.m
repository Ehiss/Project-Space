//
//  CellMemberDetailsViewController.m
//  Cell Leaders Mobile
//
//  Created by ehiss on 6/2/13.
//
//

#import "CellMemberDetailsViewController.h"

@interface CellMemberDetailsViewController ()

@end

@implementation CellMemberDetailsViewController

@synthesize theCellMemberName, theCellMemberId, theEntityValue_cellMember, encodedusername_cellMember, popoverController3, popoverController2;


-(void)textFieldDidBeginEditing:(UITextField *)textField{
    
    if(textField.tag == 1 || textField.tag == 2 || textField.tag == 3){
        NSLog(@"you want to edit this textfield");
        [self animateEntireViewForEditing:nil finished:nil context:nil];
    }
}

-(void)updateCountry:(NSString*)theCountry{
    [self.popoverController2 dismissPopoverAnimated:YES];
    //NSLog(@"you selected %@", theCountry);
   if([theValue isEqualToString:@"selectyeardob"]){
       [DOByear setText:theCountry];
       [DOByear setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
   }
    else
        if([theValue isEqualToString:@"selectmonthdob"]){
            [DOBmonth setText:theCountry];
            [DOBmonth setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
        }
        else
            if([theValue isEqualToString:@"selectdaydob"]){
                [DOBday setText:theCountry];
                [DOBday setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
            }
            else
                if([theValue isEqualToString:@"selectdaydjm"]){
                    [dateJoinedMinDay setText:theCountry];
                    [dateJoinedMinDay setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                }
                else
                    if([theValue isEqualToString:@"selectmonthdjm"]){
                        [dateJoinedMinMonth setText:theCountry];
                        [dateJoinedMinMonth setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                    }
                    else
                        if([theValue isEqualToString:@"selectyeardjm"]){
                            [dateJoinedMinYear setText:theCountry];
                            [dateJoinedMinYear setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                        }
                        else
                            if([theValue isEqualToString:@"selectdaydba"]){
                                [dateBornAgainDay setText:theCountry];
                                [dateBornAgainDay setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                            }
                            else
                                if([theValue isEqualToString:@"selectmonthdba"]){
                                    [dateBornAgainMonth setText:theCountry];
                                    [dateBornAgainMonth setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                }
                                else
                                    if([theValue isEqualToString:@"selectyeardba"]){
                                        [dateBornAgainYear setText:theCountry];
                                        [dateBornAgainYear setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                    }
                                    else
                                        if([theValue isEqualToString:@"selectbaptized"]){
                                            [baptizedLabel setText:theCountry];
                                            [baptizedLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                        }
                                        else
                                            if([theValue isEqualToString:@"selectpartner"]){
                                                [partnerLabel setText:theCountry];
                                                [stateField resignFirstResponder];
                                                [self animateEntireViewForEditingCompleted:nil finished:nil context:nil];
                                                [partnerLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                            }
                                            else
                                                if([theValue isEqualToString:@"selectstatus"]){
                                                    [statusLabel setText:theCountry];
                                                    [statusLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                                }
    
                                                else
                                                    if([theValue isEqualToString:@"titleSelector"]){
                                                        [theTitleLabel setText:theCountry];
                                                        [theTitleLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                                    }
    
                                                    else
                                                        if([theValue isEqualToString:@"genderSelector"]){
                                                            [gender setText:theCountry];
                                                            [gender setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                                        }
    
                                                        else
                                                            if([theValue isEqualToString:@"countrySelector"]){
                                                                [countryLabel setText:theCountry];
                                                                [countryLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                                            }
    
                                                            else
                                                                if([theValue isEqualToString:@"stateSelector"]){
                                                                    [stateLabel setText:theCountry];
                                                                    [stateLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                                                }






}

-(IBAction)goBack:(id)sender{
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(IBAction)selectorDependencies:(id)sender{
    
    theValue = [[sender titleLabel] text];
    
    if([theValue isEqualToString:@"selectyeardob"]){
        
        ValueSelectionViewController *MVC =
        [[ValueSelectionViewController alloc]
         initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
        
        MVC.navigationItem.title = @"Select Year";
        //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
        MVC.theResource = theValue;
        UINavigationController *navController =
        [[UINavigationController alloc]
         initWithRootViewController:MVC];
        MVC.delegate = self;
        
        UIPopoverController *popover =
        [[UIPopoverController alloc]
         initWithContentViewController:navController];
        
        popover.delegate = self;
        
        //[MVC release];
        //[navController release];
        
        self.popoverController2 = popover;
        //[popover release];
        //}
        
        CGRect popoverRect = [self.view convertRect:[dobyear_button frame] fromView:[dobyear_button superview]];
        
        popoverRect.size.width = MIN(popoverRect.size.width, 99);
        
        [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }
    
    else
        
        if([theValue isEqualToString:@"titleSelector"]){
            
            ValueSelectionViewController *MVC =
            [[ValueSelectionViewController alloc]
             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
            
            MVC.navigationItem.title = @"Select Title";
            MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
            //MVC.theResource = theValue;
            UINavigationController *navController =
            [[UINavigationController alloc]
             initWithRootViewController:MVC];
            MVC.delegate = self;
            
            UIPopoverController *popover =
            [[UIPopoverController alloc]
             initWithContentViewController:navController];
            
            popover.delegate = self;
            
            //[MVC release];
            //[navController release];
            
            self.popoverController2 = popover;
            //[popover release];
            //}
            
            CGRect popoverRect = [self.view convertRect:[titleButton frame] fromView:[titleButton superview]];
            
            popoverRect.size.width = MIN(popoverRect.size.width, 99);
            
            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            
            //NSLog(@"you have selected %@", theValue);
            
        }
    
        else
            
            if([theValue isEqualToString:@"genderSelector"]){
                
                ValueSelectionViewController *MVC =
                [[ValueSelectionViewController alloc]
                 initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                
                MVC.navigationItem.title = @"Select Gender";
                MVC.regionItems = [[NSMutableArray alloc] initWithArray:theGenderArray copyItems:YES];
                UINavigationController *navController =
                [[UINavigationController alloc]
                 initWithRootViewController:MVC];
                MVC.delegate = self;
                
                UIPopoverController *popover =
                [[UIPopoverController alloc]
                 initWithContentViewController:navController];
                
                popover.delegate = self;
                
                //[MVC release];
                //[navController release];
                
                self.popoverController2 = popover;
                //[popover release];
                //}
                
                CGRect popoverRect = [self.view convertRect:[genderButton frame] fromView:[genderButton superview]];
                
                popoverRect.size.width = MIN(popoverRect.size.width, 99);
                
                [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                
                //NSLog(@"you have selected %@", theValue);
                
            }
    
            else
                
                if([theValue isEqualToString:@"countrySelector"]){
                    
                    ValueSelectionViewController *MVC =
                    [[ValueSelectionViewController alloc]
                     initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                    
                    MVC.navigationItem.title = @"Select Country";
                    MVC.regionItems = [[NSMutableArray alloc] initWithArray:theCountryArray copyItems:YES];
                    // MVC.theResource = theValue;
                    UINavigationController *navController =
                    [[UINavigationController alloc]
                     initWithRootViewController:MVC];
                    MVC.delegate = self;
                    
                    UIPopoverController *popover =
                    [[UIPopoverController alloc]
                     initWithContentViewController:navController];
                    
                    popover.delegate = self;
                    
                    //[MVC release];
                    //[navController release];
                    
                    self.popoverController2 = popover;
                    //[popover release];
                    //}
                    
                    CGRect popoverRect = [self.view convertRect:[countryButton frame] fromView:[countryButton superview]];
                    
                    popoverRect.size.width = MIN(popoverRect.size.width, 99);
                    
                    [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                    
                    //NSLog(@"you have selected %@", theValue);
                    
                }
    
                else
                    
                    if([theValue isEqualToString:@"stateSelector"]){
                        
                        ValueSelectionViewController *MVC =
                        [[ValueSelectionViewController alloc]
                         initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                        
                        MVC.navigationItem.title = @"Select Country";
                        MVC.regionItems = [[NSMutableArray alloc] initWithArray:theStateArray copyItems:YES];
                        // MVC.theResource = theValue;
                        UINavigationController *navController =
                        [[UINavigationController alloc]
                         initWithRootViewController:MVC];
                        MVC.delegate = self;
                        
                        UIPopoverController *popover =
                        [[UIPopoverController alloc]
                         initWithContentViewController:navController];
                        
                        popover.delegate = self;
                        
                        //[MVC release];
                        //[navController release];
                        
                        self.popoverController2 = popover;
                        //[popover release];
                        //}
                        
                        CGRect popoverRect = [self.view convertRect:[stateButton frame] fromView:[stateButton superview]];
                        
                        popoverRect.size.width = MIN(popoverRect.size.width, 99);
                        
                        [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                        
                        //NSLog(@"you have selected %@", theValue);
                        
                    }

    
    else
        
        if([theValue isEqualToString:@"selectmonthdob"]){
            
            ValueSelectionViewController *MVC =
            [[ValueSelectionViewController alloc]
             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
            
            MVC.navigationItem.title = @"Select Month";
            //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
            MVC.theResource = theValue;
            UINavigationController *navController =
            [[UINavigationController alloc]
             initWithRootViewController:MVC];
            MVC.delegate = self;
            
            UIPopoverController *popover =
            [[UIPopoverController alloc]
             initWithContentViewController:navController];
            
            popover.delegate = self;
            
            //[MVC release];
            //[navController release];
            
            self.popoverController2 = popover;
            //[popover release];
            //}
            
            CGRect popoverRect = [self.view convertRect:[dobmonth_button frame] fromView:[dobmonth_button superview]];
            
            popoverRect.size.width = MIN(popoverRect.size.width, 99);
            
            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
        }
    
        else
            
            if([theValue isEqualToString:@"selectdaydob"]){
                
                ValueSelectionViewController *MVC =
                [[ValueSelectionViewController alloc]
                 initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                
                MVC.navigationItem.title = @"Select Day";
                //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                MVC.theResource = theValue;
                UINavigationController *navController =
                [[UINavigationController alloc]
                 initWithRootViewController:MVC];
                MVC.delegate = self;
                
                UIPopoverController *popover =
                [[UIPopoverController alloc]
                 initWithContentViewController:navController];
                
                popover.delegate = self;
                
                //[MVC release];
                //[navController release];
                
                self.popoverController2 = popover;
                //[popover release];
                //}
                
                CGRect popoverRect = [self.view convertRect:[dobdate_button frame] fromView:[dobdate_button superview]];
                
                popoverRect.size.width = MIN(popoverRect.size.width, 99);
                
                [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            }
    
            else
                
                if([theValue isEqualToString:@"selectdaydjm"]){
                    
                    ValueSelectionViewController *MVC =
                    [[ValueSelectionViewController alloc]
                     initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                    
                    MVC.navigationItem.title = @"Select Day";
                    //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                    MVC.theResource = theValue;
                    UINavigationController *navController =
                    [[UINavigationController alloc]
                     initWithRootViewController:MVC];
                    MVC.delegate = self;
                    
                    UIPopoverController *popover =
                    [[UIPopoverController alloc]
                     initWithContentViewController:navController];
                    
                    popover.delegate = self;
                    
                    //[MVC release];
                    //[navController release];
                    
                    self.popoverController2 = popover;
                    //[popover release];
                    //}
                    
                    CGRect popoverRect = [self.view convertRect:[djmday_button frame] fromView:[djmday_button superview]];
                    
                    popoverRect.size.width = MIN(popoverRect.size.width, 99);
                    
                    [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                }

                else
                    
                    if([theValue isEqualToString:@"selectmonthdjm"]){
                        
                        ValueSelectionViewController *MVC =
                        [[ValueSelectionViewController alloc]
                         initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                        
                        MVC.navigationItem.title = @"Select Month";
                        //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                        MVC.theResource = theValue;
                        UINavigationController *navController =
                        [[UINavigationController alloc]
                         initWithRootViewController:MVC];
                        MVC.delegate = self;
                        
                        UIPopoverController *popover =
                        [[UIPopoverController alloc]
                         initWithContentViewController:navController];
                        
                        popover.delegate = self;
                        
                        //[MVC release];
                        //[navController release];
                        
                        self.popoverController2 = popover;
                        //[popover release];
                        //}
                        
                        CGRect popoverRect = [self.view convertRect:[djmmonth_button frame] fromView:[djmmonth_button superview]];
                        
                        popoverRect.size.width = MIN(popoverRect.size.width, 99);
                        
                        [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                    }
    
                    else
                        
                        if([theValue isEqualToString:@"selectyeardjm"]){
                            
                            ValueSelectionViewController *MVC =
                            [[ValueSelectionViewController alloc]
                             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                            
                            MVC.navigationItem.title = @"Select Year";
                            //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                            MVC.theResource = theValue;
                            UINavigationController *navController =
                            [[UINavigationController alloc]
                             initWithRootViewController:MVC];
                            MVC.delegate = self;
                            
                            UIPopoverController *popover =
                            [[UIPopoverController alloc]
                             initWithContentViewController:navController];
                            
                            popover.delegate = self;
                            
                            //[MVC release];
                            //[navController release];
                            
                            self.popoverController2 = popover;
                            //[popover release];
                            //}
                            
                            CGRect popoverRect = [self.view convertRect:[djmyear_button frame] fromView:[djmyear_button superview]];
                            
                            popoverRect.size.width = MIN(popoverRect.size.width, 99);
                            
                            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                        }
    
                        else
                            
                            if([theValue isEqualToString:@"selectdaydba"]){
                                
                                ValueSelectionViewController *MVC =
                                [[ValueSelectionViewController alloc]
                                 initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                                
                                MVC.navigationItem.title = @"Select Day";
                                //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                                MVC.theResource = theValue;
                                UINavigationController *navController =
                                [[UINavigationController alloc]
                                 initWithRootViewController:MVC];
                                MVC.delegate = self;
                                
                                UIPopoverController *popover =
                                [[UIPopoverController alloc]
                                 initWithContentViewController:navController];
                                
                                popover.delegate = self;
                                
                                //[MVC release];
                                //[navController release];
                                
                                self.popoverController2 = popover;
                                //[popover release];
                                //}
                                
                                CGRect popoverRect = [self.view convertRect:[dbaday_button frame] fromView:[dbaday_button superview]];
                                
                                popoverRect.size.width = MIN(popoverRect.size.width, 99);
                                
                                [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                            }
    
                            else
                                
                                if([theValue isEqualToString:@"selectmonthdba"]){
                                    
                                    ValueSelectionViewController *MVC =
                                    [[ValueSelectionViewController alloc]
                                     initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                                    
                                    MVC.navigationItem.title = @"Select Month";
                                    //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                                    MVC.theResource = theValue;
                                    UINavigationController *navController =
                                    [[UINavigationController alloc]
                                     initWithRootViewController:MVC];
                                    MVC.delegate = self;
                                    
                                    UIPopoverController *popover =
                                    [[UIPopoverController alloc]
                                     initWithContentViewController:navController];
                                    
                                    popover.delegate = self;
                                    
                                    //[MVC release];
                                    //[navController release];
                                    
                                    self.popoverController2 = popover;
                                    //[popover release];
                                    //}
                                    
                                    CGRect popoverRect = [self.view convertRect:[dbamonth_button frame] fromView:[dbamonth_button superview]];
                                    
                                    popoverRect.size.width = MIN(popoverRect.size.width, 99);
                                    
                                    [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                                }
    
                                else
                                    
                                    if([theValue isEqualToString:@"selectyeardba"]){
                                        
                                        ValueSelectionViewController *MVC =
                                        [[ValueSelectionViewController alloc]
                                         initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                                        
                                        MVC.navigationItem.title = @"Select Year";
                                        //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                                        MVC.theResource = theValue;
                                        UINavigationController *navController =
                                        [[UINavigationController alloc]
                                         initWithRootViewController:MVC];
                                        MVC.delegate = self;
                                        
                                        UIPopoverController *popover =
                                        [[UIPopoverController alloc]
                                         initWithContentViewController:navController];
                                        
                                        popover.delegate = self;
                                        
                                        //[MVC release];
                                        //[navController release];
                                        
                                        self.popoverController2 = popover;
                                        //[popover release];
                                        //}
                                        
                                        CGRect popoverRect = [self.view convertRect:[dbayear_button frame] fromView:[dbayear_button superview]];
                                        
                                        popoverRect.size.width = MIN(popoverRect.size.width, 99);
                                        
                                        [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                                    }
    
                                    else
                                        
                                        if([theValue isEqualToString:@"selectbaptized"]){
                                            
                                            ValueSelectionViewController *MVC =
                                            [[ValueSelectionViewController alloc]
                                             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                                            
                                            MVC.navigationItem.title = @"Have You Been Baptized?";
                                            //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                                            MVC.theResource = theValue;
                                            UINavigationController *navController =
                                            [[UINavigationController alloc]
                                             initWithRootViewController:MVC];
                                            MVC.delegate = self;
                                            
                                            UIPopoverController *popover =
                                            [[UIPopoverController alloc]
                                             initWithContentViewController:navController];
                                            
                                            popover.delegate = self;
                                            
                                            //[MVC release];
                                            //[navController release];
                                            
                                            self.popoverController2 = popover;
                                            //[popover release];
                                            //}
                                            
                                            CGRect popoverRect = [self.view convertRect:[baptized_button frame] fromView:[baptized_button superview]];
                                            
                                            popoverRect.size.width = MIN(popoverRect.size.width, 99);
                                            
                                            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                                        }
    
                                        else
                                            
                                            if([theValue isEqualToString:@"selectpartner"]){
                                                
                                                ValueSelectionViewController *MVC =
                                                [[ValueSelectionViewController alloc]
                                                 initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                                                
                                                MVC.navigationItem.title = @"Are You a Partner?";
                                                //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                                                MVC.theResource = theValue;
                                                UINavigationController *navController =
                                                [[UINavigationController alloc]
                                                 initWithRootViewController:MVC];
                                                MVC.delegate = self;
                                                
                                                UIPopoverController *popover =
                                                [[UIPopoverController alloc]
                                                 initWithContentViewController:navController];
                                                
                                                popover.delegate = self;
                                                
                                                //[MVC release];
                                                //[navController release];
                                                
                                                self.popoverController2 = popover;
                                                //[popover release];
                                                //}
                                                
                                                CGRect popoverRect = [self.view convertRect:[minpartner_button frame] fromView:[minpartner_button superview]];
                                                
                                                popoverRect.size.width = MIN(popoverRect.size.width, 99);
                                                
                                                [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                                            }


                                            else
                                                
                                                if([theValue isEqualToString:@"selectstatus"]){
                                                    
                                                    ValueSelectionViewController *MVC =
                                                    [[ValueSelectionViewController alloc]
                                                     initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                                                    
                                                    MVC.navigationItem.title = @"Marital Status";
                                                    MVC.regionItems = [[NSMutableArray alloc] initWithArray:maritalStatusArray copyItems:YES];
                                                   // MVC.theResource = theValue;
                                                    UINavigationController *navController =
                                                    [[UINavigationController alloc]
                                                     initWithRootViewController:MVC];
                                                    MVC.delegate = self;
                                                    
                                                    UIPopoverController *popover =
                                                    [[UIPopoverController alloc]
                                                     initWithContentViewController:navController];
                                                    
                                                    popover.delegate = self;
                                                    
                                                    //[MVC release];
                                                    //[navController release];
                                                    
                                                    self.popoverController2 = popover;
                                                    //[popover release];
                                                    //}
                                                    
                                                    CGRect popoverRect = [self.view convertRect:[status_button frame] fromView:[status_button superview]];
                                                    
                                                    popoverRect.size.width = MIN(popoverRect.size.width, 99);
                                                    
                                                    [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                                                }
    

                   
    
}

-(IBAction)editCellMemberRecord:(id)sender{
    
    if(theEditButtonChecker == 0){
        
        NSLog(@"you want to edit ohh");
        [theEdit_button setImage:[UIImage imageNamed:@"submitedit.png"] forState:UIControlStateNormal];
        
        [self animateEditing:nil finished:nil context:nil];
        [stateField setEnabled:YES];
        [firstname_field setEnabled:YES];
        [lastname_field setEnabled:YES];
        [mobilenumber_textfield setEnabled:YES];
        [homeNumber_textfield setEnabled:YES];
        [residentialAddy_textfield setEnabled:YES];
        [occupationField setEnabled:YES];
        [yookosfield setEnabled:YES];
        [emailField setEnabled:YES];
        /**if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
            
            
            [cellLeadersComment setEditable:YES];
            [pastorsComment setEditable:NO];
        }
        else
            
            if([mainrole isEqualToString:@"Pastor"] || [subrole isEqualToString:@"Pastor"]){
                
                [pastorsComment setEditable:YES];
                [cellLeadersComment setEditable:NO];
            }**/
        
        
        theEditButtonChecker = 1;
        
    }
    else
        if(theEditButtonChecker == 1){
            
            NSLog(@"you want to save ohh");
            [theEdit_button setImage:[UIImage imageNamed:@"editreport.png"] forState:UIControlStateNormal];
            
            
            [self animateEditingComplete:nil finished:nil context:nil];
            
            [stateField setEnabled:NO];
            [firstname_field setEnabled:NO];
            [lastname_field setEnabled:NO];
            [mobilenumber_textfield setEnabled:NO];
            [homeNumber_textfield setEnabled:NO];
            [residentialAddy_textfield setEnabled:NO];
            [occupationField setEnabled:NO];
            [yookosfield setEnabled:NO];
            [emailField setEnabled:NO];
            
            [self submitEditedCellMemberRecord:theCellMemberId];
            
            
            
            /**if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
                
                [cellLeadersComment setEditable:NO];
                [self updateCellReport:theReportID];
            }
            else
                if([mainrole isEqualToString:@"Pastor"] || [subrole isEqualToString:@"Pastor"]){
                    
                    [pastorsComment setEditable:NO];
                    [self updateCellReport:theReportID];
                }**/
            //cellLeadersComment.editable
            theEditButtonChecker = 0;
            
        }
    
    
}

- (void)detailCellMemberRead:(NSString*)theMemberID{
    
    //[activityIndicator startAnimating];
    
    NSError* error;
    theURLRequestChecker_cellMember = 1;
    //NSNumber* thevalue = [NSNumber numberWithInt:14];
    [activityIndicator startAnimating];
    // NSLog(@"the entity is %@", cellLeaderReadReportEntityValue);
    
    @try{
        
        //NSArray *entitySpecValue = [[NSArray alloc] initWithObjects:@"total_attendance", @"name",@"members_attendance",@"offering",@"id", nil];
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys: theMemberID,
                              @"entityId",thecellmemberDetailReadEntityValue, @"entityName", /**entitySpecValue,@"entitySpec",**/ nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=read&content=%@", encodedusername_cellMember, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123:80/%@/detailread/", theEntityValue_cellMember]]];
        
        
        //local
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.1.102:8000/%@/detailread/", theEntityValue_cellMember]]];
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData_cellMember = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    

    
    
    
}

- (void)interpreteDetailCellMemberRead:(NSMutableData*)theData{
    
    theTitleAndObject = [[NSMutableDictionary alloc] init];
    theCountryAndObject = [[NSMutableDictionary alloc] init];
    theStateAndObject = [[NSMutableDictionary alloc] init];
    theCellAndObject = [[NSMutableDictionary alloc] init];
    theTitlesArray = [[NSMutableArray alloc] init];
    theGenderArray = [[NSMutableArray alloc] init];
    theCountryArray = [[NSMutableArray alloc] init];
    theStateArray = [[NSMutableArray alloc]init];
    //theCellArray = [[NSMutableArray alloc]init];
    maritalStatusArray = [[NSMutableArray alloc]init];
    
    NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    NSLog(@"this is the read feed back: %@", theXML);
    
    // NSDictionary *monthSpec = [NSDictionary dictionaryWithObjectsAndKeys:@"January", @"01",  @"February", @"02",  @"March", @"03",  @"April", @"04", @"May", @"05", @"June", @"06",  @"July", @"7",@"August", @"8", @"September", @"9", @"October", @"10", @"November", @"11", @"December", @"12",  nil];
     NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    NSArray *detailReadEntities = [json objectForKey:@"resultSet"];
    
    
    
    for(NSDictionary* theDetails in detailReadEntities){
        
        NSString* thePropName = [theDetails objectForKey:@"propertyName"];
        NSString* theValues = [theDetails objectForKey:@"value"];
       // NSString* theType = [theDetails objectForKey:@"type"];
        
        if([thePropName isEqualToString:@"title"]){
            [theTitleLabel setText:theValues];
            NSArray* theTitles = [theDetails objectForKey:@"options"];
            
            for(NSDictionary* options in theTitles){
                
                NSNumber* titleID = [options objectForKey:@"id"];
                
                NSString* titleLabel = [options objectForKey:@"label"];
                
                [theTitlesArray addObject:titleLabel];
                [theTitleAndObject setObject:titleID forKey:titleLabel];
                
            }
            
            NSLog(@"this is the value for title %@", theValues);
            continue;
        }
        else
            if([thePropName isEqualToString:@"first_name"]){
                [firstname_field setText:theValues];
                NSLog(@"this is the value for first name %@", theValues);
                continue;
                
            }
        
            else
                if([thePropName isEqualToString:@"last_name"]){
                    [lastname_field setText:theValues];
                    NSLog(@"this is the value for last name %@", theValues);
                    continue;
                    
                }
                else
                    if([thePropName isEqualToString:@"gender"]){
                        [gender setText:theValues];
                        
                        NSArray* theTitles = [theDetails objectForKey:@"options"];
                        
                        for(NSString* options in theTitles){
                            
                          [theGenderArray addObject:options];
                            
                        }

                        
                        
                        NSLog(@"this is the value for gender %@", theValues);
                        continue;
                        
                    }
        
                    else
                        if([thePropName isEqualToString:@"date_of_birth"]){
                            
                            //NSLog(@"this is the value for dob %@", theValues);
                            
                            NSArray* component = [theValues componentsSeparatedByString:@"-"];
                            NSLog(@"this is the value for dob %d", [component count]);
                            /**if([component count] != 0){
                                
                                NSString* theYear = [component objectAtIndex:0];
                                NSString* theMonth = [component objectAtIndex:1];
                                NSString* theDay = [component objectAtIndex:2];
                                
                                [DOBday setText:theDay];
                                [DOByear setText:theYear];
                                [DOBmonth setText:[monthSpec objectForKey:theMonth]];
                                
                                
                            }**/
                            
                            
                            continue;
                            
                        }
                        else
                            if([thePropName isEqualToString:@"age"]){
                                
                                NSLog(@"this is the value for age %@", theValues);
                                //[gender setText:theValues];
                                continue;
                                
                            }
                            else
                                if([thePropName isEqualToString:@"marital_status"]){
                                    [statusLabel setText:theValues];
                                    
                                    maritalStatusArray = [theDetails objectForKey:@"options"];
                                    
                                    NSLog(@"this is the value for marital status %@", theValues);
                                    continue;
                                    
                                }
                                else
                                    if([thePropName isEqualToString:@"occupation"]){
                                        [occupationField setText:theValues];
                                        NSLog(@"this is the value for occupation %@", theValues);
                                        continue;
                                        
                                    }
                                    else
                                        if([thePropName isEqualToString:@"email"]){
                                            [emailField setText:theValues];
                                            NSLog(@"this is the value for email %@", theValues);
                                            continue;
                                            
                                        }
                                        else
                                            if([thePropName isEqualToString:@"yookos_id"]){
                                                [yookosfield setText:theValues];
                                                NSLog(@"this is the value for yookos id %@", theValues);
                                                continue;
                                                
                                            }
                                            else
                                                if([thePropName isEqualToString:@"mobile_number"]){
                                                    [mobilenumber_textfield setText:theValues];
                                                    NSLog(@"this is the value for mobile number %@", theValues);
                                                    continue;
                                                    
                                                }
                                                else
                                                    if([thePropName isEqualToString:@"home_number"]){
                                                        [homeNumber_textfield setText:theValues];
                                                        NSLog(@"this is the value for home number %@", theValues);
                                                        continue;
                                                        
                                                    }
        
        else
        if([thePropName isEqualToString:@"home_address"]){
        [residentialAddy_textfield setText:theValues];
        NSLog(@"this is the value for residential addy %@", theValues);
        continue;
            
                }
        
        else
            if([thePropName isEqualToString:@"state"]){
                [stateField setText:theValues];
                
                NSArray* theTitles = [theDetails objectForKey:@"options"];
                
                for(NSDictionary* options in theTitles){
                    
                    NSNumber* titleID = [options objectForKey:@"id"];
                    
                    NSString* titleLabel = [options objectForKey:@"label"];
                    
                    [theStateArray addObject:titleLabel];
                    [theStateAndObject setObject:titleID forKey:titleLabel];
                    
                }

                NSLog(@"this is the value for state %@", theValues);
                continue;
                
            }
            else
                if([thePropName isEqualToString:@"country"]){
                    
                    [countryLabel setText:theValues];
                    
                    NSArray* theTitles = [theDetails objectForKey:@"options"];
                    
                    for(NSDictionary* options in theTitles){
                        
                        NSNumber* titleID = [options objectForKey:@"id"];
                        
                        NSString* titleLabel = [options objectForKey:@"label"];
                        
                        [theCountryArray addObject:titleLabel];
                        [theCountryAndObject setObject:titleID forKey:titleLabel];
                        
                    }

                    
                    
                    NSLog(@"this is the value for country %@", theValues);
                    continue;
                    
                }
                else
                    if([thePropName isEqualToString:@"cell"]){
                        
                        NSArray* theTitles = [theDetails objectForKey:@"options"];
                        
                        for(NSDictionary* options in theTitles){
                            
                            NSNumber* titleID = [options objectForKey:@"id"];
                            
                            theValues = [options objectForKey:@"label"];
                            
                            //[theCountryArray addObject:titleLabel];
                            [theCellAndObject setObject:titleID forKey:theValues];
                            
                        }

                        
                        [cellNameLabel setText:theValues];
                        NSLog(@"this is the value for cell %@", theValues);
                        continue;
                        
                    }
                    else
                        if([thePropName isEqualToString:@"date_joined_ministry"]){
                            NSLog(@"this is the value for djm %@", theValues);
                            
                            //NSArray* component = [theValues componentsSeparatedByString:@"-"];
                            /**if([component count] != 0){
                                
                                NSString* theYear = [component objectAtIndex:0];
                                NSString* theMonth = [component objectAtIndex:1];
                                NSString* theDay = [component objectAtIndex:2];
                                
                                [dateJoinedMinDay setText:theDay];
                                [dateJoinedMinYear setText:theYear];
                                [dateJoinedMinMonth setText:[monthSpec objectForKey:theMonth]];
                                
                                
                            }**/

                            //[residentialAddy_textfield setText:theValues];
                            continue;
                            
                        }
                        else
                            if([thePropName isEqualToString:@"date_got_bornagain"]){
                                NSLog(@"this is the value for dba %@", theValues);
                               /** NSArray* component = [theValues componentsSeparatedByString:@"-"];
                                if([component count] != 0){
                                    
                                    NSString* theYear = [component objectAtIndex:0];
                                    NSString* theMonth = [component objectAtIndex:1];
                                    NSString* theDay = [component objectAtIndex:2];
                                    
                                    [dateBornAgainDay setText:theDay];
                                    [dateBornAgainYear setText:theYear];
                                    [dateBornAgainMonth setText:[monthSpec objectForKey:theMonth]];
                                    
                                    
                                }**/

                                
                               // [residentialAddy_textfield setText:theValues];
                                continue;
                                
                            }
                            else
                                if([thePropName isEqualToString:@"water_baptism"]){
                                    [baptizedLabel setText:theValues];
                                    NSLog(@"this is the value for baptisim %@", theValues);
                                    continue;
                                    
                                }
                                else
                                    if([thePropName isEqualToString:@"ministry_partner"]){
                                        [partnerLabel setText:theValues];
                                        NSLog(@"this is the value for ministry partner %@", theValues);
                                        continue;
                                        
                                    }

        
        
        
    }
    
}

- (void)submitEditedCellMemberRecord:(NSString*)theMemberID{
    
    NSError* error;
    theURLRequestChecker_cellMember = 2;
    //NSNumber* thevalue = [NSNumber numberWithInt:14];
    [activityIndicator startAnimating];
    
     NSDictionary *monthSpec = [NSDictionary dictionaryWithObjectsAndKeys:@"1", @"January", @"2", @"February", @"3", @"March", @"4", @"April", @"5", @"May", @"6", @"June", @"7", @"July", @"8", @"August", @"9", @"September", @"10", @"October", @"11", @"November", @"12", @"December", nil];
    
    NSDictionary *theTrueFalseDict = [NSDictionary dictionaryWithObjectsAndKeys:@"True", @"Yes", @"False", @"No",nil];
    
    NSString *theDOBDate = [ DOByear.text stringByAppendingString:[NSString stringWithFormat:@"-%@-%@" ,[monthSpec objectForKey:DOBmonth.text], DOBday.text]];
    
    NSString *theDJMDate = [dateJoinedMinYear.text stringByAppendingString:[NSString stringWithFormat:@"-%@-%@" ,[monthSpec objectForKey:dateJoinedMinMonth.text], dateJoinedMinDay.text]];
    
    NSString *theDBADate = [dateBornAgainYear.text stringByAppendingString:[NSString stringWithFormat:@"-%@-%@" ,[monthSpec objectForKey:dateBornAgainMonth.text], dateBornAgainDay.text]];
    
    @try{
        
        //NSArray *entitySpecValue = [[NSArray alloc] initWithObjects:@"total_attendance", @"name",@"members_attendance",@"offering",@"id", nil];
        
        /**if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
            
            entitySpecValue = [NSDictionary dictionaryWithObjectsAndKeys: cellLeadersComment.text, @"cell_leaders_comment", nil];
        }
        else
            
            if([mainrole isEqualToString:@"Pastor"] || [subrole isEqualToString:@"Pastor"]){**/
                
               NSDictionary* entitySpecValue = [NSDictionary dictionaryWithObjectsAndKeys: [theTitleAndObject objectForKey:theTitleLabel.text], @"title",firstname_field.text, @"first_name", lastname_field.text, @"last_name", gender.text, @"gender", theDOBDate, @"date_of_birth", cellmemberAge.text, @"age", statusLabel.text, @"marital_status", occupationField.text, @"occupation", emailField.text, @"email", yookosfield.text, @"yookos_id", mobilenumber_textfield.text, @"mobile_number",homeNumber_textfield.text, @"home_number", residentialAddy_textfield.text, @"home_address", /**[theStateAndObject objectForKey:stateLabel.text]**/@"", @"state", [theCountryAndObject objectForKey:countryLabel.text], @"country", [theCellAndObject objectForKey:cellNameLabel.text], @"cell", theDJMDate, @"date_joined_ministry", theDBADate, @"date_got_born_again", [theTrueFalseDict objectForKey:baptizedLabel.text], @"water_baptism", [theTrueFalseDict objectForKey:partnerLabel.text], @"ministry_partner",nil];
                
            
        
        
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys: theMemberID,
                              @"entityId", entitySpecValue,@"entitySpec", nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=update&content=%@", encodedusername_cellMember, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123:80/%@/update/", theEntityValue_cellMember]]];
        
        
        //local
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.3:8000/%@/update/", cellLeaderReadReportEntityValue]]];
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData_cellMember = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }

    
}

- (void)interpreteSubmittedCellMemberRecord:(NSMutableData*)theData{
    
    //NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    //NSLog(@"this is the read feed back: %@", theXML);
    
    NSString *title = @"Update Successfull, Thank You";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];
    
    
    
}

- (void)animateEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    [UIView animateWithDuration:1.0
                          delay:0.0
                        options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                     animations:^{
                        
                         dobdate_button.center = CGPointMake(136, 129);
                         dobmonth_button.center = CGPointMake(226, 129);
                         dobyear_button.center = CGPointMake(292, 129);
                         status_button.center = CGPointMake(190, 243);
                         djmday_button.center  = CGPointMake(147, 494);
                         djmmonth_button.center  = CGPointMake(233, 494);
                         djmyear_button.center  = CGPointMake(299, 494);
                         dbaday_button.center  = CGPointMake(145, 545);
                         dbamonth_button.center  = CGPointMake(231, 545);
                         dbayear_button.center  = CGPointMake(297, 545);
                         baptized_button.center = CGPointMake(207, 591);
                         minpartner_button.center  = CGPointMake(210, 631);
                         titleButton.center  = CGPointMake(159, 21);
                         genderButton.center = CGPointMake(296, 21);
                         countryButton.center = CGPointMake(296, 410);
                        stateButton.center = CGPointMake(124, 410);
                         
                         
                     }
                     completion:^(BOOL finished){
                         NSLog(@"Move to left done");
                     }];
    
}

- (void)animateEditingComplete:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    [UIView animateWithDuration:1.0
                          delay:0.0
                        options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                     animations:^{
                         
                         dobdate_button.center = CGPointMake(385, 63);
                         dobmonth_button.center = CGPointMake(385, 63);
                         dobyear_button.center = CGPointMake(385, 63);
                        status_button.center = CGPointMake(385, 63);
                         baptized_button.center = CGPointMake(385, 63);
                         minpartner_button.center  = CGPointMake(385, 63);
                         djmday_button.center  = CGPointMake(385, 63);
                         djmmonth_button.center  = CGPointMake(385, 63);
                         djmyear_button.center  = CGPointMake(385, 63);
                         dbaday_button.center  = CGPointMake(385, 63);
                         dbamonth_button.center  = CGPointMake(385, 63);
                         dbayear_button.center  = CGPointMake(385, 63);
                         titleButton.center  = CGPointMake(385, 63);
                         genderButton.center = CGPointMake(385, 63);
                         countryButton.center = CGPointMake(385, 63);
                         stateButton.center = CGPointMake(385, 63);
                     }
                     completion:^(BOOL finished){
                         NSLog(@"Move to left done");
                     }];
    
}

- (void)animateEntireViewForEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    
    [UIView animateWithDuration:1.0
                          delay:0.0
                        options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                     animations:^{
                         
                         theContainerView.center = CGPointMake(175, 70);
                        
                     }
                     completion:^(BOOL finished){
                         NSLog(@"Move to left done");
                     }];
    
}

- (void)animateEntireViewForEditingCompleted:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    [UIView animateWithDuration:1.0
                          delay:0.0
                        options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                     animations:^{
                         
                         theContainerView.center = CGPointMake(175, 394);
                         
                     }
                     completion:^(BOOL finished){
                         NSLog(@"Move to left done");
                     }];
    
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData_cellMember setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    
    [webData_cellMember appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    NSLog(@"ERROR with theConnection");
    NSLog(@"%@", error);
    
    NSString *title = @"There is an issue connecting to the internet at this time, please try again. Thank You";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];
    
    [activityIndicator stopAnimating];
}

-(void)connectionDidFinishLoading:(NSURLConnection *) connection{
    
    NSLog(@"DONE, recieved Bytes: %d", [webData_cellMember length]);
    
    [activityIndicator stopAnimating];
    
    if (theURLRequestChecker_cellMember == 1) {
        
        [self interpreteDetailCellMemberRead:webData_cellMember];
    }
    else
    if (theURLRequestChecker_cellMember == 2) {
        
        [self interpreteSubmittedCellMemberRecord:webData_cellMember];
    }
    
    /**if (theURLRequestChecker == 3) {
     [self interpreteTheReadData:webData];
     }
     
     if (theURLRequestChecker == 4) {
     [self interpreteCellReportReadData:webData];
     }
     
     if (theURLRequestChecker == 5) {
     
     [self interpreteDetailCellReportRead:webData];
     }
     
     if (theURLRequestChecker == 6) {
     
     [self interpreteUpdatedCellReport:webData];
     }**/
    
    
    
}


- (void)viewDidLoad
{
    
    [stateField setEnabled:NO];
    [firstname_field setEnabled:NO];
    [lastname_field setEnabled:NO];
    [mobilenumber_textfield setEnabled:NO];
    [homeNumber_textfield setEnabled:NO];
    [residentialAddy_textfield setEnabled:NO];
    [occupationField setEnabled:NO];
    [yookosfield setEnabled:NO];
    [emailField setEnabled:NO];
    
    thecellmemberDetailReadEntityValue =  [[NSUserDefaults standardUserDefaults] valueForKey: @"cellmembersentity"];
    
    NSLog(@"the selected value is entity value %@ and the encoded value is %@ , and the detail read entity value is %@", theEntityValue_cellMember, encodedusername_cellMember, thecellmemberDetailReadEntityValue);
    
    self.navigationController.navigationBarHidden = YES;
    self.contentSizeForViewInPopover = CGSizeMake(330.0, 800.0);
    
    [theCellMember setText:theCellMemberName];
    
    [self detailCellMemberRead:theCellMemberId];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    theTitleLabel = nil;
    gender = nil;
    DOBday = nil;
    DOBmonth = nil;
    DOByear = nil;
    cellmemberAge = nil;
    emailField = nil;
    statusLabel = nil;
    yookosfield = nil;
    occupationField = nil;
    stateField = nil;
    countryLabel = nil;
    cellNameLabel = nil;
    dateJoinedMinDay = nil;
    dateJoinedMinMonth = nil;
    dateJoinedMinYear = nil;
    dateBornAgainDay = nil;
    dateBornAgainMonth = nil;
    dateBornAgainYear = nil;
    baptizedLabel = nil;
    partnerLabel = nil;
    dobdate_button = nil;
    dobmonth_button = nil;
    dobyear_button = nil;
    status_button = nil;
    djmday_button = nil;
    djmmonth_button = nil;
    djmyear_button = nil;
    dbaday_button = nil;
    dbamonth_button = nil;
    dbayear_button = nil;
    baptized_button = nil;
    minpartner_button = nil;
    firstname_field = nil;
    lastname_field = nil;
    mobilenumber_textfield = nil;
    homeNumber_textfield = nil;
    residentialAddy_textfield = nil;
    theEdit_button = nil;
    titleButton = nil;
    genderButton = nil;
    countryButton = nil;
    [super viewDidUnload];
}
@end
