//
//  SubmitCellReportViewController.m
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/4/13.
//
//

#import "SubmitCellReportViewController.h"

@interface SubmitCellReportViewController ()

@end

@implementation SubmitCellReportViewController
@synthesize delegate, popoverController2, theDayOfTheWeek;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    NSLog(@"This is the day of the week %d", theDayOfTheWeek);
    
    theEntityValue = [[NSUserDefaults standardUserDefaults] valueForKey: @"reportscreenentity"];
    encodedusername = [[NSUserDefaults standardUserDefaults] valueForKey: @"encodedlogindetails"];
    
    self.contentSizeForViewInPopover = CGSizeMake(480.0, 620.0);
    
    UIBarButtonItem *anotherButton = [[UIBarButtonItem alloc] initWithTitle:
									  @"Clear" style:UIBarButtonItemStylePlain target:self action:@selector(clearFields:)];
	self.navigationItem.leftBarButtonItem = anotherButton;
    //anotherButton.style = UIBarButtonItemStyleBordered;
    anotherButton.image = [UIImage imageNamed:@"btn_clear_dark.png"];
	
    
    
    
    UIBarButtonItem *anotherButton2 = [[UIBarButtonItem alloc] initWithTitle:
                                       @"Submit" style:UIBarButtonItemStylePlain target:self action:@selector(submitReport:)];
	self.navigationItem.rightBarButtonItem = anotherButton2;
	//anotherButton2.image = [UIImage imageNamed:@"btn_done_dark.png"];

   // NSLog(@"this is the link for report submission %@", theEntityValue);
   // [self initForCellReportSubmission];
    
   // attendanceIndicator = 0;
   // [self initForCellReportSubmission];
    
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidAppear:(BOOL)animated{
    
    attendanceIndicator = 0;
    
    [attendanceLabel setText:@""];
    [self initForCellReportSubmission];
    
}


-(void)updateCountry:(NSString*)theCountry{
    
    if([theValue isEqualToString:@"selectyear"]){
        
        [yearLabel setText:theCountry];
        [yearLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
        
    }
    
    else
        if([theValue isEqualToString:@"selectday"]){
            
            [dayLabel setText:theCountry];
            [dayLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
            
        }
    
        else
            if([theValue isEqualToString:@"selectmonth"]){
                
                [monthLabel setText:theCountry];
                [monthLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                
            }
    
            else
                if([theValue isEqualToString:@"selectampm"]){
                    
                    [ampmLabel setText:theCountry];
                    [ampmLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                    
                }
                else
                    if([theValue isEqualToString:@"selectmeetingheld"]){
                        
                        [meetingHeldLabel setText:theCountry];
                        [meetingHeldLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                        
                    }
                    else
                        if([theValue isEqualToString:@"selectgivenoffering"]){
                            
                        [offeringSubmittedLabel setText:theCountry];
                        [offeringSubmittedLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                            
                        }
    
                        else
                            if([theValue isEqualToString:@"meetingtype"]){
                                
                            [meetingTypeLabel setText:theCountry];
                            [meetingTypeLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                
                            }
    
    
    
    
     [self.popoverController2 dismissPopoverAnimated:YES];
}


- (void)initForCellReportSubmission{
    
    NSLog(@"this is the entity value for add new report %@", theEntityValue);
    
    totalCellMembers = [[NSMutableArray alloc] init];
    //[totalCellMembers addObject:@"Victor"];
    //[totalCellMembers addObject:@"James"];
   // [totalCellMembers addObject:@"Osahon"];
    //[totalCellMembers addObject:@"Abies"];
    totalCellMembersPresent = [[NSMutableArray alloc] init];
    //[attendanceTable reloadData];
    NSError* error;
    theURLRequestChecker = 1;
    
    [[self delegate] activateTheIndicator];
    
    @try{
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"init", @"mode", nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        //NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=create&content=%@", encodedusername, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123/%@/create/", theEntityValue]]];
        
        //local http://192.168.0.2:8000
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.3:8000/%@/create/", theEntityValue]]];
        
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    
   
    
    
}


-(IBAction)selectorDependencies:(id)sender{
    
    /**if (theError){
        
        NSString *title = @"There is an issue connecting to the internet at this time and as a result, values can not be displayed. Please try again. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
    }**/
    
    theValue = [[sender titleLabel] text];
    if([theValue isEqualToString:@"selectyear"]){
        
        ValueSelectionViewController *MVC =
        [[ValueSelectionViewController alloc]
         initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
        
        MVC.navigationItem.title = @"Select Year";
        //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
        MVC.theResource = theValue;
        UINavigationController *navController =
        [[UINavigationController alloc]
         initWithRootViewController:MVC];
        MVC.delegate = self;
        
        UIPopoverController *popover =
        [[UIPopoverController alloc]
         initWithContentViewController:navController];
        
        popover.delegate = self;
        
        //[MVC release];
        //[navController release];
        
        self.popoverController2 = popover;
        //[popover release];
        //}
        
        CGRect popoverRect = [self.view convertRect:[yearButton frame] fromView:[yearButton superview]];
        
        popoverRect.size.width = MIN(popoverRect.size.width, 99);
        
        [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }
    
    else
        
        if([theValue isEqualToString:@"selectmonth"]){
            
            ValueSelectionViewController *MVC =
            [[ValueSelectionViewController alloc]
             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
            
            MVC.navigationItem.title = @"Select Month";
            //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
            MVC.theResource = theValue;
            UINavigationController *navController =
            [[UINavigationController alloc]
             initWithRootViewController:MVC];
            MVC.delegate = self;
            
            UIPopoverController *popover =
            [[UIPopoverController alloc]
             initWithContentViewController:navController];
            
            popover.delegate = self;
            
            //[MVC release];
            //[navController release];
            
            self.popoverController2 = popover;
            //[popover release];
            //}
            
            CGRect popoverRect = [self.view convertRect:[monthButton frame] fromView:[monthButton superview]];
            
            popoverRect.size.width = MIN(popoverRect.size.width, 99);
            
            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
        }

        else
            
            if([theValue isEqualToString:@"selectday"]){
                
                ValueSelectionViewController *MVC =
                [[ValueSelectionViewController alloc]
                 initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                
                MVC.navigationItem.title = @"Select Day";
                //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                MVC.theResource = theValue;
                UINavigationController *navController =
                [[UINavigationController alloc]
                 initWithRootViewController:MVC];
                MVC.delegate = self;
                
                UIPopoverController *popover =
                [[UIPopoverController alloc]
                 initWithContentViewController:navController];
                
                popover.delegate = self;
                
                //[MVC release];
                //[navController release];
                
                self.popoverController2 = popover;
                //[popover release];
                //}
                
                CGRect popoverRect = [self.view convertRect:[dayButton frame] fromView:[dayButton superview]];
                
                popoverRect.size.width = MIN(popoverRect.size.width, 99);
                
                [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            }
    
            else
                
                if([theValue isEqualToString:@"selectampm"]){
                    
                    ValueSelectionViewController *MVC =
                    [[ValueSelectionViewController alloc]
                     initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                    
                    MVC.navigationItem.title = @"Select Time";
                    //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                    MVC.theResource = theValue;
                    UINavigationController *navController =
                    [[UINavigationController alloc]
                     initWithRootViewController:MVC];
                    MVC.delegate = self;
                    
                    UIPopoverController *popover =
                    [[UIPopoverController alloc]
                     initWithContentViewController:navController];
                    
                    popover.delegate = self;
                    
                    //[MVC release];
                    //[navController release];
                    
                    self.popoverController2 = popover;
                    //[popover release];
                    //}
                    
                    CGRect popoverRect = [self.view convertRect:[ampmButton frame] fromView:[ampmButton superview]];
                    
                    popoverRect.size.width = MIN(popoverRect.size.width, 99);
                    
                    [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                }
    

    
                else
                    
                    if([theValue isEqualToString:@"selectmeetingheld"]){
                        
                        ValueSelectionViewController *MVC =
                        [[ValueSelectionViewController alloc]
                         initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                        
                        MVC.navigationItem.title = @"Meeting Held?";
                        //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                        MVC.theResource = theValue;
                        UINavigationController *navController =
                        [[UINavigationController alloc]
                         initWithRootViewController:MVC];
                        MVC.delegate = self;
                        
                        UIPopoverController *popover =
                        [[UIPopoverController alloc]
                         initWithContentViewController:navController];
                        
                        popover.delegate = self;
                        
                        //[MVC release];
                        //[navController release];
                        
                        self.popoverController2 = popover;
                        //[popover release];
                        //}
                        
                        CGRect popoverRect = [self.view convertRect:[meetingHeldButton frame] fromView:[meetingHeldButton superview]];
                        
                        popoverRect.size.width = MIN(popoverRect.size.width, 99);
                        
                        [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                    }


                    else
                        
                        if([theValue isEqualToString:@"selectgivenoffering"]){
                            
                            ValueSelectionViewController *MVC =
                            [[ValueSelectionViewController alloc]
                             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                            
                            MVC.navigationItem.title = @"Offering Remitted?";
                            //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                            MVC.theResource = theValue;
                            UINavigationController *navController =
                            [[UINavigationController alloc]
                             initWithRootViewController:MVC];
                            MVC.delegate = self;
                            
                            UIPopoverController *popover =
                            [[UIPopoverController alloc]
                             initWithContentViewController:navController];
                            
                            popover.delegate = self;
                            
                            //[MVC release];
                            //[navController release];
                            
                            self.popoverController2 = popover;
                            //[popover release];
                            //}
                            
                            CGRect popoverRect = [self.view convertRect:[offeringSubmittedButton frame] fromView:[offeringSubmittedButton superview]];
                            
                            popoverRect.size.width = MIN(popoverRect.size.width, 99);
                            
                            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                        }
    
    else
        
        if([theValue isEqualToString:@"meetingtype"]){
            
            ValueSelectionViewController *MVC =
            [[ValueSelectionViewController alloc]
             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
            
            MVC.navigationItem.title = @"Meeting Type";
            MVC.regionItems = [[NSMutableArray alloc] initWithArray:meetingType copyItems:YES];
            MVC.theResource = theValue;
            UINavigationController *navController =
            [[UINavigationController alloc]
             initWithRootViewController:MVC];
            MVC.delegate = self;
            
            UIPopoverController *popover =
            [[UIPopoverController alloc]
             initWithContentViewController:navController];
            
            popover.delegate = self;
            
            //[MVC release];
            //[navController release];
            
            self.popoverController2 = popover;
            //[popover release];
            //}
            
            CGRect popoverRect = [self.view convertRect:[meetingTypeButton frame] fromView:[meetingTypeButton superview]];
            
            popoverRect.size.width = MIN(popoverRect.size.width, 99);
            
            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
        }




    
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    
    [webData appendData:data];
    
    //theError = FALSE;
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    theError = TRUE;
    
    NSString *title = @"There is an issue connecting to the internet at this time, please try again. Thank You";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];
    
    [[self delegate] deActivateTheIndicator];
    
    NSLog(@"ERROR with theConnection");
    NSLog(@"%@", error);
}

-(void)connectionDidFinishLoading:(NSURLConnection *) connection{
    
    [[self delegate] deActivateTheIndicator];
    //theError = FALSE;
    
    NSLog(@"DONE, recieved Bytes: %d", [webData length]);
    
    if (theURLRequestChecker == 1) {
        [self interpreteTheData:webData];
    }
    
    if (theURLRequestChecker == 2) {
        [self interpreteSubmitData:webData];
    }
    
}


- (void)interpreteTheData:(NSMutableData*)theData{
    
    theTitleAndObject = [[NSMutableDictionary alloc] init];
    cellMembersPresent = [[NSMutableArray alloc] init];
    //totalCellMembers = [[NSMutableArray alloc] init];
    //totalCellMembersPresent = [[NSMutableArray alloc] init];
   
    NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
     NSLog(@"this is the feed back: %@", theXML);
    
    if(theXML.length == 0){
        
        NSString *title = @"There is an issue connecting to the internet at this time, please try again. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
    }

    
   
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    //entitySpecification = [json objectForKey:@"entitySpec"];
    theentityname = [json objectForKey:@"entity"];
    
    NSArray *theEntitySpec = [json objectForKey:@"entitySpec"];
    
    for(NSDictionary *theEntitySpecValues in theEntitySpec){
        
        //NSString *thePropertyname = [theEntitySpecValues objectForKey:@"propertyName"];
        
        NSString *theType = [theEntitySpecValues objectForKey:@"type"];
        
        NSString *theProperty = [theEntitySpecValues objectForKey:@"propertyName"];
        
        if([theType isEqualToString:@"multiselect"]){
            
            NSArray *theCellMembers = [theEntitySpecValues objectForKey:@"options"];
            
            for(NSDictionary *theOptions in theCellMembers){
                
                NSString* cellMemberName = [theOptions objectForKey:@"label"];
                NSNumber* titleID = [theOptions objectForKey:@"id"];
                
                [totalCellMembers addObject:cellMemberName];
                [theTitleAndObject setObject:titleID forKey:cellMemberName];
                
            }
            
        }
        
        if([theType isEqualToString:@"combo"] && [theProperty isEqualToString:@"type_of_meeting"]){
            
            meetingType = [theEntitySpecValues objectForKey:@"options"];
        }
    }
    
    NSLog(@"this is the entity name %@", theentityname);
    
    [[NSUserDefaults standardUserDefaults] setValue:theentityname forKey: @"cellreportviewingentity"];
    [[NSUserDefaults standardUserDefaults] synchronize];

    
    [attendanceTable reloadData];

    
}

- (void)interpreteSubmitData:(NSMutableData*)theData{
    
    NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    NSLog(@"this is the feed back: %@", theXML);
    
    if(theXML.length == 0){
        
        NSString *title = @"There is an issue connecting to the internet at this time, please try again. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
        
    }
    
    else{
        
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    //entitySpecification = [json objectForKey:@"entitySpec"];
    submissionEntityValue = [json objectForKey:@"entity"];
    theResult = [json objectForKey:@"result"];
    
   // NSArray *theFaultFeedBack = [json objectForKey:@"fault"];
    
    //NSDictionary *faultValues = [json objectForKey:@"fault"];
    
   // NSString *theFault = [json objectForKey:@"fault"];
    
    if([theResult isEqualToString:@"false"]){
       
        NSString *title = @"Your report could not be submitted at this time, please ensure all values have been correctly entered and you are not submitting the same report twice";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];

        
    }
    
    else
        if([theResult isEqualToString:@"true"]){
            
           // NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/ellattendancewk1.txt"];
                
                NSString *title = @"Your report has been submitted successfully";
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                
                [alert show];
            
           
            
            if(theDayOfTheWeek == 1){
                
                [cellMembersPresent writeToFile:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk1.txt"] atomically:YES];
                
            }
            else
                if(theDayOfTheWeek == 2){
                    
                    [cellMembersPresent writeToFile:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk2.txt"] atomically:YES];
                    
                }
                else
                    if(theDayOfTheWeek == 3){
                        
                        [cellMembersPresent writeToFile:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk3.txt"] atomically:YES];
                        
                    }
                    else
                        if(theDayOfTheWeek == 4){
                            
                            [cellMembersPresent writeToFile:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk4.txt"] atomically:YES];
                            
                        }
                        else
                            if(theDayOfTheWeek == 5){
                                
                                [cellMembersPresent writeToFile:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk5.txt"] atomically:YES];
                                
                            }
            
             [[self delegate] deActivateThePopup];
            
        }
    
    }
}

-(IBAction)submitReport:(UIBarButtonItem *)sender {
    
    if([hourField.text isEqualToString:@""]){
        
        hourField.backgroundColor = [UIColor redColor];
    }
    
    if([minutesField.text isEqualToString:@""]){
        
        minutesField.backgroundColor = [UIColor redColor];
    }
    
    if([secondsField.text isEqualToString:@""]){
        
        secondsField.backgroundColor = [UIColor redColor];
    }
    
    if([noofFirstTimersField.text isEqualToString:@""]){
        
        noofFirstTimersField.backgroundColor = [UIColor redColor];
    }
    
    if([newConvertsField.text isEqualToString:@""]){
        
        newConvertsField.backgroundColor = [UIColor redColor];
    }
    
    if([firstTimersCaledField.text isEqualToString:@""]){
        
        firstTimersCaledField.backgroundColor = [UIColor redColor];
    }
    
    if([firstTimersVisitedField.text isEqualToString:@""]){
        
        firstTimersVisitedField.backgroundColor = [UIColor redColor];
    }
    
    if([minMaterialTargetField.text isEqualToString:@""]){
        
        minMaterialTargetField.backgroundColor = [UIColor redColor];
    }
    
    if([minMaterialBoughtField.text isEqualToString:@""]){
        
        minMaterialBoughtField.backgroundColor = [UIColor redColor];
    }
    
    if([partnershipTargetField.text isEqualToString:@""]){
        
        partnershipTargetField.backgroundColor = [UIColor redColor];
    }
    
    if([partnershipGivingField.text isEqualToString:@""]){
        
        partnershipGivingField.backgroundColor = [UIColor redColor];
    }
    
    if([offeringField.text isEqualToString:@""]){
        
        offeringField.backgroundColor = [UIColor redColor];
    }
    
    if([followupCardRecieved.text isEqualToString:@""]){
        
        followupCardRecieved.backgroundColor = [UIColor redColor];
    }
    
    
    
    
    if ([hourField.text isEqualToString:@""] || [minutesField.text isEqualToString:@""] || [secondsField.text isEqualToString:@""] || [dayLabel.text isEqualToString:@"day"] || [monthLabel.text isEqualToString:@"month"] || [yearLabel.text isEqualToString:@"year"] || [noofFirstTimersField.text isEqualToString:@""] || [ampmLabel.text isEqualToString:@"am/pm"] || [meetingHeldLabel.text isEqualToString:@"did your meeting hold"] || [offeringSubmittedLabel.text isEqualToString:@"offering remitted ?"]  || [newConvertsField.text isEqualToString:@""] || [firstTimersCaledField.text isEqualToString:@""] || [firstTimersVisitedField.text isEqualToString:@""] || [minMaterialTargetField.text isEqualToString:@""] || [minMaterialBoughtField.text isEqualToString:@""] || [partnershipTargetField.text isEqualToString:@""] || [partnershipGivingField.text isEqualToString:@""]  || [offeringField.text isEqualToString:@""] || [cellLeadersComment.text isEqualToString:@""] || [followupCardRecieved.text isEqualToString:@""] || [meetingTypeLabel.text isEqualToString:@""] ) {
        
        
        NSString *title = @"Some fields have not been properly filled, please ensure all fields are filled. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
    }
    else
        if([totalCellMembersPresent count] == 0){
            
            NSString *title = @"The cell attendance needs to be marked, please do so by selecting the names of those present from the list of cell members provided";
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            
            [alert show];
            
        }

    else{
    
    NSDictionary *monthSpec = [NSDictionary dictionaryWithObjectsAndKeys:@"1", @"January", @"2", @"February", @"3", @"March", @"4", @"April", @"5", @"May", @"6", @"June", @"7", @"July", @"8", @"August", @"9", @"September", @"10", @"October", @"11", @"November", @"12", @"December", nil];
        
        NSDictionary *theTrueFalseDict = [NSDictionary dictionaryWithObjectsAndKeys:@"True", @"Yes", @"False", @"No",nil];
    
    NSString *theTime = [hourField.text stringByAppendingString:[NSString stringWithFormat:@":%@:%@" , minutesField.text, secondsField.text]];
    
    
    
     NSString *theDate = [yearLabel.text stringByAppendingString:[NSString stringWithFormat:@"-%@-%@" ,[monthSpec objectForKey:monthLabel.text], dayLabel.text]];
        
        
        
        
        NSString *partnershipTarget = [partnershipTargetField.text stringByAppendingString:@".00"];
        
        NSString *partnshipGiving = [partnershipGivingField.text stringByAppendingString:@".00"];
        NSString *offering = [offeringField.text stringByAppendingString:@".00"];
        NSString *meetingHeld = [theTrueFalseDict objectForKey:meetingHeldLabel.text];
        //NSString *totalAttendance = attendanceField.text;
        NSString *firstTimers = noofFirstTimersField.text;
        NSString *newConverts = newConvertsField.text;
        NSString *followUpCard = followupCardRecieved.text;
        NSString *firstTimersVisited = firstTimersVisitedField.text;
        NSString *firstTimersCalled = firstTimersCaledField.text;
        NSString *minMatTarget = minMaterialTargetField.text;
        NSString *minMatBought = minMaterialBoughtField.text;
        NSString *offeringSubmitted = [theTrueFalseDict objectForKey:offeringSubmittedLabel.text];
        NSString *thecellLaedersComment = cellLeadersComment.text;
        NSString *themeetingtype = meetingTypeLabel.text;
    
    //NSLog(@"time you want to submit report is %@ and date is %@", theTime, theDate);
        
        
        NSError* error;
        theURLRequestChecker = 2;
        [[self delegate] activateTheIndicator];
        
        @try{
            
            
            NSDictionary *entitySpec = [NSDictionary dictionaryWithObjectsAndKeys:theDate, @"date_of_meeting", theTime, @"time_of_meeting", meetingHeld, @"meeting_held", totalCellMembersPresent, @"members_in_attendance", firstTimers, @"first_timers_attendance", newConverts, @"new_converts_attendance", followUpCard, @"follow_up_cards_received", firstTimersVisited, @"total_first_timers_visited", firstTimersCalled, @"total_first_timers_called", minMatTarget, @"ministry_materials_target", minMatBought, @"ministry_materials_purchased", partnershipTarget, @"partnership_target", partnshipGiving, @"partnership_giving", offering, @"offering", offeringSubmitted, @"offering_remitted",thecellLaedersComment, @"cell_leaders_comment", themeetingtype, @"type_of_meeting", nil];
            
            
            NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:
                                  @"save", @"mode", entitySpec, @"entitySpec", theentityname, @"entityName", nil];
            
            
            NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                               options:NSJSONWritingPrettyPrinted
                                                                 error:&error];
            
            NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                            encoding:NSUTF8StringEncoding];
            
            NSLog(@"this is the json %@", theJsonString);
            
            NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=create&content=%@", encodedusername, theJsonString];
            
           //online
            
            NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123/%@/create/", theEntityValue]]];
            
            // local http://192.168.0.2:8000
            
             //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.3:8000/%@/create/", theEntityValue]]];
            
            
           
            [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            
            
            [postRequest setHTTPMethod:@"POST"];
            [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
            
            
            NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
            
            if(conn) {
                
                webData = [NSMutableData data] ;
            }
            
        }
        
        @catch (NSException *e){
            NSLog(@"Exception %@", e);
        }
        
        
        
    }
    
}

-(IBAction)clearFields:(UIBarButtonItem *)sender {
    
     NSLog(@"you want to clear field");
    
    [hourField setText:@""];
    [minutesField setText:@""];
    [secondsField setText:@""];
    [minMaterialBoughtField setText:@""];
    [minMaterialTargetField setText:@""];
    [dayLabel setText:@"day"];
    [monthLabel setText:@"month"];
    [yearLabel setText:@"year"];
    [ampmLabel setText:@"am/pm"];
    [noofFirstTimersField setText:@""];
    [meetingHeldLabel setText:@"did your meeting hold"];
    [offeringSubmittedLabel setText:@"offering remitted ?"];
    [newConvertsField setText:@""];
    [firstTimersCaledField setText:@""];
    [firstTimersVisitedField setText:@""];
    [partnershipTargetField setText:@""];
    [partnershipGivingField setText:@""];
    [offeringField setText:@""];
    [attendanceField setText:@""];
    [followupCardRecieved setText:@""];
    [cellLeadersComment setText:@""];
    [attendanceLabel setText:@""];
}

-(void)textViewDidBeginEditing:(UITextView *)textView{
    
    NSLog(@"u want to edit now");
    
    [cellLeadersComment setText:@""];
    [cellLeadersComment setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    hourField = nil;
    minutesField = nil;
    secondsField = nil;
    noofFirstTimersField = nil;
    newConvertsField = nil;
    firstTimersVisitedField = nil;
    firstTimersCaledField = nil;
    minMaterialTargetField = nil;
    minMaterialBoughtField = nil;
    partnershipTargetField = nil;
    partnershipGivingField = nil;
    attendanceField = nil;
    offeringField = nil;
    //followupCardsRecievedField = nil;
    followupCardRecieved = nil;
    [super viewDidUnload];
}

#pragma mark -
#pragma mark Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [totalCellMembers count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
        cell = [[UITableViewCell alloc]
				 initWithStyle:UITableViewCellStyleDefault
				 reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
	cell.textLabel.text = [totalCellMembers objectAtIndex:indexPath.row];
	//cell.textLabel.text.size = 14;
	cell.textLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:14];
	
    // cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
	    return cell;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    
    if(textField.tag == 1){
    hourField.backgroundColor = [UIColor whiteColor];
    }
    if(textField.tag == 2){
        minutesField.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 3){
        secondsField.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 4){
       noofFirstTimersField.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 5){
        
        newConvertsField.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 6){
        
         firstTimersVisitedField.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 7){
        
         firstTimersCaledField.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 8){
        
         minMaterialTargetField.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 9){
        
         minMaterialBoughtField.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 10){
     
        followupCardRecieved.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 11){
        
         partnershipTargetField.backgroundColor = [UIColor whiteColor];
    }
    
    if(textField.tag == 12){
       
         partnershipGivingField.backgroundColor = [UIColor whiteColor];
        
    }
    
    if(textField.tag == 13){
        
         offeringField.backgroundColor = [UIColor whiteColor];
    }
    
}



#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *theMember = [totalCellMembers objectAtIndex:indexPath.row];
    [cellMembersPresent addObject:theMember];
    NSNumber* theID = [theTitleAndObject objectForKey:theMember];
    
    
    if(![totalCellMembersPresent containsObject:theID]){
        
        [totalCellMembersPresent addObject:theID];
        attendanceIndicator++ ;
        
        NSString *theAttendance = [NSString stringWithFormat:@"%d", attendanceIndicator];
        [attendanceLabel setText:[NSString stringWithFormat:@"%@ Present", theAttendance]];
        
        
    }
	
	NSLog(@"You selected %@", theID);
    
	
    
}




@end
