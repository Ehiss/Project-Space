//
//  GenerateReportViewController.m
//  Cell Leaders Mobile
//
//  Created by ehiss on 8/30/13.
//
//

#import "GenerateReportViewController.h"

@interface GenerateReportViewController ()

@end

@implementation GenerateReportViewController

@synthesize popoverController2, delegate, popoverController3;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (IBAction)generateReport:(id)sender {
    
    NSDictionary *monthSpec = [NSDictionary dictionaryWithObjectsAndKeys:@"1", @"January", @"2", @"February", @"3", @"March", @"4", @"April", @"5", @"May", @"6", @"June", @"7", @"July", @"8", @"August", @"9", @"September", @"10", @"October", @"11", @"November", @"12", @"December", nil];
    
    
    
    NSString *the_fm_date = dayLabel_fm.text;
    NSString *the_fm_mont = monthLabel_fm.text;
    NSString *the_fm_year = yearLabel_fm.text;
    NSString *the_to_date = dayLabel_to.text;
    NSString *the_to_month = monthLabel_to.text;
    NSString *the_to_year = yearLabel_to.text;
    NSString *the_report_type = reportTypeLabel.text;
    
    if([the_fm_date isEqualToString:@"day"] || [the_fm_mont isEqualToString:@"month"] || [the_fm_year isEqualToString:@"year"] || [the_to_date isEqualToString:@"day"] || [the_to_month isEqualToString:@"month"] || [the_to_year isEqualToString:@"year"] || [reportType length] == 0 || [the_report_type isEqualToString:@"report type"]){
        
        NSString *title = @"Some fields have not been properly filled, please ensure all fields are filled. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
        
    }
    
    else
    {
       
       NSError* error;
        theURLRequestChecker = 3;
        
        [[self delegate] activateTheIndicator];
        [theActivityIndicator startAnimating];
        
        @try{
            
            NSString *theReportLink = [reportTypeAndLink objectForKey:the_report_type];
            NSString *theEntityValue = @"reporting_base";
            
            NSString *theToDate = [the_to_year stringByAppendingString:[NSString stringWithFormat:@"-%@-%@", [monthSpec objectForKey:the_to_month], the_to_date]];
            
            
            NSString *theFromDate = [the_fm_year stringByAppendingString:[NSString stringWithFormat:@"-%@-%@", [monthSpec objectForKey:the_fm_mont], the_fm_date]];
            
           /** NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:
                                  @"init", @"mode", nil];
            
            NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                               options:NSJSONWritingPrettyPrinted
                                                                 error:&error];
            
            NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                            encoding:NSUTF8StringEncoding];**/
            
            //NSLog(@"the json string is %@", theJsonString);
            
            NSDictionary *entitySpec = [NSDictionary dictionaryWithObjectsAndKeys:theFromDate, @"from_date", theToDate, @"to_date", theReportLink, @"report", reportType, @"delivery_mode", nil];
            
            NSData* jsonData = [NSJSONSerialization dataWithJSONObject:entitySpec
                                                               options:NSJSONWritingPrettyPrinted
                                                                 error:&error];
            
            NSString *theJason = [[NSString alloc] initWithData:jsonData
                                                            encoding:NSUTF8StringEncoding];
            
            NSLog(@"this is the json %@", theJason);
            
            NSString *bodyData = [NSString stringWithFormat:@"content=%@",theJason];

            
           // NSString *bodyData = [NSString stringWithFormat:@"from_date=%@&to_date=%@&report=%@&delivery_mode=%@",theFromDate, theToDate, theReportLink, reportType];
            
            //NSLog(@"this is the body data: %@", bodyData);
            
            //online
            NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123:80/%@/%@/", theEntityValue, theReportLink]]];
            
            //local
            
            //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.101:8000/%@/%@", theEntityValue, theReportLink]]];
            
            // NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
            
            
            // Set the request's content type to application/x-www-form-urlencoded
            [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            
            // Designate the request a POST request and specify its body data
            [postRequest setHTTPMethod:@"POST"];
            [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
            
            
            NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
            
            if(conn) {
                
                webData = [NSMutableData data] ;
            }
            
        }
        
        @catch (NSException *e){
            NSLog(@"Exception %@", e);
        }
        
      //[self dismissModalViewControllerAnimated:YES];
    }
    
    
}

- (IBAction)reportTypeAction:(id)sender {
    
    NSString *theButtonValue = [[sender titleLabel] text];
    
    if([theButtonValue isEqualToString:@"download"]){
        
        [download_button setImage:[UIImage imageNamed:@"ic_dot_on.png"] forState:UIControlStateNormal];
        [email_button setImage:[UIImage imageNamed:@"ic_dot_off.png"] forState:UIControlStateNormal];
        
        reportType = theButtonValue;
        
        NSLog(@"the report type is %@", reportType);
    }
    
    else
        if([theButtonValue isEqualToString:@"email"]){
            
        [download_button setImage:[UIImage imageNamed:@"ic_dot_off.png"] forState:UIControlStateNormal];
            [email_button setImage:[UIImage imageNamed:@"ic_dot_on.png"] forState:UIControlStateNormal];
            
            reportType = theButtonValue;
            
            NSLog(@"the report type is %@", reportType);
            
        }
}

- (IBAction)doneReporting:(id)sender{
    
    [self dismissModalViewControllerAnimated:YES];
}

-(IBAction)selectorDependencies:(id)sender{
    
    theValue = [[sender titleLabel] text];
    
    if([theValue isEqualToString:@"selectyear_fm"]){
        
        ValueSelectionViewController *MVC =
        [[ValueSelectionViewController alloc]
         initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
        
        MVC.navigationItem.title = @"Select Year";
        //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
        MVC.theResource = theValue;
        UINavigationController *navController =
        [[UINavigationController alloc]
         initWithRootViewController:MVC];
        MVC.delegate = self;
        
        UIPopoverController *popover =
        [[UIPopoverController alloc]
         initWithContentViewController:navController];
        
        popover.delegate = self;
        
        //[MVC release];
        //[navController release];
        
        self.popoverController2 = popover;
        //[popover release];
        //}
        
        CGRect popoverRect = [self.view convertRect:[yearFmButton frame] fromView:[yearFmButton superview]];
        
        popoverRect.size.width = MIN(popoverRect.size.width, 99);
        
        [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }
    
    else
        if([theValue isEqualToString:@"selectmonth_fm"]){
            
            ValueSelectionViewController *MVC =
            [[ValueSelectionViewController alloc]
             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
            
            MVC.navigationItem.title = @"Select Month";
            //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
            MVC.theResource = theValue;
            UINavigationController *navController =
            [[UINavigationController alloc]
             initWithRootViewController:MVC];
            MVC.delegate = self;
            
            UIPopoverController *popover =
            [[UIPopoverController alloc]
             initWithContentViewController:navController];
            
            popover.delegate = self;
            
            //[MVC release];
            //[navController release];
            
            self.popoverController2 = popover;
            //[popover release];
            //}
            
            CGRect popoverRect = [self.view convertRect:[monthFmButton frame] fromView:[monthFmButton superview]];
            
            popoverRect.size.width = MIN(popoverRect.size.width, 99);
            
            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
        }
    
        else
            if([theValue isEqualToString:@"selectday_fm"]){
                
                ValueSelectionViewController *MVC =
                [[ValueSelectionViewController alloc]
                 initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                
                MVC.navigationItem.title = @"Select Day";
                //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                MVC.theResource = theValue;
                UINavigationController *navController =
                [[UINavigationController alloc]
                 initWithRootViewController:MVC];
                MVC.delegate = self;
                
                UIPopoverController *popover =
                [[UIPopoverController alloc]
                 initWithContentViewController:navController];
                
                popover.delegate = self;
                
                //[MVC release];
                //[navController release];
                
                self.popoverController2 = popover;
                //[popover release];
                //}
                
                CGRect popoverRect = [self.view convertRect:[dayFmButton frame] fromView:[dayFmButton superview]];
                
                popoverRect.size.width = MIN(popoverRect.size.width, 99);
                
                [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            }
    
            else
                if([theValue isEqualToString:@"selectyear_to"]){
                    
                    ValueSelectionViewController *MVC =
                    [[ValueSelectionViewController alloc]
                     initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                    
                    MVC.navigationItem.title = @"Select Year";
                    //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                    MVC.theResource = theValue;
                    UINavigationController *navController =
                    [[UINavigationController alloc]
                     initWithRootViewController:MVC];
                    MVC.delegate = self;
                    
                    UIPopoverController *popover =
                    [[UIPopoverController alloc]
                     initWithContentViewController:navController];
                    
                    popover.delegate = self;
                    
                    //[MVC release];
                    //[navController release];
                    
                    self.popoverController2 = popover;
                    //[popover release];
                    //}
                    
                    CGRect popoverRect = [self.view convertRect:[yearToButton frame] fromView:[yearToButton superview]];
                    
                    popoverRect.size.width = MIN(popoverRect.size.width, 99);
                    
                    [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                }
    
                else
                    if([theValue isEqualToString:@"selectmonth_to"]){
                        
                        ValueSelectionViewController *MVC =
                        [[ValueSelectionViewController alloc]
                         initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                        
                        MVC.navigationItem.title = @"Select Month";
                        //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                        MVC.theResource = theValue;
                        UINavigationController *navController =
                        [[UINavigationController alloc]
                         initWithRootViewController:MVC];
                        MVC.delegate = self;
                        
                        UIPopoverController *popover =
                        [[UIPopoverController alloc]
                         initWithContentViewController:navController];
                        
                        popover.delegate = self;
                        
                        //[MVC release];
                        //[navController release];
                        
                        self.popoverController2 = popover;
                        //[popover release];
                        //}
                        
                        CGRect popoverRect = [self.view convertRect:[monthToButton frame] fromView:[monthToButton superview]];
                        
                        popoverRect.size.width = MIN(popoverRect.size.width, 99);
                        
                        [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                    }
    
    
                    else
                        if([theValue isEqualToString:@"selectday_to"]){
                            
                            ValueSelectionViewController *MVC =
                            [[ValueSelectionViewController alloc]
                             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                            
                            MVC.navigationItem.title = @"Select Day";
                            //MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                            MVC.theResource = theValue;
                            UINavigationController *navController =
                            [[UINavigationController alloc]
                             initWithRootViewController:MVC];
                            MVC.delegate = self;
                            
                            UIPopoverController *popover =
                            [[UIPopoverController alloc]
                             initWithContentViewController:navController];
                            
                            popover.delegate = self;
                            
                            //[MVC release];
                            //[navController release];
                            
                            self.popoverController2 = popover;
                            //[popover release];
                            //}
                            
                            CGRect popoverRect = [self.view convertRect:[dayToButton frame] fromView:[dayToButton superview]];
                            
                            popoverRect.size.width = MIN(popoverRect.size.width, 99);
                            
                            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                        }
    
                        else
                            if([theValue isEqualToString:@"selectreporttype"]){
                                
                                ValueSelectionViewController *MVC =
                                [[ValueSelectionViewController alloc]
                                 initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                                
                                MVC.navigationItem.title = @"Select Report";
                                MVC.regionItems = [[NSMutableArray alloc] initWithArray:cellReportTypes copyItems:YES];
                                MVC.theResource = theValue;
                                UINavigationController *navController =
                                [[UINavigationController alloc]
                                 initWithRootViewController:MVC];
                                MVC.delegate = self;
                                
                                UIPopoverController *popover =
                                [[UIPopoverController alloc]
                                 initWithContentViewController:navController];
                                
                                popover.delegate = self;
                                
                                //[MVC release];
                                //[navController release];
                                
                                self.popoverController2 = popover;
                                //[popover release];
                                //}
                                
                                CGRect popoverRect = [self.view convertRect:[reportTypeButton frame] fromView:[reportTypeButton superview]];
                                
                                popoverRect.size.width = MIN(popoverRect.size.width, 99);
                                
                                [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                            }



    
}

- (IBAction)viewArchivedReport:(id)sender{
   
    if (self.popoverController3 == nil) {
        
        // [self initForCreate];
        //[self retrieveCellMembers:@"5" theCounerValue:@"1"];
        
        TheReportArchiveViewController *addtheMember =
        [[TheReportArchiveViewController alloc]
         initWithNibName:@"TheReportArchiveViewController" bundle:[NSBundle mainBundle]];
        
        addtheMember.navigationItem.title = @"Report Archives";
        addtheMember.delegate = self;
    //addtheMember.cellReportsArray = [[NSMutableArray alloc] initWithArray:cellReportArchiveArray copyItems:YES];
        UINavigationController *navController =
        [[UINavigationController alloc]
         initWithRootViewController:addtheMember];
        
        UIPopoverController *popover =
        [[UIPopoverController alloc]
         initWithContentViewController:navController];
        
        popover.delegate = self;
        
        self.popoverController3 = popover;
        
    }
    
    CGRect popoverRect = [self.view convertRect:[archiveButton frame] fromView:[archiveButton superview]];
    
    popoverRect.size.width = MIN(popoverRect.size.width, 99);
    
    [self.popoverController3 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    
//}

}

- (void)viewDidLoad
{
    encodedusername = [[NSUserDefaults standardUserDefaults] valueForKey: @"encodedlogindetails"];
    
    //theDelegate = [[UIApplication sharedApplication] delegate];
    
   // [self initForViewCellReport];
    [self initForViewCellReportManualWay];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidAppear:(BOOL)animated{
    
    NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellreportarchive.txt"];
    
    if(cellReportArchiveArray == nil){
        
        cellReportArchiveArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName];
    }
    
    
    
    [super viewDidAppear:YES];
    
}

-(void)openTheArchivedReport:(NSString*)theReport {
    
    NSLog(@"This is the report you want to open %@", theReport);
    
    
    [[self delegate] openTheReportArchive:theReport];
    
    [self.popoverController3 dismissPopoverAnimated:YES];
    
    [self dismissModalViewControllerAnimated:YES];
}


-(void)updateCountry:(NSString*)theCountry{
  
    if([theValue isEqualToString:@"selectyear_fm"]){
        
        [yearLabel_fm setText:theCountry];
        [yearLabel_fm setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
        
    }
    else
        if([theValue isEqualToString:@"selectmonth_fm"]){
            
            [monthLabel_fm setText:theCountry];
            [monthLabel_fm setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
            
        }
        else
            if([theValue isEqualToString:@"selectday_fm"]){
                
                [dayLabel_fm setText:theCountry];
                [dayLabel_fm setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                
            }
    
            else
                if([theValue isEqualToString:@"selectyear_to"]){
                    
                    [yearLabel_to setText:theCountry];
                    [yearLabel_to setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                    
                }
    
                else
                    if([theValue isEqualToString:@"selectmonth_to"]){
                        
                        [monthLabel_to setText:theCountry];
                        [monthLabel_to setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                        
                    }
    
                    else
                        if([theValue isEqualToString:@"selectday_to"]){
                            
                            [dayLabel_to setText:theCountry];
                            [dayLabel_to setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                            
                        }
    
                        else
                            if([theValue isEqualToString:@"selectreporttype"]){
                                
                                [reportTypeLabel setText:theCountry];
                                [reportTypeLabel setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                                
                            }
    
    [self.popoverController2 dismissPopoverAnimated:YES];

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initForViewCellReport{
    
    NSString *theEntityValue = @"reporting_base";
    
    NSLog(@"this is the entity value for add new member %@", theEntityValue);
    
    NSError* error;
    theURLRequestChecker = 1;
    
    [[self delegate] activateTheIndicator];
    [theActivityIndicator startAnimating];
    
    @try{
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"init", @"mode", nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        //NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=create&content=%@", encodedusername, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://166.78.9.139/%@/create/", theEntityValue]]];
        
        //local
        
        // NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.101:8000/%@/", theEntityValue]]];
        
        // NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
        
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    
}

- (void)initForViewCellReportManualWay{
    
    
    theURLRequestChecker = 2;
    
    [[self delegate] activateTheIndicator];
    [theActivityIndicator startAnimating];
    
    @try{
        
        NSString *url22 =[NSString stringWithFormat:@"http://162.242.238.123:80/reportMenu"];
        //NSLog(@"%@",url);
        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url22]];
        
        [req setHTTPMethod:@"GET"]; // This might be redundant, I'm pretty sure GET is the default value
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:req delegate:self];
        
        //[conn start];
        
        
        //NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData = [NSMutableData data] ;
        }
        
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }

}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
    {
        [webData setLength:0];
    }
    
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
        
        [webData appendData:data];
        
        //theError = FALSE;
    }
    
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
        
        //theError = TRUE;
        
        NSString *title = @"There is an issue connecting to the internet at this time, please try again. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
        
        [[self delegate] deActivateTheIndicator];
        [theActivityIndicator stopAnimating];
        
        NSLog(@"ERROR with theConnection");
        NSLog(@"%@", error);
    }
    
-(void)connectionDidFinishLoading:(NSURLConnection *) connection{
        
        [[self delegate] deActivateTheIndicator];
        [theActivityIndicator stopAnimating];
       // theError = FALSE;
        
        NSLog(@"DONE, recieved Bytes: %d", [webData length]);
        
        if (theURLRequestChecker == 1) {
            [self interpreteTheData:webData];
        }
    else
    if (theURLRequestChecker == 2) {
        [self interpreteTheDataForMannual:webData];
    }
    else
        if (theURLRequestChecker == 3) {
            [self interpreteSubmitReport:webData];
        }
    
        //if (theURLRequestChecker == 2) {
           // [self interpretePostData:webData];
        //}
        
    }

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    
    return YES;
}
  
 
    

- (void)interpreteTheData:(NSMutableData*)theData{
    
    cellReportTypes = [[NSMutableArray alloc] init];
    reportTypeAndLink = [[NSMutableDictionary alloc] init];
    
    NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    NSLog(@"this is the feed back: %@", theXML);
    
    /** NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    NSArray *reportCategory = [json objectForKey:@"reports"];
    
    for(NSMutableDictionary *theReports in reportCategory){
        
        NSString *theLink = [theReports objectForKey:@"link"];
        NSString *theReport = [theReports objectForKey:@"label"];
        
        [cellReportTypes addObject:theReport];
        [reportTypeAndLink setObject:theLink forKey:theReport];
        
    }
    
    NSLog(@"this is the report value %@", [reportTypeAndLink objectForKey:cellReportTypes[0]]);**/
}

- (void)interpreteTheDataForMannual:(NSMutableData*)theData{
    
    cellReportTypes = [[NSMutableArray alloc] init];
    reportTypeAndLink = [[NSMutableDictionary alloc] init];
    
    NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    NSLog(@"this is the feed back: %@", theXML);
    
     NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
     
     NSArray *reportCategory = [json objectForKey:@"reports"];
     
     for(NSMutableDictionary *theReports in reportCategory){
     
     NSString *theLink = [theReports objectForKey:@"link"];
     NSString *theReport = [theReports objectForKey:@"label"];
     
     [cellReportTypes addObject:theReport];
     [reportTypeAndLink setObject:theLink forKey:theReport];
     
     }
     
     //NSLog(@"this is the report value %@", [reportTypeAndLink objectForKey:cellReportTypes[0]]);
}

- (void)interpreteSubmitReport:(NSMutableData*)theData{
   
    //NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
   // NSLog(@"this is the feed back: %@", theXML);
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    NSString *theReport = [json objectForKey:@"payload"];
    NSString *theStatus = [json objectForKey:@"result"];
    
    if([theStatus isEqualToString:@"true"]){
        
        NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellreportarchive.txt"];
        
       
        
        NSDate *today = [NSDate date];
        NSDateFormatter *tempFormatter = [[NSDateFormatter alloc]init];
        [tempFormatter setDateFormat:@"dd-MM-yyyy HH-mm-ss"];
        NSString *dateString = [tempFormatter stringFromDate:today];
       
        
      
        
        NSString *theReportDate = dateString;
        NSString *theFileName = [reportTypeLabel.text stringByAppendingString:[NSString stringWithFormat:@"(%@)", theReportDate]];
        
        NSLog(@"this is the file name %@", theFileName);
        
        [cellReportArchiveArray addObject:theFileName];
        
        [cellReportArchiveArray writeToFile:fileName atomically:YES];
        
       
        [[self delegate] openTheReport:theReport theReportName:reportTypeLabel.text];
        //[theDelegate.detailViewController getStringForEncoding:theReport];
        [self dismissModalViewControllerAnimated:YES];
    }
    else{
        
        NSString *title = @"Your report could not be generated at this time, please try again. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
        
    }
    
    //NSLog(@"this is the report values %@ and this is the status %@", theReport, theStatus );

    
    
    
}



- (void)viewDidUnload {
    download_button = nil;
    email_button = nil;
    theActivityIndicator = nil;
    [super viewDidUnload];
}
@end
