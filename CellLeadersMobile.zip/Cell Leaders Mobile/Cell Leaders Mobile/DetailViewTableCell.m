//
//  DetailViewTableCell.m
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/10/13.
//
//

#import "DetailViewTableCell.h"


@implementation DetailViewTableCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

/**- (IBAction)attendanceIndicatorButton:(id)sender{
    
    NSString *theString = [[sender titleLabel] text];
    
    NSCalendar *calendar = [NSCalendar autoupdatingCurrentCalendar];
    
    NSDate *today = [NSDate date];
    NSDateFormatter *tempFormatter = [[NSDateFormatter alloc]init];
    [tempFormatter setDateFormat:@"dd-MM-yyyy HH:mm:ss"];
    NSString *dateString = [tempFormatter stringFromDate:today];
    NSDate *pickerDate = [tempFormatter dateFromString:dateString];
    
    NSDateComponents *dateComponents = [calendar components:( NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit )
												   fromDate:pickerDate];
    
    int theDay = [dateComponents day] ;
    
    NSRange firstweek = NSMakeRange(1, 7);
    NSRange secondweek = NSMakeRange(8, 7);
    NSRange thirdweek = NSMakeRange(15, 7);
    NSRange fourthweek = NSMakeRange(22, 7);
    NSRange fifthweek = NSMakeRange(30, 7);
    
    if (NSLocationInRange(theDay, firstweek)) {
        theWeek = 1;
    }
    else
        if (NSLocationInRange(theDay, secondweek)) {
        
        theWeek = 2;
            
        }
    
        else
            
            if (NSLocationInRange(theDay, thirdweek)) {
                                
                theWeek = 3;
            }
            else
                
                if (NSLocationInRange(theDay, fourthweek)) {
                    
                    theWeek = 4;
                }
    
                else
                    
                    if (NSLocationInRange(theDay, fifthweek)) {
                        theWeek = 5;
                    }
    
    
    if ([theString isEqualToString:@"wk1"]) {
        
       // NSLog(@"this is the value of week %d", theWeek);
        
        if (theWeek == 1) {
            
            if(tableViewSelectionForWeek1 == 0){
                [self.wk1Indicator setImage:[UIImage imageNamed:@"ic_dot_on.png"] forState:UIControlStateNormal];
                tableViewSelectionForWeek1 = 1;
            }
            else
            {
                [self.wk1Indicator setImage:[UIImage imageNamed:@"ic_dot_off.png"] forState:UIControlStateNormal];
                tableViewSelectionForWeek1 = 0;
            }
        }

        else{
            NSString *title = @"Attendance can only be entered for the current week, please enter attendance for the highlighted week above. Thank You";
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            
            [alert show];
        }
        
    }

    else
        if ([theString isEqualToString:@"wk2"]) {
            
            if (theWeek == 2) {
                
                if(tableViewSelectionForWeek2 == 0){
                    [self.wk2Indicator setImage:[UIImage imageNamed:@"ic_dot_on.png"] forState:UIControlStateNormal];
                    tableViewSelectionForWeek2 = 1;
                }
                else
                {
                    [self.wk2Indicator setImage:[UIImage imageNamed:@"ic_dot_off.png"] forState:UIControlStateNormal];
                    tableViewSelectionForWeek2 = 0;
                }
            }
            
            else{
                NSString *title = @"Attendance can only be entered for the current week, please enter attendance for the highlighted week above. Thank You";
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                
                [alert show];
            }
            

        }
    
        else
            if ([theString isEqualToString:@"wk3"]) {
                
                if (theWeek == 3) {
                    
                    if(tableViewSelectionForWeek3 == 0){
                        [self.wk3Indicator setImage:[UIImage imageNamed:@"ic_dot_on.png"] forState:UIControlStateNormal];
                        tableViewSelectionForWeek3 = 1;
                    }
                    else
                    {
                        [self.wk3Indicator setImage:[UIImage imageNamed:@"ic_dot_off.png"] forState:UIControlStateNormal];
                        tableViewSelectionForWeek3 = 0;
                    }
                }
                
                else{
                    NSString *title = @"Attendance can only be entered for the current week, please enter attendance for the highlighted week above. Thank You";
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                    
                    [alert show];
                }
                

                
            }
    
            else
                if ([theString isEqualToString:@"wk4"]) {
                    
                    
                    if (theWeek == 4) {
                        
                        if(tableViewSelectionForWeek4 == 0){
                            [self.wk4Indicator setImage:[UIImage imageNamed:@"ic_dot_on.png"] forState:UIControlStateNormal];
                            tableViewSelectionForWeek4 = 1;
                        }
                        else
                        {
                            [self.wk4Indicator setImage:[UIImage imageNamed:@"ic_dot_off.png"] forState:UIControlStateNormal];
                            tableViewSelectionForWeek4 = 0;
                        }
                    }
                    
                    else{
                        NSString *title = @"Attendance can only be entered for the current week, please enter attendance for the highlighted week above. Thank You";
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        
                        [alert show];
                    }
                    

                }

                else
                    if ([theString isEqualToString:@"wk5"]) {
                        
                        
                        if (theWeek == 5) {
                            
                            if(tableViewSelectionForWeek5 == 0){
                                [self.wk5Indicator setImage:[UIImage imageNamed:@"ic_dot_on.png"] forState:UIControlStateNormal];
                                tableViewSelectionForWeek5 = 1;
                            }
                            else
                            {
                                [self.wk5Indicator setImage:[UIImage imageNamed:@"ic_dot_off.png"] forState:UIControlStateNormal];
                                tableViewSelectionForWeek5 = 0;
                            }
                        }
                        
                        else{
                            NSString *title = @"Attendance can only be entered for the current week, please enter attendance for the highlighted week above. Thank You";
                            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                            
                            [alert show];
                        }
                        

                    }


}**/

@end
