//
//  ValueSelectionViewController.m
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/8/13.
//
//

#import "ValueSelectionViewController.h"

@interface ValueSelectionViewController ()

@end

@implementation ValueSelectionViewController

@synthesize delegate, regionItems;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if([self.theResource isEqualToString:@"selectreporttype"]){
        
       self.contentSizeForViewInPopover = CGSizeMake(300.0, 200.0);
    }
    else{
      self.contentSizeForViewInPopover = CGSizeMake(200.0, 200.0);  
    }
    
     NSString* yearpath = [[NSBundle mainBundle] pathForResource:@"yearsource" ofType:@"txt"];
    NSString* monthpath = [[NSBundle mainBundle] pathForResource:@"monthsource" ofType:@"txt"];
    NSString* daypath = [[NSBundle mainBundle] pathForResource:@"daysource" ofType:@"txt"];
    
    
    if([self.theResource isEqualToString:@"selectyear"] ||[self.theResource isEqualToString:@"selectyeardob"] || [self.theResource isEqualToString:@"selectyeardjm"] || [self.theResource isEqualToString:@"selectyeardba"] || [self.theResource isEqualToString:@"selectyear_fm"] || [self.theResource isEqualToString:@"selectyear_to"]){
        
	regionItems = [[NSMutableArray alloc] initWithContentsOfFile:yearpath];
    }
    else
        if([self.theResource isEqualToString:@"selectmonth"] || [self.theResource isEqualToString:@"selectmonthdob"] || [self.theResource isEqualToString:@"selectmonthdjm"] || [self.theResource isEqualToString:@"selectmonthdba"] || [self.theResource isEqualToString:@"selectmonth_fm"] || [self.theResource isEqualToString:@"selectmonth_to"]){
            
            regionItems = [[NSMutableArray alloc] initWithContentsOfFile:monthpath];
        }
        else
            if([self.theResource isEqualToString:@"selectday"] || [self.theResource isEqualToString:@"selectdaydob"] || [self.theResource isEqualToString:@"selectdaydjm"] || [self.theResource isEqualToString:@"selectdaydba"] || [self.theResource isEqualToString:@"selectday_fm"] || [self.theResource isEqualToString:@"selectday_to"]){
                
                regionItems = [[NSMutableArray alloc] initWithContentsOfFile:daypath];
            }
            else
                if([self.theResource isEqualToString:@"selectampm"]){
                    regionItems = [[NSMutableArray alloc] initWithObjects:@"am", @"pm", nil];
                }
                else
                   /** if([self.theResource isEqualToString:@"maritalstatus"]){
                        regionItems = [[NSMutableArray alloc] initWithObjects:@"Un-Married", @"Married", nil];
                    }
                    else**/
                        if([self.theResource isEqualToString:@"bornagain"] || [self.theResource isEqualToString:@"selectbaptized"] || [self.theResource isEqualToString:@"selectpartner"]){
                            regionItems = [[NSMutableArray alloc] initWithObjects:@"Yes", @"No", nil];
                        }
    
    else
        if( [self.theResource isEqualToString:@"selectmeetingheld"] || [self.theResource isEqualToString:@"selectgivenoffering"]){
            regionItems = [[NSMutableArray alloc] initWithObjects:@"Yes", @"No", nil];
        }
    
        else
            if( [self.theResource isEqualToString:@"selectstatus"] ){
                
                regionItems = [[NSMutableArray alloc] initWithObjects:@"Married", @"Un-Married", nil];
            }
    
}




- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Override to allow orientations other than the default portrait orientation.
    return YES;
}


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [regionItems count];
	
}


// Customize the appearance of table view cells.

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		
		cell = [[UITableViewCell alloc]
                initWithStyle:UITableViewCellStyleDefault
                reuseIdentifier:CellIdentifier];
        /**cell = [[[UITableViewCell alloc]
		 initWithStyle:UITableViewCellStyleSubtitle
		 reuseIdentifier:CellIdentifier] autorelease];**/
    }
	
	
    // Configure the cell...
	
	cell.textLabel.text = [regionItems objectAtIndex:indexPath.row];
	
	//cell.textLabel.font = [UIFont fontWithName:@"Trebuchet-Ms" size:40];
    //cell.textLabel.textColor = [UIColor whiteColor];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	
	NSString* selectedRegion = [regionItems objectAtIndex:indexPath.row];
    [[self delegate] updateCountry:selectedRegion];
    
	
	
	
    
}




@end
