//
//  TheReportArchiveViewController.h
//  Cell Leaders Mobile
//
//  Created by ehiss on 11/26/13.
//
//

#import <UIKit/UIKit.h>

@protocol CellReportArchiveDelegate

-(void)openTheArchivedReport:(NSString*)theReport ;

@end

@interface TheReportArchiveViewController : UITableViewController{
    
    id <CellReportArchiveDelegate> delegate;
    
}

@property NSMutableArray *cellReportsArray;
@property (retain) id delegate;

@end
