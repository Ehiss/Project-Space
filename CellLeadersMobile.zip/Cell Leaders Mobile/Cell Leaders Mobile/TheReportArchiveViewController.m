//
//  TheReportArchiveViewController.m
//  Cell Leaders Mobile
//
//  Created by ehiss on 11/26/13.
//
//

#import "TheReportArchiveViewController.h"

@interface TheReportArchiveViewController ()

@end

@implementation TheReportArchiveViewController
@synthesize cellReportsArray, delegate;



- (void)viewDidLoad
{
    
    self.contentSizeForViewInPopover = CGSizeMake(440.0, 450.0);
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
     self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)viewDidAppear:(BOOL)animated{
    
    NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellreportarchive.txt"];
    
        
        self.cellReportsArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName];
    
    [self.tableView reloadData];
    
    
    [super viewDidAppear:YES];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    return [cellReportsArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    cell.textLabel.text = [cellReportsArray objectAtIndex:indexPath.row];
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
	
	if (editingStyle == UITableViewCellEditingStyleDelete) {
		
		NSFileManager *fileManager = [NSFileManager defaultManager];
		NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
		NSString *documentsDirectory = [paths objectAtIndex:0]; // Get documents folder
		NSString* theDataPath = [documentsDirectory stringByAppendingPathComponent:@"Report Library"];
		
		NSString* filepath = [NSString stringWithFormat:@"%@/%@.pdf", theDataPath, [self.cellReportsArray objectAtIndex:indexPath.row]];
		
		if ([fileManager fileExistsAtPath:filepath]) {
			BOOL theStatus = [fileManager removeItemAtPath:filepath error:nil];
			
			if(theStatus == YES){
               NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellreportarchive.txt"]; 
				NSLog(@"Directory %@ deleted successfully!", filepath);
              [cellReportsArray removeObjectAtIndex:indexPath.row];  
                [cellReportsArray writeToFile:fileName atomically:YES];
                
				
			}
		}
		
		// Delete the row from the data source.
		
		//[cellReportsArray removeObjectAtIndex:indexPath.row];
		[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
		
		
		
		
	}
	else if (editingStyle == UITableViewCellEditingStyleInsert) {
		// Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
		//[predictSearchItems replaceObjectAtIndex:indexPath.row withObject:[predictSearchItems objectAtIndex:indexPath.row]];
		//[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
	}
}





-(UITableViewCellEditingStyle) tableView:(UITableView *)
tableView editingStyleForRowAtIndexPath: (NSIndexPath *) indexPath {
	return UITableViewCellEditingStyleDelete;
	//return UITableViewCellEditingStyleInsert;
}


// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
    
    id object = [cellReportsArray objectAtIndex:fromIndexPath.row];
	[cellReportsArray removeObjectAtIndex:fromIndexPath.row];
	[cellReportsArray insertObject:object atIndex:toIndexPath.row];
    
}



// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *theValue = [cellReportsArray objectAtIndex:indexPath.row];
    
    [[self delegate] openTheArchivedReport:theValue];
  
}

@end
