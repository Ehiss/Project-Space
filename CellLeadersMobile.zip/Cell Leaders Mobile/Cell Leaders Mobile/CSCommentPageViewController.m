//
//  CSCommentPageViewController.m
//  ImmStreamingApp2
//
//  Created by Christian Isaac on 10/4/12.
//  Copyright (c) 2012 Emerging Technologies & Re-engineering. All rights reserved.
//

#import "CSCommentPageViewController.h"

@implementation CSCommentPageViewController
@synthesize delegate;

#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.contentSizeForViewInPopover = CGSizeMake(200.0, 300.0);
	regionItems = [[NSMutableArray alloc] initWithObjects:@"Afghanistan",
                   @"Albania",
                   @"Algeria",
                   @"Andorra",
                   @"Angola",
                   @"Anguilla",
                   @"Antarctica",
                   @"Argentina",
                   @"Armenia",
                   @"Aruba",
                   @"Australia", 
                   @"Austria",
                   @"Azerbaijan",
                   @"Bahamas",
                   @"Bahrain",
                   @"Bangladesh",
                   @"Barbados",
                   @"Belarus",
                   @"Belgium",
                   @"Belize",
                   @"Benin",
                   @"Bermuda", 
                   @"Bhutan",
                   @"Bolivia",
                   @"Botswana", 
                   @"Bouvet", 
                   @"Brazil", 
                   @"Brunei", 
                   @"Bulgaria", 
                   @"Burkina Faso", 
                   @"Burundi", 
                   @"Cambodia", 
                   @"Cameroon",
                   @"Canada",
                   @"Cape Verde",
                   @"Cayman",
                   @"Chad",
                   @"Chile",
                   @"China",
                   @"Colombia",
                   @"Comoros",
                   @"Congo",
                   @"Cook Islands",
                   @"Costa Rica",
                   @"Cote Ivoire",
                   @"Croatia",
                   @"Cuba",
                   @"Cyprus",
                   @"Czech Republic",
                   @"Denmark",
                   @"Djibouti", 
                   @"Dominica", 
                   @"East Timor", 
                   @"Ecuador ",
                   @"Egypt", 
                   @"El Salvador",
                   @"Equatorial Guinea",
                   @"Eritrea", 
                   @"Estonia",
                   @"Ethiopia", 
                   @"Finland", 
                   @"France",
                   @"Gabon",
                   @"Gambia",
                   @"Georgia",
                   @"Germany",
                   @"Ghana", 
                   @"Gibraltar",
                   @"Greece", 
                   @"Grenada",
                   @"Guatemala", 
                   @"Guinea", 
                   @"Guinea-Bissau", 
                   @"Guyana",
                   @"Haiti",
                   @"Honduras",
                   @"Hungary",
                   @"Iceland", 
                   @"India", 
                   @"Indonesia",
                   @"Iran",
                   @"Iraq",
                   @"Ireland",
                   @"Israel",
                   @"Italy", 
                   @"Jamaica",
                   @"Japan",
                   @"Jordan",
                   @"Kazakhstan",
                   @"Kenya",
                   @"Kiribati", 
                   @"Korea South",
                   @"Korea North",
                   @"Kuwait",
                   @"Kyrgyzstan",
                   @"Laos",
                   @"Latvia", 
                   @"Lebanon",
                   @"Lesotho",
                   @"Liberia",
                   @"Libya",
                   @"Lithuania",
                   @"Luxembourg", 
                   @"Macedonia",
                   @"Madagascar", 
                   @"Malawi", 
                   @"Malaysia", 
                   @"Maldives", 
                   @"Mali", 
                   @"Malta", 
                   @"Mauritania", 
                   @"Mauritius", 
                   @"Mayotte", 
                   @"Mexico",
                   @"Micronesia", 
                   @"Moldova", 
                   @"Mongolia", 
                   @"Montserrat",
                   @"Morocco",
                   @"Mozambique", 
                   @"Myanmar",
                   @"Namibia", 
                   @"Nauru",
                   @"Nepal",
                   @"Netherlands",
                   @"New Caledoria",
                   @"New Zealand",
                   @"Nicaragua",
                   @"Niger", 
                   @"Nigeria", 
                   @"Niue", 
                   @"Norway",
                   @"Oman", 
                   @"Pakistan",
                   @"Palau",
                   @"Panama", 
                   @"Paraguay", 
                   @"Peru", 
                   @"Philippines", 
                   @"Poland",
                   @"Portugal",
                   @"Puerto Rico",
                   @"Qatar", 
                   @"Reunion",
                   @"Romania", 
                   @"Russia", 
                   @"Rwanda",
                   @"Saudi Arabia", 
                   @"Senegal",
                   @"Sierra Leone",
                   @"Singapore",
                   @"Slovakia", 
                   @"Slovenia", 
                   @"Somalia",
                   @"South Africa", 
                   @"South Georgia",
                   @"Spain",
                   @"Sri Lanka",
                   @"Sudan",
                   @"Swaziland", 
                   @"Sweden",
                   @"Switzerland",
                   @"Syria", 
                   @"Taiwan", 
                   @"Tajikistan",
                   @"Tanzania",
                   @"Thailand", 
                   @"Togo", 
                   @"Tokelau", 
                   @"Tonga",
                   @"Trinidad and Tobago", 
                   @"Tunisia",
                   @"Turkey",
                   @"Uganda",
                   @"Ukraine", 
                   @"UAE",
                   @"UK",
                   @"USA",
                   @"Uruguay", 
                   @"Uzbekistan",
                   @"Vanuatu", 
                   @"Venezuela", 
                   @"Vietnam", 
                   @"Yemen", 
                   @"Yugoslavia", 
                   @"Zambia",
                   @"Zimbabwe", nil];
	
	/**[regionItems addObject:@"America"];
     [regionItems addObject:@"Europe"];
     [regionItems addObject:@"United Kingdom"];
     [regionItems addObject:@"Nigeria"];**/
    
    
    //NSString* filepath = [[NSBundle mainBundle] pathForResource:@"Countries" ofType:@"txt"];
	//regionItems = [[NSMutableArray alloc] initWithContentsOfFile:filepath];
    
}




- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Override to allow orientations other than the default portrait orientation.
    return YES;
}


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [regionItems count];
	
}


// Customize the appearance of table view cells.

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		
		cell = [[UITableViewCell alloc] 
                initWithStyle:UITableViewCellStyleDefault 
                reuseIdentifier:CellIdentifier];
        /**cell = [[[UITableViewCell alloc] 
		 initWithStyle:UITableViewCellStyleSubtitle 
		 reuseIdentifier:CellIdentifier] autorelease];**/
    }
	
	
    // Configure the cell...
	
	cell.textLabel.text = [regionItems objectAtIndex:indexPath.row];
	
	//cell.textLabel.font = [UIFont fontWithName:@"Trebuchet-Ms" size:40];
    //cell.textLabel.textColor = [UIColor whiteColor];
    
    return cell;
}



#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	
	NSString* selectedRegion = [regionItems objectAtIndex:indexPath.row];
    [[self delegate] updateCountry:selectedRegion];
    
	
	
	
    
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    //[super dealloc];
	//[regionItems release];//
}

@end
