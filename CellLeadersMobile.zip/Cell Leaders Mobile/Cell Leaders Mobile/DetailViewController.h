//
//  DetailViewController.h
//  Cell Leaders Mobile
//
//  Created by imm(content 2 mobile) on 3/22/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewController.h"
#import "AddNewMemberViewController.h"
#import "SubmitCellReportViewController.h"
#import "LoginViewController.h"
#import "DetailViewTableCell.h"
#import "GenerateReportViewController.h"
#import "NSData+Base64.h"

@interface DetailViewController : UIViewController <UISplitViewControllerDelegate, UIPopoverControllerDelegate, NSURLConnectionDelegate, SubmissionCompleteDelegate, UITableViewDelegate, UITableViewDataSource, CellReportSubmissionCompleteDelegate, UITextViewDelegate, CellReportViewingDelegate, UIWebViewDelegate, UIDocumentInteractionControllerDelegate, UIAlertViewDelegate>{
    
    IBOutlet UITableView *theDetailTable;
    IBOutlet UIWebView *scoreCardViewer;
    
    IBOutlet UIView *cellLeadersBodyView;
    IBOutlet UIView *pastorsView;
    IBOutlet UIView *cellLeadersHeaderView;
    IBOutlet UIView *statisticsView;
    IBOutlet UIView *theScoreCardView;
    IBOutlet UIButton *buttonForMastersView;
    IBOutlet UILabel *activityNameLabel;
    IBOutlet UILabel *activityTimeLabel;
    IBOutlet UILabel *welcomeLabel;
    IBOutlet UIActivityIndicatorView *theLoadingIndicator;
    
    IBOutlet UIButton *previousButton;
    IBOutlet UIButton *nextButton;
    IBOutlet UIButton *activityButton;
    IBOutlet UIButton *smsButton;
    IBOutlet UIButton *visitationButton;
    IBOutlet UIButton *statisticsButton;
    IBOutlet UIButton *alertButton;
    IBOutlet UIButton *settingsButton;
    IBOutlet UIButton *attendanceButton;
    IBOutlet UIButton *summaryButton;
    IBOutlet UIButton *submitReportButton;
     IBOutlet UIButton *addNewMemberButton;
    IBOutlet UIButton *editButton;
    IBOutlet UIButton *graphicalAnalysisButton;
    IBOutlet UIButton *doneButton;
    
    IBOutlet UIImageView *activityWeek1;
    IBOutlet UIImageView *activityWeek2;
    IBOutlet UIImageView *activityWeek3;
    IBOutlet UIImageView *activityWeek4;
    IBOutlet UIImageView *activityWeek5;
    IBOutlet UILabel *theScoreCardLabel;
    
    __weak IBOutlet UITableView *cellReportTable;
    __weak IBOutlet UILabel *meetingDateLabel;
    __weak IBOutlet UILabel *meetingTimeLabel;
    __weak IBOutlet UILabel *meetingHeldLabel;
    __weak IBOutlet UILabel *firstTimersLabel;
    __weak IBOutlet UILabel *newConvertsLabel;
    __weak IBOutlet UILabel *followUpCardsLabel;
    __weak IBOutlet UILabel *firstTimersVisitedLabel;
    __weak IBOutlet UILabel *firstTimersCalledLabel;
    __weak IBOutlet UITextView *cellLeadersComment;
    __weak IBOutlet UITextView *pastorsComment;
    __weak IBOutlet UITextView *pcuLeadersComment;
    
    __weak IBOutlet UILabel *totalOffering;
    __weak IBOutlet UILabel *offeringRemitted;
    __weak IBOutlet UILabel *partnershipGiving;
    __weak IBOutlet UILabel *partnershipTarget;
    __weak IBOutlet UILabel *minMatBought;
    __weak IBOutlet UILabel *minMatTarget;
    
    
    __weak IBOutlet UITableView *membersPresentTable;
    
    DetailViewTableCell *cell;
    
    MasterViewController *MVC;
    
    //int theWeek;
    int tableViewSelectionForWeek1;
    int tableViewSelectionForWeek2;
    int tableViewSelectionForWeek3;
    int tableViewSelectionForWeek4;
    int tableViewSelectionForWeek5;
    int theURLRequestChecker;
    int userHasLogedIn;
    int theOrientationChecker;
    int theEditButtonChecker;
    int thePageValue;
    
     NSString* thePageSizeValue;
    int thePageValue_report;
    NSString* thePageSizeValue_report;
    NSString* theReportID;
    NSString *theCellReportViewingEntity;
    NSString *theUserName;
    NSString *theUserId;
    NSString *theEntityValue;
    NSString *theentityName;
    NSString *encodedusername;
    NSString *theUsername_ForStorage;
    NSString *cellLeaderReadReportEntityValue;
    NSString *mainrole;
    NSString *subrole;
    NSString *theEditingView;
    NSString* theBookToBeDisplayed;
    NSMutableData *webData;
    NSMutableArray *cellMembersNameArray;
    NSMutableArray *cellMembersImageArray;
    NSMutableArray *cellMembersRankingArray;
    NSMutableArray *theCellReports;
    NSMutableArray *theTotalAttendance;
     NSMutableArray *cellMembersPresent;
    NSMutableArray *cellMembersPresentwk1;
    NSMutableArray *cellMembersPresentwk2;
    NSMutableArray *cellMembersPresentwk3;
    NSMutableArray *cellMembersPresentwk4;
    NSMutableArray *cellMembersPresentwk5;
    NSMutableArray *cellReportStatus;
    NSMutableDictionary *theReportTitleAndObject;
}

@property int rateChecker;
@property int hasRated;
@property NSString *theUserName;
@property int theWeek;
@property (strong, nonatomic) id detailItem;
@property (strong, nonatomic) IBOutlet UILabel *detailDescriptionLabel;
@property (nonatomic, retain) UIPopoverController *popoverController2;
@property (nonatomic, retain) UIPopoverController *popoverController3;
@property (nonatomic, retain) UIPopoverController *popoverController4;
@property NSMutableArray *cellMembersNameArray;
@property NSMutableArray *cellMembersImageArray;
@property NSMutableArray *cellMembersRankingArray;

- (IBAction)footerButtonAction:(id)sender;
-(IBAction)showMasterView:(id)sender;
-(IBAction)headerButtonAction:(id)sender;
- (IBAction)generateReport:(id)sender;

 -(IBAction)doneViewingReport:(id)sender;

-(IBAction)viewInIbook:(id)sender;

-(IBAction)cellReportHeaderButtonAction:(id)sender;
-(void)determineWeek;
- (void)userLogin;
- (void)initForCreate;

- (void)interpreteTheData:(NSMutableData*)theData;

- (void)interpreteTheReadData:(NSMutableData*)theData;

- (void)interpreteCellReportReadData:(NSMutableData*)theData;

- (void)interpreteDetailCellReportRead:(NSMutableData*)theData;

- (void)interpreteUpdatedCellReport:(NSMutableData*)theData;

- (void)interpreteDetailCellMemberRead:(NSMutableData*)theData;

-(void)retrieveCellMembers:(NSString*)pageSize theCounerValue:(NSString*)conter;

-(void)retrieveCellReport:(NSString*)pageSize theCounerValue:(NSString*)conter;

-(void)detailCellReportRead:(NSString*)theId;

-(void)updateCellReport:(NSString*)theId;

-(void)detailCellMemberRead:(NSString*)theId;


- (void)animateTheTextViewsForEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

- (void)animateReturnofTheTextViewsAfterEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

- (void)animateCellLeaderView:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

- (void)animatePastroView:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

- (void)animateStatisticView:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;
- (void)getFrameForRotation ;

- (NSString *)base64Encode:(NSString *)plainText;

- (NSString *)base64Decode:(NSString *)base64String;

- (void)getStringForEncoding:(NSString *)base64String;

- (NSData *)base64DataFromString: (NSString *)string;

-(NSString *) base64StringFromData:(NSString *)str;



@end
