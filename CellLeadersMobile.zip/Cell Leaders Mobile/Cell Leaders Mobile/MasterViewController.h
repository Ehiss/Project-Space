//
//  MasterViewController.h
//  Cell Leaders Mobile
//
//  Created by imm(content 2 mobile) on 3/22/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MasterViewTableCell.h"
#import "CellMemberDetailsViewController.h"
#import "Autocomplete.h"

//@class DetailViewController;

@interface MasterViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, NSURLConnectionDelegate, UISearchBarDelegate>{
    
    IBOutlet UITableView *theDetailTable;
    IBOutlet UISearchBar *theSearchBar;
    IBOutlet UILabel *memberLabel;
    IBOutlet UIActivityIndicatorView *theDetailIndicator;
    IBOutlet UIButton *editButton;
    
    MasterViewTableCell *cell;
    
    NSMutableArray *mcellMembersNameArray;
    NSMutableArray *mcellMembersIdArray;
    NSMutableArray *mcellMembersImageArray;
    NSMutableArray *mcellMembersRankingArray;
    
    NSMutableData *webData_master;
    
    NSString *encodedusername_master;
    NSString *theEntityValue_master;
    Autocomplete *autocomplete;
    
    int userHasLogedIn_master;
    int theURLRequestChecker_master;
    int thePageValue;
    NSString* thePageSizeValue;
}

//@property (strong, nonatomic) DetailViewController *detailViewController;
@property (nonatomic, retain) UITableView *theDetailTable;
@property (nonatomic, retain) NSMutableArray *mcellMembersNameArray;
-(IBAction)editTable:(id)sender;

-(IBAction)refreshTable:(id)sender;

-(void)retrieveCellMembers:(NSString*)pageSize theCounerValue:(NSString*)conter;

- (void)interpreteTheReadCellMembers:(NSMutableData*)theData;

@end
