//
//  DetailViewTableCell.h
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/10/13.
//
//

#import <UIKit/UIKit.h>
//#import "DetailViewController.h"

//@class DetailViewController;

@interface DetailViewTableCell : UITableViewCell{
    
    int theWeek;
    int tableViewSelectionForWeek1;
    int tableViewSelectionForWeek2;
    int tableViewSelectionForWeek3;
    int tableViewSelectionForWeek4;
    int tableViewSelectionForWeek5;
    
    //DetailViewController *thePointer;
    
}

@property (nonatomic, weak) IBOutlet UILabel *nameLabel;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage2;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage3;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage4;
@property (nonatomic, weak) IBOutlet UIImageView *rankingImage5;
@property (nonatomic, weak) IBOutlet UIImageView *wk1Indicator;
@property (nonatomic, weak) IBOutlet UIImageView *wk2Indicator;
@property (nonatomic, weak) IBOutlet UIImageView *wk3Indicator;
@property (nonatomic, weak) IBOutlet UIImageView *wk4Indicator;
@property (nonatomic, weak) IBOutlet UIImageView *wk5Indicator;
@property (nonatomic, weak) IBOutlet UIImageView *memberImage;

//- (IBAction)attendanceIndicatorButton:(id)sender;

@end
