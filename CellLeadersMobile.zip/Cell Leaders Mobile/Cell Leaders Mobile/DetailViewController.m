//
//  DetailViewController.m
//  Cell Leaders Mobile
//
//  Created by imm(content 2 mobile) on 3/22/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

static char base64EncodingTable[64] = {
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
    'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
    'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
    'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
};

#import "DetailViewController.h"

@interface DetailViewController ()
@property (strong, nonatomic) UIPopoverController *masterPopoverController;
- (void)configureView;
@end

@implementation DetailViewController

@synthesize detailItem = _detailItem;
@synthesize detailDescriptionLabel = _detailDescriptionLabel;
@synthesize masterPopoverController = _masterPopoverController;
@synthesize popoverController2, popoverController3, popoverController4, theWeek, cellMembersNameArray, cellMembersImageArray, cellMembersRankingArray, theUserName, hasRated, rateChecker;

-(void)webViewDidStartLoad:(UIWebView *)webView{
    
    [theLoadingIndicator startAnimating];
}

-(void)webViewDidFinishLoad:(UIWebView *)webView{
    
    [theLoadingIndicator stopAnimating];
}

-(IBAction)doneViewingReport:(id)sender{
    
    [theScoreCardView setHidden:YES];
}

-(IBAction)viewInIbook:(id)sender{
    
    NSLog(@"you want to view in ibook");
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0]; // Get documents folder
	NSString* theDataPath = [documentsDirectory stringByAppendingPathComponent:@"Report Library"];
	
	NSURL *url222 = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@.pdf", theDataPath, theBookToBeDisplayed]];
	
	//NSURL *url = [NSURL fileURLWithPath:FilePath];
	
	UIDocumentInteractionController *docController = [UIDocumentInteractionController interactionControllerWithURL:url222];
	
	docController.delegate = self;
	//[docController retain];
	BOOL isValid = [docController presentOpenInMenuFromRect:CGRectZero inView:self.view animated:YES];
	if(isValid){
		NSLog(@"Book is being opened");
	}
    
}

- (IBAction)footerButtonAction:(id)sender{
    
    NSString *buttonSelected = [[sender titleLabel] text];
    
    if ([buttonSelected isEqualToString:@"activity"]) {
        
        [theScoreCardView setHidden:YES];
        
        [activityButton setImage:[UIImage imageNamed:@"ic_on_actv.png"] forState:UIControlStateNormal];
        [statisticsButton setImage:[UIImage imageNamed:@"ic_off_statistics.png"] forState:UIControlStateNormal];
        [alertButton setImage:[UIImage imageNamed:@"ic_off_alert.png"] forState:UIControlStateNormal];
        [smsButton setImage:[UIImage imageNamed:@"ic_off_sms.png"] forState:UIControlStateNormal];
        [visitationButton setImage:[UIImage imageNamed:@"ic_off_visit.png"] forState:UIControlStateNormal];
        [settingsButton setImage:[UIImage imageNamed:@"ic_off_set.png"] forState:UIControlStateNormal];
        
        if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
        [activityNameLabel setText:@"Cell Activity"];
        
        [self animateCellLeaderView:nil finished:nil context:nil];
            
        }
        
        else
            if([mainrole isEqualToString:@"Pastor"] || [subrole isEqualToString:@"Pastor"]){
                
                [activityNameLabel setText:@"Weekly Cell Reports"];
                
                [self animateStatisticView:nil finished:nil context:nil];
                
                NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
                
                [self retrieveCellReport:thePageSizeValue theCounerValue:thecounter];
                
            }
        
    }
    else
        if ([buttonSelected isEqualToString:@"visitation"]) {
            
            [activityButton setImage:[UIImage imageNamed:@"ic_off_actv.png"] forState:UIControlStateNormal];
            [statisticsButton setImage:[UIImage imageNamed:@"ic_off_statistics.png"] forState:UIControlStateNormal];
            [alertButton setImage:[UIImage imageNamed:@"ic_off_alert.png"] forState:UIControlStateNormal];
            [smsButton setImage:[UIImage imageNamed:@"ic_off_sms.png"] forState:UIControlStateNormal];
            [visitationButton setImage:[UIImage imageNamed:@"ic_on_visit.png"] forState:UIControlStateNormal];
            [settingsButton setImage:[UIImage imageNamed:@"ic_off_set.png"] forState:UIControlStateNormal];
            
            NSString *title = @"Coming Soon";
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            
            [alert show];
            
        }
        else
            if ([buttonSelected isEqualToString:@"statistics"]) {
                
                [theScoreCardView setHidden:YES];
                
                [activityButton setImage:[UIImage imageNamed:@"ic_off_actv.png"] forState:UIControlStateNormal];
                [statisticsButton setImage:[UIImage imageNamed:@"ic_on_statistics.png"] forState:UIControlStateNormal];
                [alertButton setImage:[UIImage imageNamed:@"ic_off_alert.png"] forState:UIControlStateNormal];
                [smsButton setImage:[UIImage imageNamed:@"ic_off_sms.png"] forState:UIControlStateNormal];
                [visitationButton setImage:[UIImage imageNamed:@"ic_off_visit.png"] forState:UIControlStateNormal];
                [settingsButton setImage:[UIImage imageNamed:@"ic_off_set.png"] forState:UIControlStateNormal];
                
                
                if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
                    [editButton setHidden:YES];
                    [cellReportTable setHidden:NO];
                    
                    [activityNameLabel setText:@"Statistics"];
                    
                    [self animateStatisticView:nil finished:nil context:nil];
                    
                    NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue_report];
                    
                    [self retrieveCellReport:thePageSizeValue_report theCounerValue:thecounter];
                }
                
                else
                    if([mainrole isEqualToString:@"Pastor"] || [subrole isEqualToString:@"Pastor"]){
                        
                        [editButton setHidden:YES];
                        [cellReportTable setHidden:NO];

                        
                        [activityNameLabel setText:@"Weekly Cell Reports"];
                        
                        [self animateStatisticView:nil finished:nil context:nil];
                        
                        [self retrieveCellReport:@"10" theCounerValue:@"1"];
                        
                    }
                
            
            }
            else
                if ([buttonSelected isEqualToString:@"sms"]) {
                    
                    [activityButton setImage:[UIImage imageNamed:@"ic_off_actv.png"] forState:UIControlStateNormal];
                    [statisticsButton setImage:[UIImage imageNamed:@"ic_off_statistics.png"] forState:UIControlStateNormal];
                    [alertButton setImage:[UIImage imageNamed:@"ic_off_alert.png"] forState:UIControlStateNormal];
                    [smsButton setImage:[UIImage imageNamed:@"ic_on_sms.png"] forState:UIControlStateNormal];
                    [visitationButton setImage:[UIImage imageNamed:@"ic_off_visit.png"] forState:UIControlStateNormal];
                    [settingsButton setImage:[UIImage imageNamed:@"ic_off_set.png"] forState:UIControlStateNormal];
                    
                    NSString *title = @"Coming Soon";
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                    
                    [alert show];
                }
                else
                    if ([buttonSelected isEqualToString:@"alerts"]) {
                        
                        [activityButton setImage:[UIImage imageNamed:@"ic_off_actv.png"] forState:UIControlStateNormal];
                        [statisticsButton setImage:[UIImage imageNamed:@"ic_off_statistics.png"] forState:UIControlStateNormal];
                        [alertButton setImage:[UIImage imageNamed:@"ic_on_alert.png"] forState:UIControlStateNormal];
                        [smsButton setImage:[UIImage imageNamed:@"ic_off_sms.png"] forState:UIControlStateNormal];
                        [visitationButton setImage:[UIImage imageNamed:@"ic_off_visit.png"] forState:UIControlStateNormal];
                        [settingsButton setImage:[UIImage imageNamed:@"ic_off_set.png"] forState:UIControlStateNormal];
                        
                        NSString *title = @"Coming Soon";
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        
                        [alert show];
                    }
                    else
                        if ([buttonSelected isEqualToString:@"settings"]) {
                            
                            [activityButton setImage:[UIImage imageNamed:@"ic_off_actv.png"] forState:UIControlStateNormal];
                            [statisticsButton setImage:[UIImage imageNamed:@"ic_off_statistics.png"] forState:UIControlStateNormal];
                            [alertButton setImage:[UIImage imageNamed:@"ic_off_alert.png"] forState:UIControlStateNormal];
                            [smsButton setImage:[UIImage imageNamed:@"ic_off_sms.png"] forState:UIControlStateNormal];
                            [visitationButton setImage:[UIImage imageNamed:@"ic_off_visit.png"] forState:UIControlStateNormal];
                            [settingsButton setImage:[UIImage imageNamed:@"ic_on_set.png"] forState:UIControlStateNormal];
                            
                            NSString *title = @"Coming Soon";
                            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                            
                            [alert show];
                        }
    
}

-(IBAction)showMasterView:(id)sender{
    if (self.popoverController2 == nil) {
    
    MVC =[[MasterViewController alloc]
     initWithNibName:@"MasterViewController" bundle:[NSBundle mainBundle]];
    
    MVC.navigationItem.title = @"Welcome";
    UINavigationController *navController =
    [[UINavigationController alloc]
     initWithRootViewController:MVC];
    
    UIPopoverController *popover =
    [[UIPopoverController alloc]
     initWithContentViewController:navController];
    
    popover.delegate = self;
    //[MVC release];
    //[navController release];
    
    self.popoverController2 = popover;
    //[popover release];
    }
	
	CGRect popoverRect = [self.view convertRect:[buttonForMastersView frame] fromView:[buttonForMastersView superview]];
	
	popoverRect.size.width = MIN(popoverRect.size.width, 99);
	
	[self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
    
}

-(IBAction)headerButtonAction:(id)sender{
    
    NSString *theButtonSelected = [[sender titleLabel] text];
    
    if ([theButtonSelected isEqualToString:@"addmember"]) {
        
        [summaryButton setImage:[UIImage imageNamed:@"btn_summary_on.png"] forState:UIControlStateNormal];
        
      if (self.popoverController3 == nil) {
            
           // [self initForCreate];
             //[self retrieveCellMembers:@"5" theCounerValue:@"1"];
            
            AddNewMemberViewController *addtheMember =
            [[AddNewMemberViewController alloc]
             initWithNibName:@"AddNewMemberViewController" bundle:[NSBundle mainBundle]];
            
            addtheMember.navigationItem.title = @"Add A New Member";
            addtheMember.delegate = self;
            UINavigationController *navController =
            [[UINavigationController alloc]
             initWithRootViewController:addtheMember];
            
            UIPopoverController *popover =
            [[UIPopoverController alloc]
             initWithContentViewController:navController];
            
            popover.delegate = self;
            //[MVC release];
            //[navController release];
            
            self.popoverController3 = popover;
            //[popover release];
        }
        
        CGRect popoverRect = [self.view convertRect:[addNewMemberButton frame] fromView:[addNewMemberButton superview]];
        
        popoverRect.size.width = MIN(popoverRect.size.width, 99);
        
        [self.popoverController3 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
        
    }
    else
        
        if ([theButtonSelected isEqualToString:@"attendance"]) {
            
            theUserName = @"";
            
            
            [[NSUserDefaults standardUserDefaults] setValue:theUserName forKey: @"username"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            [self userLogin];
            [self determineWeek];
            
    //[attendanceButton setImage:[UIImage imageNamed:@"btn_attendance_on.png"] forState:UIControlStateNormal];
    [summaryButton setImage:[UIImage imageNamed:@"btn_summary_on.png"] forState:UIControlStateNormal];
            
    
        }
    
        else
            if ([theButtonSelected isEqualToString:@"summary"]) {
                
                [self determineWeek];
                
                //[attendanceButton setImage:[UIImage imageNamed:@"btn_attendance_off.png"] forState:UIControlStateNormal];
                [summaryButton setImage:[UIImage imageNamed:@"btn_summary_off.png"] forState:UIControlStateNormal];
                
                if (self.popoverController4 == nil) {
                    
                    SubmitCellReportViewController *MVC22 =
                    [[SubmitCellReportViewController alloc]
                     initWithNibName:@"SubmitCellReportViewController" bundle:[NSBundle mainBundle]];
                    
                    MVC22.navigationItem.title = @"Submit Cell Report";
                    MVC22.theDayOfTheWeek = theWeek;
                    MVC22.delegate = self;
                    UINavigationController *navController =
                    [[UINavigationController alloc]
                     initWithRootViewController:MVC22];
                    
                    UIPopoverController *popover =
                    [[UIPopoverController alloc]
                     initWithContentViewController:navController];
                    
                    popover.delegate = self;
                    
                    self.popoverController4 = popover;
                    
                }
                
                CGRect popoverRect = [self.view convertRect:[summaryButton frame] fromView:[summaryButton superview]];
                
                popoverRect.size.width = MIN(popoverRect.size.width, 99);
                
                [self.popoverController4 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
                

                
                
            }
    
            else
                if ([theButtonSelected isEqualToString:@"prev"]){
                    
                    [summaryButton setImage:[UIImage imageNamed:@"btn_summary_on.png"] forState:UIControlStateNormal];
                    
                    if(thePageValue < 1 || thePageValue == 1){
                        
                        NSString *title = @"You are currently on the first page, please select the next button to proceed to the next page. Thank You";
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        
                        [alert show];
                        
                    }
                    
                    else{
                        
                        thePageValue-=10 ;
                        
                    NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
                    
                    [self retrieveCellMembers:thePageSizeValue theCounerValue:thecounter];
                        
                        [[NSUserDefaults standardUserDefaults] setInteger:thePageValue forKey: @"thesetpagevalue"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                        
                    }
                }
    
                else
                    if ([theButtonSelected isEqualToString:@"next"]){
                        
                        [summaryButton setImage:[UIImage imageNamed:@"btn_summary_on.png"] forState:UIControlStateNormal];
                        
                        thePageValue+=10 ;
                        
                        NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
                        
                        [self retrieveCellMembers:thePageSizeValue theCounerValue:thecounter];
                        
                        [[NSUserDefaults standardUserDefaults] setInteger:thePageValue forKey: @"thesetpagevalue"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                    }

}

- (IBAction)generateReport:(id)sender {
    
    
    GenerateReportViewController *witness =[[GenerateReportViewController alloc] initWithNibName:@"GenerateReportViewController" bundle:nil];
    witness.delegate = self;
    witness.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    witness.modalPresentationStyle = UIModalPresentationFormSheet;
    [self presentViewController:witness animated:YES completion:nil];
    
}

-(IBAction)cellReportHeaderButtonAction:(id)sender{
    
   NSString *theButtonSelected = [[sender titleLabel] text];
    
    if([theButtonSelected isEqualToString:@"theMonth"]){
        
        NSLog(@"you selected %@", theButtonSelected);
    }
    
    else
        if([theButtonSelected isEqualToString:@"edit"]){
            
            if(theEditButtonChecker == 0){
                
                 NSLog(@"you want to edit ohh");
            [editButton setImage:[UIImage imageNamed:@"submitedit.png"] forState:UIControlStateNormal];
                
                if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
                    
                    //[cellLeadersComment ]
                    [cellLeadersComment setEditable:YES];
                    [pastorsComment setEditable:NO];
                }
                else
                    
                    if([mainrole isEqualToString:@"Pastor"] || [subrole isEqualToString:@"Pastor"]){
                        
                        [pastorsComment setEditable:YES];
                        [cellLeadersComment setEditable:NO];
                    }
                
                
                theEditButtonChecker = 1;
                
            }
            else
                if(theEditButtonChecker == 1){
                    
                    NSLog(@"you want to save ohh");
            [editButton setImage:[UIImage imageNamed:@"editreport.png"] forState:UIControlStateNormal];
                    
                    if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
                        
                        [cellLeadersComment setEditable:NO];
                        [self updateCellReport:theReportID];
                    }
                    else
                    if([mainrole isEqualToString:@"Pastor"] || [subrole isEqualToString:@"Pastor"]){
                        
                        [pastorsComment setEditable:NO];
                        [self updateCellReport:theReportID];
                    }
                    //cellLeadersComment.editable
                    theEditButtonChecker = 0;
                    
                }
            
            
            
           
        }
    
    else
        if([theButtonSelected isEqualToString:@"graph"]){
            
            NSLog(@"you selected %@", theButtonSelected);
            
            NSString *title = @"Coming Soon";
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            
            [alert show];
        }
    
        else
            if([theButtonSelected isEqualToString:@"summary"]){
                
                [editButton setHidden:YES];
                [cellReportTable setHidden:NO];
                
                [activityNameLabel setText:@"Statistics"];
                
                //[self animateStatisticView:nil finished:nil context:nil];
                NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue_report];
                
                [self retrieveCellReport:thePageSizeValue_report theCounerValue:thecounter];
                
            }
    
            else
                if([theButtonSelected isEqualToString:@"prev"]){
                    
                    [editButton setHidden:YES];
                    [cellReportTable setHidden:NO];
                    
                    [activityNameLabel setText:@"Statistics"];
                    
                    if(thePageValue_report < 1 || thePageValue_report == 1){
                        
                        NSString *title = @"You are currently on the first page, please select the next button to proceed to the next page. Thank You";
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        
                        [alert show];
                        
                    }
                    
                    else{
                        
                        thePageValue_report-=10 ;
                        
                        NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue_report];
                        
                        [self retrieveCellReport:thePageSizeValue_report theCounerValue:thecounter];
                        
                        [[NSUserDefaults standardUserDefaults] setInteger:thePageValue_report forKey: @"thesetpagevalue_report"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                        
                    }

                    
                }
    
                else
                    if([theButtonSelected isEqualToString:@"next"]){
                        
                        [editButton setHidden:YES];
                        [cellReportTable setHidden:NO];
                        
                        [activityNameLabel setText:@"Statistics"];
                        
                        thePageValue_report+=10 ;
                        
                        NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue_report];
                        
                        [self retrieveCellReport:thePageSizeValue_report theCounerValue:thecounter];
                        
                        [[NSUserDefaults standardUserDefaults] setInteger:thePageValue_report forKey: @"thesetpagevalue_report"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                        
                    }
}

-(void)determineWeek{
    
    NSCalendar *calendar = [NSCalendar autoupdatingCurrentCalendar];
    
    NSDate *today = [NSDate date];
    NSDateFormatter *tempFormatter = [[NSDateFormatter alloc]init];
    [tempFormatter setDateFormat:@"dd-MM-yyyy HH:mm:ss"];
    NSString *dateString = [tempFormatter stringFromDate:today];
    NSDate *pickerDate = [tempFormatter dateFromString:dateString];
    
    NSDateComponents *dateComponents = [calendar components:( NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit )
												   fromDate:pickerDate];
    
    int theDay = [dateComponents day] ;
    //int theMonth = [dateComponents month];
    //int theYear = [dateComponents year];
    
    //NSLog(@"day is %d, month is %d, year is %d", theDay, theMonth, theYear);
    
    //int theWeek = theDay / 7 ;
    
    NSRange firstweek = NSMakeRange(1, 7);
    NSRange secondweek = NSMakeRange(8, 7);
    NSRange thirdweek = NSMakeRange(15, 7);
    NSRange fourthweek = NSMakeRange(22, 7);
    NSRange fifthweek = NSMakeRange(29, 7);
    
    if (NSLocationInRange(theDay, firstweek)) {
        
        [activityWeek1 setImage:[UIImage imageNamed:@"ic_cell_wk1_on.png"]];
        [activityWeek2 setImage:[UIImage imageNamed:@"ic_cell_wk2_off.png"]];
        [activityWeek3 setImage:[UIImage imageNamed:@"ic_cell_wk3_off.png"]];
        [activityWeek4 setImage:[UIImage imageNamed:@"ic_cell_wk4_off.png"]];
        [activityWeek5 setImage:[UIImage imageNamed:@"ic_cell_wk5_off.png"]];
        
        theWeek = 1;

    }
    else
        
    if (NSLocationInRange(theDay, secondweek)) {
        
        [activityWeek1 setImage:[UIImage imageNamed:@"ic_cell_wk1_off.png"]];
        [activityWeek2 setImage:[UIImage imageNamed:@"ic_cell_wk2_on.png"]];
        [activityWeek3 setImage:[UIImage imageNamed:@"ic_cell_wk3_off.png"]];
        [activityWeek4 setImage:[UIImage imageNamed:@"ic_cell_wk4_off.png"]];
        [activityWeek5 setImage:[UIImage imageNamed:@"ic_cell_wk5_off.png"]];
        
        theWeek = 2;
        
    }
    
    else
        
        if (NSLocationInRange(theDay, thirdweek)) {
            
            [activityWeek1 setImage:[UIImage imageNamed:@"ic_cell_wk1_off.png"]];
            [activityWeek2 setImage:[UIImage imageNamed:@"ic_cell_wk2_off.png"]];
            [activityWeek3 setImage:[UIImage imageNamed:@"ic_cell_wk3_on.png"]];
            [activityWeek4 setImage:[UIImage imageNamed:@"ic_cell_wk4_off.png"]];
            [activityWeek5 setImage:[UIImage imageNamed:@"ic_cell_wk5_off.png"]];
            
            theWeek = 3;
        }
        else
            
            if (NSLocationInRange(theDay, fourthweek)) {
                
                [activityWeek1 setImage:[UIImage imageNamed:@"ic_cell_wk1_off.png"]];
                [activityWeek2 setImage:[UIImage imageNamed:@"ic_cell_wk2_off.png"]];
                [activityWeek3 setImage:[UIImage imageNamed:@"ic_cell_wk3_off.png"]];
                [activityWeek4 setImage:[UIImage imageNamed:@"ic_cell_wk4_on.png"]];
                [activityWeek5 setImage:[UIImage imageNamed:@"ic_cell_wk5_off.png"]];
                
                theWeek = 4;
            }
    
            else
                
                if (NSLocationInRange(theDay, fifthweek)) {
                    
                    [activityWeek1 setImage:[UIImage imageNamed:@"ic_cell_wk1_off.png"]];
                    [activityWeek2 setImage:[UIImage imageNamed:@"ic_cell_wk2_off.png"]];
                    [activityWeek3 setImage:[UIImage imageNamed:@"ic_cell_wk3_off.png"]];
                    [activityWeek4 setImage:[UIImage imageNamed:@"ic_cell_wk4_off.png"]];
                    [activityWeek5 setImage:[UIImage imageNamed:@"ic_cell_wk5_on.png"]];
                    
                    theWeek = 5;
                }

    
    /**NSDateComponents *dateComps = [[NSDateComponents alloc] init];
    [dateComps setDay:[dateComponents day]];
    [dateComps setMonth:[dateComponents month]];
    [dateComps setYear:[dateComponents year]];**/
    
    
}

/**-(void)submissionCompleted:(NSNumber*)theCountry{
    
    NSLog(@"this is the number id ohh %@", theCountry);
    
    [self.popoverController3 dismissPopoverAnimated:YES];
}**/


-(void)submissionCompleted:(NSNumber*)theCountry theUserFirstname:(NSString*)theFirstname theUserLastname:(NSString*)theLastname{
    
   // NSLog(@"these are the values FirstName:%@, LastName:%@, theEntityNumber:%@", theFirstname, theLastname, theCountry);
    
    [self.popoverController3 dismissPopoverAnimated:YES];
    
    NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
    
    [self retrieveCellMembers:thePageSizeValue theCounerValue:thecounter];
    
    
    //[theDetailTable reloadData];
    
}


-(void)addRecordToTable:(NSString*)theFirstname theUserLastname:(NSString*)theLastname theUserTitle:(NSString*)theTitle;{
    
    //NSLog(@"these are the values FirstName:%@, LastName:%@", theFirstname, theLastname);
    
    //NSString *theCellMemberName = [theTitle stringByAppendingString:[NSString stringWithFormat:@" %@ %@", theLastname, theFirstname]];
    
    //[cellMembersNameArray addObject:theCellMemberName];
}

-(void)activateTheIndicator{
    
    [theLoadingIndicator startAnimating];

}

-(void)deActivateTheIndicator{
    
    [theLoadingIndicator stopAnimating];
}

-(void)deActivateThePopup{
    if(self.popoverController4 != nil){
        [self.popoverController4 dismissPopoverAnimated:YES];
    }
    
    
    NSString *fileName4 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk1.txt"];
    
    NSString *fileName5 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk2.txt"];
    
    NSString *fileName6 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk3.txt"];
    
    NSString *fileName7 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk4.txt"];
    
    NSString *fileName8 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk5.txt"];
    
    
    
        cellMembersPresentwk1 = [[NSMutableArray alloc] initWithContentsOfFile:fileName4];
    
    
   
        cellMembersPresentwk2 = [[NSMutableArray alloc] initWithContentsOfFile:fileName5];
    
    
   
        cellMembersPresentwk3 = [[NSMutableArray alloc] initWithContentsOfFile:fileName6];
    
    
        cellMembersPresentwk4 = [[NSMutableArray alloc] initWithContentsOfFile:fileName7];
    
        cellMembersPresentwk5 = [[NSMutableArray alloc] initWithContentsOfFile:fileName8];
    
    [theDetailTable reloadData];
    
    
}

-(void)openTheReport:(NSString*)theReport theReportName:(NSString*)reportName{
    
    NSLog(@"the report name %@", reportName);
    
    //NSCalendar *calendar = [NSCalendar autoupdatingCurrentCalendar];
    
    NSDate *today = [NSDate date];
    NSDateFormatter *tempFormatter = [[NSDateFormatter alloc]init];
    [tempFormatter setDateFormat:@"dd-MM-yyyy HH-mm-ss"];
    NSString *dateString = [tempFormatter stringFromDate:today];
   // NSDate *pickerDate = [tempFormatter dateFromString:dateString];
    
    //NSDateComponents *dateComponents = [calendar components:( NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit )
												  // fromDate:pickerDate];
    
    /***int theDay = [dateComponents day] ;
    int theMonth = [dateComponents month];
    int theYear = [dateComponents year];
    int theTime = [dateComponents timeZone];**/
    
    NSString *theReportDate = dateString;//[NSString stringWithFormat:@"%d_%d_%d", theDay, theMonth, theYear];
    
    //NSLog(@"this is the date %@", theReportDate);
    

    
    NSData *data = [self base64DataFromString:theReport];
    
    NSFileHandle *handleFile;
    
    NSString *theFileName;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0]; // Get documents folder
    NSString *audioPath = [documentsDirectory stringByAppendingPathComponent:@"Report Library"];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:audioPath])
        [[NSFileManager defaultManager] createDirectoryAtPath:audioPath withIntermediateDirectories:NO attributes:nil error:nil];
    
    theFileName = [reportName stringByAppendingString:[NSString stringWithFormat:@"(%@).pdf", theReportDate]];
    
    theBookToBeDisplayed = [reportName stringByAppendingString:[NSString stringWithFormat:@"(%@)", theReportDate]];
    
    NSLog(@"the report to be displayed %@", theBookToBeDisplayed);
    
    NSString *filePath = [NSString stringWithFormat:@"%@/%@",audioPath, theFileName];
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        [[NSFileManager defaultManager] createFileAtPath:filePath contents:nil attributes:nil];
    }
    
    handleFile = [NSFileHandle fileHandleForWritingAtPath:filePath];
    
    //NSData *plainTextData = [theValue dataUsingEncoding:NSUTF8StringEncoding];
    
    [handleFile writeData:data];
   
    
    /**if(handleFile ){
        
        
    }**/
    
    NSURL *url22 = [NSURL fileURLWithPath:filePath];
	NSURLRequest *urlReq = [[NSURLRequest alloc] initWithURL:url22];
	[scoreCardViewer loadRequest:urlReq];
    [theScoreCardLabel setText:theBookToBeDisplayed];
    [theScoreCardView setHidden:NO];
    
    
}


-(void)openTheReportArchive:(NSString*)theReport{
    
    theBookToBeDisplayed = theReport;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0]; // Get documents folder
    NSString *audioPath = [documentsDirectory stringByAppendingPathComponent:@"Report Library"];
    
    NSString *filePath = [NSString stringWithFormat:@"%@/%@.pdf",audioPath, theReport];
    
    NSURL *url22 = [NSURL fileURLWithPath:filePath];
	NSURLRequest *urlReq = [[NSURLRequest alloc] initWithURL:url22];
	[scoreCardViewer loadRequest:urlReq];
    [theScoreCardLabel setText:theBookToBeDisplayed];
    [theScoreCardView setHidden:NO];
    
}


- (NSData *)base64DataFromString: (NSString *)string
{
    unsigned long ixtext, lentext;
    unsigned char ch, inbuf[4], outbuf[3];
    short i, ixinbuf;
    Boolean flignore, flendtext = false;
    const unsigned char *tempcstring;
    NSMutableData *theData;
    
    if (string == nil)
    {
        return [NSData data];
    }
    
    ixtext = 0;
    
    tempcstring = (const unsigned char *)[string UTF8String];
    
    lentext = [string length];
    
    theData = [NSMutableData dataWithCapacity: lentext];
    
    ixinbuf = 0;
    
    while (true)
    {
        if (ixtext >= lentext)
        {
            break;
        }
        
        ch = tempcstring [ixtext++];
        
        flignore = false;
        
        if ((ch >= 'A') && (ch <= 'Z'))
        {
            ch = ch - 'A';
        }
        else if ((ch >= 'a') && (ch <= 'z'))
        {
            ch = ch - 'a' + 26;
        }
        else if ((ch >= '0') && (ch <= '9'))
        {
            ch = ch - '0' + 52;
        }
        else if (ch == '+')
        {
            ch = 62;
        }
        else if (ch == '=')
        {
            flendtext = true;
        }
        else if (ch == '/')
        {
            ch = 63;
        }
        else
        {
            flignore = true;
        }
        
        if (!flignore)
        {
            short ctcharsinbuf = 3;
            Boolean flbreak = false;
            
            if (flendtext)
            {
                if (ixinbuf == 0)
                {
                    break;
                }
                
                if ((ixinbuf == 1) || (ixinbuf == 2))
                {
                    ctcharsinbuf = 1;
                }
                else
                {
                    ctcharsinbuf = 2;
                }
                
                ixinbuf = 3;
                
                flbreak = true;
            }
            
            inbuf [ixinbuf++] = ch;
            
            if (ixinbuf == 4)
            {
                ixinbuf = 0;
                
                outbuf[0] = (inbuf[0] << 2) | ((inbuf[1] & 0x30) >> 4);
                outbuf[1] = ((inbuf[1] & 0x0F) << 4) | ((inbuf[2] & 0x3C) >> 2);
                outbuf[2] = ((inbuf[2] & 0x03) << 6) | (inbuf[3] & 0x3F);
                
                for (i = 0; i < ctcharsinbuf; i++)
                {
                    [theData appendBytes: &outbuf[i] length: 1];
                }
            }
            
            if (flbreak)
            {
                break;
            }
        }
    }
    
    return theData;
    
}


-(NSString *) base64StringFromData:(NSString *)str
{
    
    NSData* data=[str dataUsingEncoding:NSUTF8StringEncoding];
    int length = str.length;
    
    unsigned long ixtext, lentext;
    long ctremaining;
    unsigned char input[3], output[4];
    short i, charsonline = 0, ctcopy;
    const unsigned char *raw;
    NSMutableString *result;
    
    lentext = [data length];
    if (lentext < 1)
        return @"";
    result = [NSMutableString stringWithCapacity: lentext];
    raw = [data bytes];
    ixtext = 0;
    
    while (true) {
        ctremaining = lentext - ixtext;
        if (ctremaining <= 0)
            break;
        for (i = 0; i < 3; i++) {
            unsigned long ix = ixtext + i;
            if (ix < lentext)
                input[i] = raw[ix];
            else
                input[i] = 0;
        }
        output[0] = (input[0] & 0xFC) >> 2;
        output[1] = ((input[0] & 0x03) << 4) | ((input[1] & 0xF0) >> 4);
        output[2] = ((input[1] & 0x0F) << 2) | ((input[2] & 0xC0) >> 6);
        output[3] = input[2] & 0x3F;
        ctcopy = 4;
        switch (ctremaining) {
            case 1:
                ctcopy = 2;
                break;
            case 2:
                ctcopy = 3;
                break;
        }
        
        for (i = 0; i < ctcopy; i++)
            [result appendString: [NSString stringWithFormat: @"%c", base64EncodingTable[output[i]]]];
        
        for (i = ctcopy; i < 4; i++)
            [result appendString: @"="];
        
        ixtext += 3;
        charsonline += 4;
        
        if ((length > 0) && (charsonline >= length))
            charsonline = 0;
    }
    return result;
}




- (void)userLogin{
	
	LoginViewController *login =[[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
	UINavigationController *tatNavcon2 = [[UINavigationController alloc] initWithRootViewController:login];
	tatNavcon2.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	tatNavcon2.modalPresentationStyle = UIModalPresentationFullScreen;
	[self presentViewController:tatNavcon2 animated:YES completion:nil];
	
	
}

#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem
{
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
        
        // Update the view.
        [self configureView];
    }

    if (self.masterPopoverController != nil) {
        [self.masterPopoverController dismissPopoverAnimated:YES];
    }        
}

- (void)configureView
{
    // Update the user interface for the detail item.

    if (self.detailItem) {
        self.detailDescriptionLabel.text = [self.detailItem description];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)getFrameForRotation
{
    if (self.interfaceOrientation == UIInterfaceOrientationPortrait || self.interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) {
        
        [buttonForMastersView setHidden:NO];
        
        
		
    }
    else
        if(self.interfaceOrientation == UIInterfaceOrientationLandscapeLeft || self.interfaceOrientation == UIInterfaceOrientationLandscapeRight){
            
            [buttonForMastersView setHidden:YES];
            
        }
	
}


- (void)viewDidLoad
{
  
    
    thePageSizeValue = @"11";
    thePageSizeValue_report = @"11";
    
    thePageValue_report = [[NSUserDefaults standardUserDefaults] integerForKey: @"thesetpagevalue_report"];
    thePageValue = [[NSUserDefaults standardUserDefaults] integerForKey: @"thesetpagevalue"];
    
    if(thePageValue == 0){
    thePageValue = 1;
        
    }
    
    if(thePageValue_report == 0){
        thePageValue_report = 1;
        
    }
    self.navigationController.navigationBarHidden = YES;
    [self determineWeek];
    /**theUserName = [[NSUserDefaults standardUserDefaults] valueForKey: @"username"];
    
    if (theUserName.length == 0) {
          [self userLogin];
    }
    else{
        NSString *theLabelValue = [NSString stringWithFormat:@"Welcome %@", theUserName];
        [welcomeLabel setText:theLabelValue];
    }**/
  
    NSLog(@"the entity value %@", theentityName);
    [self getFrameForRotation];
    
   
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
   // [self configureView];
}

-(void)viewDidAppear:(BOOL)animated{
    
    //[self retrieveCellMembers:@"5" theCounerValue:@"1"];
    
    
    
    
    cellLeaderReadReportEntityValue = [[NSUserDefaults standardUserDefaults] valueForKey: @"reportscreenentity"];
    theUserId = [[NSUserDefaults standardUserDefaults] valueForKey: @"theuserid"];
    theUserName = [[NSUserDefaults standardUserDefaults] valueForKey: @"username"];
    theEntityValue = [[NSUserDefaults standardUserDefaults] valueForKey: @"screenentity"];
    encodedusername = [[NSUserDefaults standardUserDefaults] valueForKey: @"encodedlogindetails"];
    mainrole = [[NSUserDefaults standardUserDefaults] valueForKey: @"mainrole"];
    subrole = [[NSUserDefaults standardUserDefaults] valueForKey: @"subrole"];
    userHasLogedIn =  [[NSUserDefaults standardUserDefaults] integerForKey: @"loginindicator"];
    theCellReportViewingEntity =  [[NSUserDefaults standardUserDefaults] valueForKey: @"cellreportviewingentity"];  
    
    NSLog(@"this is the main role %@",mainrole);
    
    if (theUserName.length == 0) {
        [self userLogin];
    }
    else{
        NSString *theLabelValue = [NSString stringWithFormat:@"Welcome %@", theUserName];
        [welcomeLabel setText:theLabelValue];
        [activityNameLabel setText:@"Cell Activity"];
    }
    
   // theUsername_ForStorage = [theUserName stringByReplacingOccurrencesOfString:@" " withString:@""];
    //NSLog(@"the user id is %@", theUserId);
    
    if([subrole isEqualToString:@"Pastor"]|| [mainrole isEqualToString:@"Pastor"]){
        
        [editButton setHidden:YES];
        [cellReportTable setHidden:NO];
        
        [activityNameLabel setText:@"Weekly Cell Reports"];
        
        [self animateStatisticView:nil finished:nil context:nil];
        
        NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
        
        [self retrieveCellReport:thePageSizeValue theCounerValue:thecounter];
        
    }
    
    else {
        
        [activityNameLabel setText:@"Cell Activity"];
        
        [self animateCellLeaderView:nil finished:nil context:nil];
    
NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmembernames.txt"];
NSString *fileName2 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmemberimages.txt"];
NSString *fileName3 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmemberrankings.txt"];
        
  NSString *fileName4 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk1.txt"];
        
         NSString *fileName5 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk2.txt"];
    
 NSString *fileName6 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk3.txt"];
        
         NSString *fileName7 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk4.txt"];
        
         NSString *fileName8 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellattendancewk5.txt"];
        
        
    if(cellMembersPresentwk1 == nil){
            cellMembersPresentwk1 = [[NSMutableArray alloc] initWithContentsOfFile:fileName4];
        }
        
        if(cellMembersPresentwk2 == nil){
            cellMembersPresentwk2 = [[NSMutableArray alloc] initWithContentsOfFile:fileName5];
        }
        
        if(cellMembersPresentwk3 == nil){
            cellMembersPresentwk3 = [[NSMutableArray alloc] initWithContentsOfFile:fileName6];
        }
        
        if(cellMembersPresentwk4 == nil){
            cellMembersPresentwk4 = [[NSMutableArray alloc] initWithContentsOfFile:fileName7];
        }
        
        if(cellMembersPresentwk5 == nil){
            cellMembersPresentwk5 = [[NSMutableArray alloc] initWithContentsOfFile:fileName8];
        }
        
    
    if(cellMembersNameArray == nil){
    cellMembersNameArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName];
    }
    
    if(cellMembersImageArray == nil){
    cellMembersImageArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName2];
        
    }
    
    if(cellMembersRankingArray == nil){
    cellMembersRankingArray = [[NSMutableArray alloc] initWithContentsOfFile:fileName3];
    }
    
    [super viewDidAppear:YES];
    
   /** for(NSString* thevalues in cellMembersNameArray){
        
        NSLog(@"these are the array values %@", thevalues);
    }**/
    
    [theDetailTable reloadData];
    
    if(userHasLogedIn == 1){
        
        
        NSString *thecounter = [NSString stringWithFormat:@"%d", thePageValue];
        
        [self retrieveCellMembers:thePageSizeValue theCounerValue:thecounter];
        
        userHasLogedIn = 2;
        
        [[NSUserDefaults standardUserDefaults] setInteger:userHasLogedIn forKey: @"loginindicator"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }
    
    }
}


-(void)textViewDidBeginEditing:(UITextView *)textView{
    if (textView.tag == 1){
        theEditingView = @"cellleaderview";
        //NSLog(@"you want to edit the cell leaders comment");
        [self animateTheTextViewsForEditing:nil finished:nil context:nil];
    }
    else
        if (textView.tag == 2){
            theEditingView = @"pculeaderview";
            [self animateTheTextViewsForEditing:nil finished:nil context:nil];
            //NSLog(@"you want to edit the pcu leaders comment");
        }
    
    else
        if (textView.tag == 3){
            theEditingView = @"pastorview";
            [self animateTheTextViewsForEditing:nil finished:nil context:nil];
            //NSLog(@"you want to edit the pastors leaders comment");
        }


    
}

-(void)textViewDidEndEditing:(UITextView *)textView{
    
    if (textView.tag == 1){
        
        theEditingView = @"cellleaderview";
        
        [self animateReturnofTheTextViewsAfterEditing:nil finished:nil context:nil];
        
       // NSLog(@"you have edited the cell leaders comment");
    }
    else
        if (textView.tag == 2){
            
            theEditingView = @"pculeaderview";
            [self animateReturnofTheTextViewsAfterEditing:nil finished:nil context:nil];
            
            //NSLog(@"you have edited the pcu leaders comment");
        }
    
        else
            if (textView.tag == 3){
                
                theEditingView = @"pastorview";
                [self animateReturnofTheTextViewsAfterEditing:nil finished:nil context:nil];
                
                //NSLog(@"you have edited the pastors leaders comment");
            }
    

    
    
}

- (void)animateCellLeaderView:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    NSLog(@"Ÿou are on potrait mode bro!");
    [UIView animateWithDuration:1.0
                          delay:0.0
                        options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                     animations:^{
                         
                           if(theOrientationChecker == 1){
                         cellLeadersBodyView.center = CGPointMake(384, 498);
                         //pastorsView.center = CGPointMake(1152, 498);
                         statisticsView.center = CGPointMake(1152, 498);
                               
                           }
                         
                           else
                               if(theOrientationChecker == 2){
                                   
                                   cellLeadersBodyView.center = CGPointMake(353, 370);
                                   //pastorsView.center = CGPointMake(429, 1358);
                                   statisticsView.center = CGPointMake(1258, 370);
                                   
                               }
                         //articleView.center = CGPointMake(1152, 497);
                         //theBookView.center = CGPointMake(384, 497);
                         
                     }
                     completion:^(BOOL finished){
                         NSLog(@"Move to left done");
                         
                     }];
    
}



- (void)animatePastroView:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    [UIView animateWithDuration:1.0
                          delay:0.0
                        options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                     animations:^{
                         
                         
                         cellLeadersBodyView.center = CGPointMake(-384, 498);
                         pastorsView.center = CGPointMake(384, 498);
                         //articleView.center = CGPointMake(384, 497);
                         //theBookView.center = CGPointMake(-384, 497);
                         
                     }
                     completion:^(BOOL finished){
                         NSLog(@"Move to left done");
                     }];
    
    
    
}

- (void)animateStatisticView:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    [UIView animateWithDuration:1.0
                          delay:0.0
                        options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                     animations:^{
                         
                         //if([mainrole isEqualToString:@""]){
                         if(theOrientationChecker == 1){
                             cellLeadersBodyView.center = CGPointMake(-384, 498);
                             //pastorsView.center = CGPointMake(1152, 498);
                         statisticsView.center = CGPointMake(384, 498);
                             
                         }
                        else
                            if(theOrientationChecker == 2){
                                
                                cellLeadersBodyView.center = CGPointMake(-353, 370);
                                //pastorsView.center = CGPointMake(1358, 429);
                                statisticsView.center = CGPointMake(353, 370);
                                
                            }
                         
                     }
                     completion:^(BOOL finished){
                         NSLog(@"Move to left done");
                     }];
    

}


- (void)animateTheTextViewsForEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    if([theEditingView isEqualToString:@"cellleaderview" ]){
        
        [UIView animateWithDuration:1.0
                              delay:0.0
                            options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                         animations:^{
                             
                          
                             
                         }
                         completion:^(BOOL finished){
                             NSLog(@"Move to left done");
                         }];

        
        //NSLog(@"we are animating the cell leaders view");
    }
    else
        if([theEditingView isEqualToString:@"pculeaderview" ]){
            
            [UIView animateWithDuration:0.7
                                  delay:0.0
                                options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                             animations:^{
                                 
                        pcuLeadersComment.center = CGPointMake(604, 630);
  
                                 
                             }
                             completion:^(BOOL finished){
                                 NSLog(@"Move to left done");
                             }];

            //NSLog(@"we are animating the cell leaders view");
        }
    else
        if([theEditingView isEqualToString:@"pastorview" ]){
            
            [UIView animateWithDuration:0.7
                                  delay:0.0
                                options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                             animations:^{
                                 
                                 pastorsComment.center = CGPointMake(604, 630);
                                 
                                 
                             }
                             completion:^(BOOL finished){
                                 NSLog(@"Move to left done");
                             }];

            //NSLog(@"we are animating the cell leaders view");
        }
    
    
}

- (void)animateReturnofTheTextViewsAfterEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
    
    if([theEditingView isEqualToString:@"cellleaderview" ]){
        
        [UIView animateWithDuration:1.0
                              delay:0.0
                            options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                         animations:^{
                             
                             cellLeadersComment.center = CGPointMake(394, 569);
                             
                         }
                         completion:^(BOOL finished){
                             NSLog(@"Move to left done");
                         }];
        
        
        //NSLog(@"we are animating the cell leaders view");
    }
    else
        if([theEditingView isEqualToString:@"pculeaderview" ]){
            
            [UIView animateWithDuration:1.0
                                  delay:0.0
                                options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                             animations:^{
                                 
                                 pcuLeadersComment.center = CGPointMake(394, 697);
                                 
                             }
                             completion:^(BOOL finished){
                                 NSLog(@"Move to left done");
                             }];
            
            //NSLog(@"we are animating the cell leaders view");
        }
        else
            if([theEditingView isEqualToString:@"pastorview" ]){
                
                [UIView animateWithDuration:1.0
                                      delay:0.0
                                    options:(UIViewAnimationCurveEaseInOut|UIViewAnimationOptionAllowUserInteraction)
                                 animations:^{
                                     
                                     pastorsComment.center = CGPointMake(394, 832);
                                     
                                 }
                                 completion:^(BOOL finished){
                                     NSLog(@"Move to left done");
                                 }];
                
                //NSLog(@"we are animating the cell leaders view");
            }

    
    
}


- (void)initForCreate{
    
    NSError* error;
    theURLRequestChecker = 1;
    
    [theLoadingIndicator startAnimating];
  
    @try{
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"init", @"mode", nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=create&content=%@", encodedusername, theJsonString];
        
        //online
       NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123/%@/create/", theEntityValue]]];
        
        //local
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.3:8000/%@/create/", theEntityValue]]];
        
       // NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
      
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
       [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
 
    
    
}

-(void)detailCellReportRead:(NSString*)theId{
    
    NSError* error;
    theURLRequestChecker = 5;
    //NSNumber* thevalue = [NSNumber numberWithInt:14];
    [theLoadingIndicator startAnimating];
   // NSLog(@"the entity is %@", cellLeaderReadReportEntityValue);

    @try{
        
         //NSArray *entitySpecValue = [[NSArray alloc] initWithObjects:@"total_attendance", @"name",@"members_attendance",@"offering",@"id", nil];
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys: theId,
                              @"entityId",theCellReportViewingEntity, @"entityName", /**entitySpecValue,@"entitySpec",**/ nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=read&content=%@", encodedusername, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123:80/%@/detailread/", cellLeaderReadReportEntityValue]]];
        
        
        //local
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.3:8000/%@/detailread/", cellLeaderReadReportEntityValue]]];
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    

    
}

-(void)updateCellReport:(NSString*)theId{
    
    NSError* error;
    theURLRequestChecker = 6;
    //NSNumber* thevalue = [NSNumber numberWithInt:14];
    [theLoadingIndicator startAnimating];
    NSLog(@"the entity is %@", cellLeaderReadReportEntityValue);
    NSDictionary* entitySpecValue;
    
    @try{
        
        //NSArray *entitySpecValue = [[NSArray alloc] initWithObjects:@"total_attendance", @"name",@"members_attendance",@"offering",@"id", nil];
        
        if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
          
            entitySpecValue = [NSDictionary dictionaryWithObjectsAndKeys: cellLeadersComment.text, @"cell_leaders_comment", nil];
        }
        else
            
            if([mainrole isEqualToString:@"Pastor"] || [subrole isEqualToString:@"Pastor"]){
                
                entitySpecValue = [NSDictionary dictionaryWithObjectsAndKeys: pastorsComment.text, @"final_comment", nil];
               
            }
        
        
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys: theId,
                              @"entityId", entitySpecValue,@"entitySpec", nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=update&content=%@", encodedusername, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123:80/%@/update/", cellLeaderReadReportEntityValue]]];
        
        
        //local
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.3:8000/%@/update/", cellLeaderReadReportEntityValue]]];
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    
}

-(void)detailCellMemberRead:(NSString*)theId{
    
    
    
}

-(void)retrieveCellMembers:(NSString*)pageSize theCounerValue:(NSString*)conter{
    
    
    NSError* error;
    theURLRequestChecker = 3;
    
    [theLoadingIndicator startAnimating];
    
    @try{
        
        //NSArray *entitySpecValue = [[NSArray alloc] initWithObjects:@"first_name", @"last_name",@"title", nil];
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:pageSize,
                              @"pageSize", conter,@"firstCount", @"id", @"sortField", @"desc", @"sort", nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=read&content=%@", encodedusername, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123:80/%@/read/", theEntityValue]]];
        
        
        //local
        
       // NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.101:8000/%@/read/", theEntityValue]]];
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    

    
}


-(void)retrieveCellReport:(NSString*)pageSize theCounerValue:(NSString*)conter{
   
    
    NSError* error;
    theURLRequestChecker = 4;
    
    [theLoadingIndicator startAnimating];
    
    @try{
        
       // NSArray *entitySpecValue = [[NSArray alloc] initWithObjects:@"total_attendance", @"name",@"members_attendance",@"offering",@"id", nil];
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:pageSize,
                              @"pageSize", conter,@"firstCount", @"id", @"sortField", @"desc", @"sort",/**entitySpecValue,@"entitySpec",**/ nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=read&content=%@", encodedusername, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123:80/%@/read/", cellLeaderReadReportEntityValue]]];
        
        
        //local
        
       // NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.3:8000/%@/read/", cellLeaderReadReportEntityValue]]];
        
        //NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    

    
}


-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    
    [webData appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    NSLog(@"ERROR with theConnection");
    NSLog(@"%@", error);
    
    NSString *title = @"There is an issue connecting to the internet at this time, please try again. Thank You";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];
    
    [theLoadingIndicator stopAnimating];
}

-(void)connectionDidFinishLoading:(NSURLConnection *) connection{
    
    NSLog(@"DONE, recieved Bytes: %d", [webData length]);
    
    [theLoadingIndicator stopAnimating];
    
    if (theURLRequestChecker == 1) {
        [self interpreteTheData:webData];
    }
    
    if (theURLRequestChecker == 3) {
        [self interpreteTheReadData:webData];
    }
    
    if (theURLRequestChecker == 4) {
        [self interpreteCellReportReadData:webData];
    }

  if (theURLRequestChecker == 5) {
   
      [self interpreteDetailCellReportRead:webData];
  }
    
    if (theURLRequestChecker == 6) {
        
        [self interpreteUpdatedCellReport:webData];
    }
   
    
    
}

- (void)interpreteTheData:(NSMutableData*)theData{
    
    NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    
    NSLog(@"this is the feed back: %@", theXML);
    
    
}

- (void)interpreteTheReadData:(NSMutableData*)theData{
    
    cellMembersNameArray = [[NSMutableArray alloc] init];
    
     NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cellmembernames.txt"];
    
    //NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    
    //NSLog(@"this is the read feed back: %@", theXML);
    
     NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    NSArray *cellMembersQuerry = [json objectForKey:@"resultSet"];
    
    NSString *resultValue = [json objectForKey:@"result"];
    
    if ([resultValue isEqualToString:@"true"]){
        
        for(NSDictionary* cellrecord in cellMembersQuerry){
            
            //NSString *theTitle = [cellrecord objectForKey:@"title"];
            
            NSString *theName = [cellrecord objectForKey:@"name"];
            
            //NSString *theCombinedRecord = [theTitle stringByAppendingString:[NSString stringWithFormat:@" %@", theName]];
            
            //[cellMembersNameArray addObject:theCombinedRecord];
            
            
            
            [cellMembersNameArray addObject:theName];
            
            
        }
      //  if([cellMembersNameArray count] != 0){
        [cellMembersNameArray writeToFile:fileName atomically:YES];
        [theDetailTable reloadData];
        //}
       /** else
        {
            NSString *title = @"You don't have any member in your cell currently, please use the add member button above to add members, Thank You.";
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            
            [alert show];
        }**/
        //[MVC.theDetailTable reloadData];
       // [MVC viewDidAppear:YES];
    }
    
   // NSLog(@"this is the result %@", resultValue);
    
}

- (void)interpreteCellReportReadData:(NSMutableData*)theData{
    
    
    theCellReports = [[NSMutableArray alloc] init];
    theTotalAttendance = [[NSMutableArray alloc] init];
    theReportTitleAndObject = [[NSMutableDictionary alloc] init];
    cellReportStatus = [[NSMutableArray alloc] init];
    
    //NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    
    //NSLog(@"this is the read feed back: %@", theXML);
    
     NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    NSNumber* resultSet = [json objectForKey:@"resultSize"];
    
    if (resultSet == 0){
        
        NSString *title = @"We are sorry, there are no reports to be displayed at this time.";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
        
        [cellReportTable reloadData];
    }
    
    else{
    
    NSArray *theCellReports22 = [json objectForKey:@"resultSet"];
    
    for(NSDictionary *theOptions in theCellReports22){
        
        NSString* cellReportName = [theOptions objectForKey:@"name"];
        NSNumber* reportID = [theOptions objectForKey:@"id"];
         NSNumber* totalAttendance = [theOptions objectForKey:@"total_attendance"];
        NSString* reportStatus = [theOptions objectForKey:@"status"];
        
        [theCellReports addObject:cellReportName];
        if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
           [theTotalAttendance addObject:totalAttendance]; 
            
        }
        //[theTotalAttendance addObject:totalAttendance];
        [cellReportStatus addObject:reportStatus];
        
        [theReportTitleAndObject setObject:reportID forKey:cellReportName];
        
    }
    
    [cellReportTable reloadData];
    }
}

- (void)interpreteDetailCellReportRead:(NSMutableData*)theData{
    
    cellMembersPresent = [[NSMutableArray alloc] init];
    
    NSDictionary *monthSpec = [NSDictionary dictionaryWithObjectsAndKeys:@"January", @"01",  @"February", @"02",  @"March", @"03",  @"April", @"04", @"May", @"05", @"June", @"06",  @"July", @"7",@"August", @"8", @"September", @"9", @"October", @"10", @"November", @"11", @"December", @"12",  nil];
    
    [editButton setHidden:NO];
    [cellReportTable setHidden:YES];
    [editButton setImage:[UIImage imageNamed:@"editreport.png"] forState:UIControlStateNormal];
    [cellLeadersComment setEditable:NO];
    [pastorsComment setEditable:NO];
    theEditButtonChecker = 0;
    
    //NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
   // NSLog(@"this is the read feed back: %@", theXML);
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    NSArray *detailReadEntities = [json objectForKey:@"resultSet"];
    
    for(NSDictionary* theDetails in detailReadEntities){
        
        NSString* thePropName = [theDetails objectForKey:@"propertyName"];
        NSString* theValues = [theDetails objectForKey:@"value"];
        NSString* theType = [theDetails objectForKey:@"type"];
        
        //NSLog(@"this is the type: %@", theType);
        
        if([thePropName isEqualToString:@"date_of_meeting"]){
            
            NSArray* component = [theValues componentsSeparatedByString:@"-"];
            NSString* theYear = [component objectAtIndex:0];
            NSString* theMonth = [component objectAtIndex:1];
            NSString* theDay = [component objectAtIndex:2];
            
            NSString* theDateString = [theDay stringByAppendingString:[NSString stringWithFormat:@" %@, %@", [monthSpec objectForKey:theMonth], theYear]];
            
            [meetingDateLabel setText:theDateString];
            //NSLog(@"this is the date: %@", theDateString);
            
            continue;
        }
        
        else
         if([thePropName isEqualToString:@"time_of_meeting"]){
             
             [meetingTimeLabel setText:theValues];
             continue;
             
         }
        
         else
             if([thePropName isEqualToString:@"meeting_held"]){
                 
                 [meetingHeldLabel setText:theValues];
                 continue;
                 
             }
             else
                 if([thePropName isEqualToString:@"first_timers_attendance"]){
                     
                     [firstTimersLabel setText:theValues];
                     
                 }
                 else
                     if([theType isEqualToString:@"multiselect"]){
                         
                         //[firstTimersLabel setText:theValues];
                         NSArray* theCellMemb = [theDetails objectForKey:@"value"];
                         for(NSDictionary* themembers in theCellMemb){
                             
                             NSString* theMemberPresent = [themembers objectForKey:@"label"];
                             [cellMembersPresent addObject:theMemberPresent];
                             
                         }
                         
                         [membersPresentTable reloadData];
                     }
                     else
                         if([thePropName isEqualToString:@"new_converts_attendance"]){
            
                             [newConvertsLabel setText:theValues];
            
                         }
                         else
                             if([thePropName isEqualToString:@"follow_up_cards_received"]){
    
                                 [followUpCardsLabel setText:theValues];
    
                             }

                             else

                                 if([thePropName isEqualToString:@"total_first_timers_visited"]){
    
                                     [firstTimersVisitedLabel setText:theValues];
    
                                 }

                                 else

                                     if([thePropName isEqualToString:@"total_first_timers_called"]){
    
                                         [firstTimersCalledLabel setText:theValues];
    
                                     }

                                     else

                                         if([thePropName isEqualToString:@"ministry_materials_target"]){
    
                                             [minMatTarget setText:theValues];
    
                                         }

                                         else

                                             if([thePropName isEqualToString:@"ministry_materials_purchased"]){
    
                                                 [minMatBought setText:theValues];
    
                                             }

                                             else

                                                 if([thePropName isEqualToString:@"partnership_target"]){
    
                                                     [partnershipTarget setText:theValues];
    
                                                 }

                                                 else

                                                     if([thePropName isEqualToString:@"partnership_giving"]){
    
                                                         [partnershipGiving setText:theValues];
    
                                                     }

                                                     else

                                                         if([thePropName isEqualToString:@"offering"]){
    
                                                             [totalOffering setText:theValues];
    
                                                         }

                                                         else

                                                             if([thePropName isEqualToString:@"offering_remitted"]){
    
                                                                 [offeringRemitted setText:theValues];
    
                                                             }

                                                             else

                                                                 if([thePropName isEqualToString:@"cell_leaders_comment"]){
    
                                                                     if([theValues isEqualToString:@"nil"]){
        
                                                                         [cellLeadersComment setText:@"No Comments are available at this time"];
                                                                     }
    
                                                                     else{
                                                                         [cellLeadersComment setText:theValues];
                                                                     }
    
                                                                 }

                                                                 else

                                                                     if([thePropName isEqualToString:@"leaders_comment"]){
    
                                                                         if([theValues isEqualToString:@"nil"]){
        
                                                                             [pcuLeadersComment setText:@"No Comments are available at this time"];
                                                                         }
    
                                                                         else{
                                                                             [pcuLeadersComment setText:theValues];
                                                                         }
    
                                                                     }

                                                                     else

                                                                         if([thePropName isEqualToString:@"final_comment"]){
    
                                                                             if([theValues isEqualToString:@"nil"]){
        
                                                                                 [pastorsComment setText:@"No Comments are available at this time"];
                                                                             }
    
                                                                             else{
                                                                                 [pastorsComment setText:theValues];
                                                                             }
    
                                                                         }

        }


}

- (void)interpreteDetailCellMemberRead:(NSMutableData*)theData{
    
    //NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    
   // NSLog(@"this is the read feed back: %@", theXML);

    
}

- (void)interpreteUpdatedCellReport:(NSMutableData*)theData{
    
    //NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    
    //NSLog(@"this is the update feed back: %@", theXML);
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    //entitySpecification = [json objectForKey:@"entitySpec"];
    //submissionEntityValue = [json objectForKey:@"entity"];
    NSString* theResult = [json objectForKey:@"result"];
    NSString* theMessage = [json objectForKey:@"message"];
    
    /**NSArray *theFaultFeedBack = [json objectForKey:@"fault"];
    
    NSDictionary *faultValues = [theFaultFeedBack objectAtIndex:0];
    
    NSString *theFault = [faultValues objectForKey:@"errorMessage"];**/
    
   
        if([theResult isEqualToString:@"true"]){
            
            NSString *title = theMessage;
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            
            [alert show];
            
        }
        else{
           
            NSString *title = @"Your update was not Successfull, please try again.";
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Thank You" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            
            [alert show];
        }

    
}


- (void)viewDidUnload
{
    meetingDateLabel = nil;
    meetingTimeLabel = nil;
    meetingHeldLabel = nil;
    firstTimersLabel = nil;
    membersPresentTable = nil;
    newConvertsLabel = nil;
    followUpCardsLabel = nil;
    firstTimersVisitedLabel = nil;
    firstTimersCalledLabel = nil;
    minMatTarget = nil;
    minMatBought = nil;
    partnershipTarget = nil;
    partnershipGiving = nil;
    offeringRemitted = nil;
    totalOffering = nil;
    cellLeadersComment = nil;
    pcuLeadersComment = nil;
    pastorsComment = nil;
    cellReportTable = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    //[theDetailTable.clearsSelectionOnViewWillAppear = NO];
    [super viewWillAppear:animated];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Detail", @"Detail");
    }
    return self;
}
							
#pragma mark - Split view

- (void)splitViewController:(UISplitViewController *)splitController willHideViewController:(UIViewController *)viewController withBarButtonItem:(UIBarButtonItem *)barButtonItem forPopoverController:(UIPopoverController *)popoverController
{
    /**barButtonItem.title = NSLocalizedString(@"Master", @"Master");
    [self.navigationItem setLeftBarButtonItem:barButtonItem animated:YES];
    self.masterPopoverController = popoverController;**/
    
    [buttonForMastersView setHidden:NO];
    
    //orientation is potrait
    theOrientationChecker = 1;
}

- (void)splitViewController:(UISplitViewController *)splitController willShowViewController:(UIViewController *)viewController invalidatingBarButtonItem:(UIBarButtonItem *)barButtonItem
{
    // Called when the view is shown again in the split view, invalidating the button and popover controller.
    [self.navigationItem setLeftBarButtonItem:nil animated:YES];
    self.masterPopoverController = nil;
    
    [buttonForMastersView setHidden:YES];
    
    [self.popoverController2 dismissPopoverAnimated:YES];
    
    //orientation is landscape
    theOrientationChecker = 2;
}

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    int theNumberofRows = 0;
    
    if(tableView.tag == 1){
        
        theNumberofRows = [cellMembersNameArray count];
    }
    
    else
        if(tableView.tag == 3){
            
            theNumberofRows = [theCellReports count];
        }
    
        else
            if(tableView.tag == 2){
                
                theNumberofRows = [cellMembersPresent count];
            }


    
    return theNumberofRows;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *thecell;
    
    if (tableView.tag == 1) {
    
    static NSString *simpleTableIdentifier = @"DetailViewTableCellIdentifier";
    
    cell = (DetailViewTableCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
   
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DetailViewTableCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    
    // Configure the cell.
    
    cell.nameLabel.text = [cellMembersNameArray objectAtIndex:indexPath.row];
    
    cell.memberImage.image = [UIImage imageNamed:@"pix_icon.png"];
    cell.rankingImage.image = [UIImage imageNamed:@"ic_star_on.png"];
    cell.rankingImage2.image = [UIImage imageNamed:@"ic_star_off.png"];
    cell.rankingImage3.image = [UIImage imageNamed:@"ic_star_off.png"];
    cell.rankingImage4.image = [UIImage imageNamed:@"ic_star_off.png"];
    cell.rankingImage5.image = [UIImage imageNamed:@"ic_star_off.png"];
    cell.wk1Indicator.tag = indexPath.row;
    cell.wk2Indicator.tag = indexPath.row;
    cell.wk3Indicator.tag = indexPath.row;
    cell.wk4Indicator.tag = indexPath.row;
    cell.wk5Indicator.tag = indexPath.row;
        
        
        
        /**if(cell.wk1Indicator.tag == 2 || cell.wk1Indicator.tag == 4
           || cell.wk1Indicator.tag == 6 || cell.wk1Indicator.tag == 8 || cell.wk1Indicator.tag == 10){
            
            cell.wk1Indicator.image = [UIImage imageNamed:@"ic_dot_on.png"];
            
        }**/
    // cell.wk1Indicator.image = [UIImage imageNamed:@"ic_dot_on.png"];
        
        NSString *theCellMember = [cellMembersNameArray objectAtIndex:indexPath.row];
        
        if([cellMembersPresentwk1 containsObject:theCellMember]){
            if (cell.wk1Indicator.tag == indexPath.row){
            cell.wk1Indicator.image = [UIImage imageNamed:@"ic_dot_on.png"];
            }
        }
        else{
            if (cell.wk1Indicator.tag == indexPath.row){
                cell.wk1Indicator.image = [UIImage imageNamed:@"ic_dot_off.png"];
            }
            //cell.wk1Indicator.image = [UIImage imageNamed:@"ic_dot_off.png"];
        }
        
        if([cellMembersPresentwk2 containsObject:theCellMember]){
            if (cell.wk2Indicator.tag == indexPath.row){
                cell.wk2Indicator.image = [UIImage imageNamed:@"ic_dot_on.png"];
            }
        }
        else{
            if (cell.wk2Indicator.tag == indexPath.row){
                cell.wk2Indicator.image = [UIImage imageNamed:@"ic_dot_off.png"];
            }
        
        }
    
    if([cellMembersPresentwk3 containsObject:theCellMember]){
        if (cell.wk3Indicator.tag == indexPath.row){
            cell.wk3Indicator.image = [UIImage imageNamed:@"ic_dot_on.png"];
        }
    }
    else{
        if (cell.wk3Indicator.tag == indexPath.row){
            cell.wk3Indicator.image = [UIImage imageNamed:@"ic_dot_off.png"];
        }
        
    }
    
    if([cellMembersPresentwk4 containsObject:theCellMember]){
        if (cell.wk4Indicator.tag == indexPath.row){
            cell.wk4Indicator.image = [UIImage imageNamed:@"ic_dot_on.png"];
        }
    }
    else{
        if (cell.wk4Indicator.tag == indexPath.row){
            cell.wk4Indicator.image = [UIImage imageNamed:@"ic_dot_off.png"];
        }
        
    }
    
    if([cellMembersPresentwk5 containsObject:theCellMember]){
        if (cell.wk5Indicator.tag == indexPath.row){
            cell.wk5Indicator.image = [UIImage imageNamed:@"ic_dot_on.png"];
        }
    }
    else{
        if (cell.wk5Indicator.tag == indexPath.row){
            cell.wk5Indicator.image = [UIImage imageNamed:@"ic_dot_off.png"];
        }
        
    }

        
    
    cell.nameLabel.highlightedTextColor = [UIColor blackColor];
 UIView *v = [[UIView alloc] init];
    v.backgroundColor = [UIColor whiteColor];
    cell.selectedBackgroundView = v;
        
        //return cell ;
        
        thecell = cell;
    }
    else
        
        if(tableView.tag == 3){
            
            static NSString *CellIdentifier = @"Cell";
            
            UITableViewCell *cell3 = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            
            if (cell3 == nil) {
                cell3 = [[UITableViewCell alloc]
                        initWithStyle:UITableViewCellStyleSubtitle
                        reuseIdentifier:CellIdentifier];
            }
            
            // Configure the cell...
            cell3.textLabel.text = [theCellReports objectAtIndex:indexPath.row];
            
            if([mainrole isEqualToString:@"Cell Leader"] || [subrole isEqualToString:@"Cell Leader"]){
            cell3.detailTextLabel.text = [NSString stringWithFormat:@"Total Attendance - %@.       Cell Report Status - %@", [theTotalAttendance objectAtIndex:indexPath.row], [cellReportStatus objectAtIndex:indexPath.row]];
            }
            else
                if([mainrole isEqualToString:@"Pastor"] || [subrole isEqualToString:@"Pastor"]){
                    cell3.detailTextLabel.text = [NSString stringWithFormat:@"Cell Report Status - %@", [cellReportStatus objectAtIndex:indexPath.row]];
                }
 
            //cell.textLabel.text.size = 14;
            cell3.textLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:20];
             cell3.detailTextLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:17];
            if([[cellReportStatus objectAtIndex:indexPath.row] isEqualToString:@"Pending"]){
                cell3.detailTextLabel.textColor = [UIColor redColor];
            }
            else
                if([[cellReportStatus objectAtIndex:indexPath.row] isEqualToString:@"Marked"]){
                    cell3.detailTextLabel.textColor = [UIColor blueColor];
                }
            
            //cell3.detailTextLabel.textColor = [UIColor greenColor];
            
            // cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            
            //return cell;
            
            thecell = cell3;
            
            
        }
        else
            
            if(tableView.tag == 2){
                
                static NSString *CellIdentifier = @"Cell";
                
                UITableViewCell *cell3 = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                
                if (cell3 == nil) {
                    cell3 = [[UITableViewCell alloc]
                             initWithStyle:UITableViewCellStyleSubtitle
                             reuseIdentifier:CellIdentifier];
                }
                
                // Configure the cell...
                cell3.textLabel.text = [cellMembersPresent objectAtIndex:indexPath.row];
                //cell3.detailTextLabel.text = [NSString stringWithFormat:@"Tatal Attendance - %@", [theTotalAttendance objectAtIndex:indexPath.row]];
                //cell.textLabel.text.size = 14;
                cell3.textLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:17];
               // cell3.detailTextLabel.font = [UIFont fontWithName:@"Helvetica Neue" size:17];
                
                // cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
                
                //return cell;
                
                thecell = cell3;
                
                
            }

    
    return thecell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if(tableView.tag == 3){
        
        NSString *theReport = [theCellReports objectAtIndex:indexPath.row];
        theReportID = [theReportTitleAndObject objectForKey:theReport];
        
        [self detailCellReportRead:theReportID];
        
         NSLog(@"you just selected a value %@ with an id %@", theReport, theReportID);
    }
    //NSLog(@"you just selected a value");
    
  
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat theTableHeight = 44;
    
    if (tableView.tag == 1){
    theTableHeight = 78;
        
    }
    
    else
        if (tableView.tag == 3){
            theTableHeight = 70;
            
        }
        else
            if (tableView.tag == 2){
                theTableHeight = 50;
                
            }
    
    return theTableHeight;
}


- (NSString *)base64Encode:(NSString *)plainText
{
    NSData *plainTextData = [plainText dataUsingEncoding:NSUTF8StringEncoding];
    NSString *base64String = [plainTextData base64EncodedString];
    return base64String;
}

- (NSString *)base64Decode:(NSString *)base64String
{
    NSData *plainTextData = [NSData dataFromBase64String:base64String];
    NSString *plainText = [[NSString alloc] initWithData:plainTextData encoding:NSUTF8StringEncoding];
    return plainText;
}

- (void)getStringForEncoding:(NSString *)base64String;{
    
    NSLog(@"this is the string %@", base64String);
}


- (void)alertView:(UIAlertView *)alert clickedButtonAtIndex:(NSInteger)buttonIndex
{
	
	NSString *selectedBook = [alert buttonTitleAtIndex:buttonIndex];
    
    if([selectedBook isEqualToString:@"Rate Now"]){
        
        hasRated = 1;
        [[NSUserDefaults standardUserDefaults] setInteger: hasRated forKey: @"hasRatedCheck"];
		[[NSUserDefaults standardUserDefaults] synchronize];
        
        NSURL *theURL = [NSURL URLWithString:@"http://videoshare.loveworldapis.com/rateApp/ratecellleadesrapp.php"] ;
        
        
        [[UIApplication sharedApplication] openURL:theURL];
        
    }
}





@end
