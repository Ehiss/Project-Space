//
//  LoginViewController.h
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/5/13.
//
//

#import <UIKit/UIKit.h>
//#import "Base64.h"
#import <sqlite3.h>
//#import "AppDelegate.h"

//@class Base64;

@interface LoginViewController : UIViewController <NSURLConnectionDelegate, UITextFieldDelegate>{
    
    IBOutlet UIImageView *thebackgroundImage;
    IBOutlet UITextField *nameField;
    IBOutlet UITextField *passwordField;
    IBOutlet UIActivityIndicatorView *theLoginIndicator;
    IBOutlet UIView *theLoginView;
    IBOutlet UIImageView *theLogoViewLogo;
    NSMutableData *webData;
    
    NSString* theUserName;
    NSString* thePassword;
    NSString* orientationCheck;
    NSDictionary* cellMemberScreen;
    NSDictionary* cellReportScreen;
    
    int theLoginMarker;
    int animationMarker;
    
    //AppDelegate *appDelegateForCellLeaders;
    
    //Base64 *theClass;
}

-(IBAction)performLogin:(id)sender;
-(void)theConnectionFunction:(NSString *)theConnectionUrl;

@property (strong, nonatomic) NSString *databasePath;
@property (nonatomic) sqlite3 *contactDB;

-(void)createDataBase;
-(void)insertIntoDataBase;

- (void)animateTheTextFieldForEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

- (void)animateReturnofTheTextFieldAfterEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

- (void)getFrameForRotation;

/**-(NSString *) base64StringFromData:(NSData *)data length:(int)length;

-(NSData *) base64DataFromString:(NSString *)string;**/



@end
