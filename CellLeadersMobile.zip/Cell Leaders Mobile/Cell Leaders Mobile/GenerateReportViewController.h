//
//  GenerateReportViewController.h
//  Cell Leaders Mobile
//
//  Created by ehiss on 8/30/13.
//
//

#import <UIKit/UIKit.h>
#import "ValueSelectionViewController.h"
#import "TheReportArchiveViewController.h"
//#import "AppDelegate.h"
//#import "DetailViewController.h"


@protocol CellReportViewingDelegate

//-(void)submissionCompleted:(NSNumber*)theCountry theUserFirstname:(NSString*)theFirstname theUserLastname:(NSString*)theLastname;


//-(void)addRecordToTable:(NSString*)theFirstname theUserLastname:(NSString*)theLastname theUserTitle:(NSString*)theTitle;

-(void)activateTheIndicator;

-(void)deActivateTheIndicator;

-(void)deActivateThePopup;

-(void)openTheReport:(NSString*)theReport theReportName:(NSString*)reportName;

-(void)openTheReportArchive:(NSString*)theReport;

@end

//@class AppDelegate;

@interface GenerateReportViewController : UIViewController <UIPopoverControllerDelegate, CountryUpdaterDelegate, NSURLConnectionDelegate, CellReportArchiveDelegate>{
    
    //AppDelegate *theDelegate;
    
    __weak IBOutlet UILabel *yearLabel_fm;
    __weak IBOutlet UILabel *monthLabel_fm;
    __weak IBOutlet UILabel *dayLabel_fm;
    __weak IBOutlet UILabel *yearLabel_to;
    __weak IBOutlet UILabel *monthLabel_to;
    __weak IBOutlet UILabel *dayLabel_to;
    __weak IBOutlet UILabel *reportTypeLabel;
    __weak IBOutlet UIButton *download_button;
    
    __weak IBOutlet UIButton *email_button;
    IBOutlet UIButton *dayFmButton;
    IBOutlet UIButton *monthFmButton;
    IBOutlet UIButton *yearFmButton;
    IBOutlet UIButton *dayToButton;
    IBOutlet UIButton *monthToButton;
    IBOutlet UIButton *yearToButton;
    IBOutlet UIButton *reportTypeButton;
    IBOutlet UIButton *archiveButton;
    
    __weak IBOutlet UIActivityIndicatorView *theActivityIndicator;
    NSString *theValue;
    NSString *encodedusername;
    NSString *reportType;
     NSMutableData *webData;
    
     id <CellReportViewingDelegate> delegate;
    
    int theURLRequestChecker;
    
    NSMutableArray *cellReportTypes;
    NSMutableDictionary *reportTypeAndLink;
    NSMutableArray *cellReportArchiveArray;
    
}
@property (nonatomic, retain) UIPopoverController *popoverController2;
@property (nonatomic, retain) UIPopoverController *popoverController3;
@property (retain) id delegate;
- (IBAction)generateReport:(id)sender;
- (IBAction)reportTypeAction:(id)sender;

- (IBAction)doneReporting:(id)sender;

- (IBAction)viewArchivedReport:(id)sender;

-(IBAction)selectorDependencies:(id)sender;

- (void)initForViewCellReport;

- (void)initForViewCellReportManualWay;

- (void)interpreteTheData:(NSMutableData*)theData;

- (void)interpreteSubmitReport:(NSMutableData*)theData;

- (void)interpreteTheDataForMannual:(NSMutableData*)theData;

@end
