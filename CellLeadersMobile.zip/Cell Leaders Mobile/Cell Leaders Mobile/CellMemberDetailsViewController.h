//
//  CellMemberDetailsViewController.h
//  Cell Leaders Mobile
//
//  Created by ehiss on 6/2/13.
//
//

#import <UIKit/UIKit.h>
#import "ValueSelectionViewController.h"

@interface CellMemberDetailsViewController : UIViewController<NSURLConnectionDelegate, UIPopoverControllerDelegate, CountryUpdaterDelegate, UITextFieldDelegate>{
    IBOutlet UILabel *theCellMember;
    IBOutlet UIActivityIndicatorView *activityIndicator;
    IBOutlet UIView *theContainerView;
    IBOutlet UILabel *stateLabel;
    IBOutlet UIButton *stateButton;
    NSString *theCellMemberName;
    NSString *theCellMemberId;
    
    NSMutableData *webData_cellMember;
    
    NSString *encodedusername_cellMember;
    NSString *theEntityValue_cellMember;
    NSString *theValue;
    
    //int userHasLogedIn_master;
    int theURLRequestChecker_cellMember;
    int theEditButtonChecker;
    
    NSMutableArray *theTitlesArray;
    NSMutableArray *theGenderArray;
    NSMutableArray *theCountryArray;
    //NSMutableArray *theCellArray;
    NSMutableArray *theStateArray;
    NSMutableArray *maritalStatusArray;
    NSMutableDictionary *theTitleAndObject;
    NSMutableDictionary *theCountryAndObject;
    NSMutableDictionary *theStateAndObject;
    NSMutableDictionary *theCellAndObject;
    
    NSString *thecellmemberDetailReadEntityValue;
    __weak IBOutlet UILabel *theTitleLabel;
    __weak IBOutlet UILabel *gender;
    __weak IBOutlet UILabel *DOBday;
    __weak IBOutlet UILabel *DOBmonth;
    __weak IBOutlet UILabel *DOByear;
    __weak IBOutlet UILabel *cellmemberAge;
    __weak IBOutlet UITextField *emailField;
    __weak IBOutlet UILabel *statusLabel;
    __weak IBOutlet UITextField *yookosfield;
    __weak IBOutlet UITextField *occupationField;
    __weak IBOutlet UITextField *stateField;
    __weak IBOutlet UILabel *countryLabel;
    
    __weak IBOutlet UILabel *dateJoinedMinYear;
    __weak IBOutlet UILabel *dateJoinedMinMonth;
    __weak IBOutlet UILabel *dateJoinedMinDay;
    __weak IBOutlet UILabel *cellNameLabel;
    __weak IBOutlet UILabel *dateBornAgainDay;
    __weak IBOutlet UILabel *dateBornAgainMonth;
    __weak IBOutlet UIButton *dobmonth_button;
    
    __weak IBOutlet UIButton *dobyear_button;
    __weak IBOutlet UIButton *dobdate_button;
    __weak IBOutlet UILabel *partnerLabel;
    __weak IBOutlet UILabel *baptizedLabel;
    __weak IBOutlet UILabel *dateBornAgainYear;
    __weak IBOutlet UIButton *status_button;
    
    __weak IBOutlet UIButton *djmyear_button;
    __weak IBOutlet UIButton *djmmonth_button;
    __weak IBOutlet UIButton *djmday_button;
    
    __weak IBOutlet UIButton *dbaday_button;
    __weak IBOutlet UIButton *dbamonth_button;
    __weak IBOutlet UIButton *dbayear_button;
    
    __weak IBOutlet UIButton *minpartner_button;
    __weak IBOutlet UIButton *baptized_button;
    __weak IBOutlet UITextField *firstname_field;
    __weak IBOutlet UIButton *titleButton;
    __weak IBOutlet UIButton *countryButton;
    
    __weak IBOutlet UIButton *genderButton;
    __weak IBOutlet UITextField *lastname_field;
    __weak IBOutlet UITextField *mobilenumber_textfield;
    __weak IBOutlet UITextField *homeNumber_textfield;
    __weak IBOutlet UITextField *residentialAddy_textfield;
    __weak IBOutlet UIButton *theEdit_button;
}

@property (nonatomic, retain) UIPopoverController *popoverController2;
@property (nonatomic, retain) UIPopoverController *popoverController3;
@property (nonatomic, retain) NSString *theCellMemberName;
@property (nonatomic, retain) NSString *theCellMemberId;
@property (nonatomic, retain) NSString *encodedusername_cellMember;
@property (nonatomic, retain) NSString *theEntityValue_cellMember;
-(IBAction)goBack:(id)sender;
-(IBAction)editCellMemberRecord:(id)sender;

- (void)detailCellMemberRead:(NSString*)theMemberID;

- (void)submitEditedCellMemberRecord:(NSString*)theMemberID;

- (void)interpreteDetailCellMemberRead:(NSMutableData*)theData;

- (void)interpreteSubmittedCellMemberRecord:(NSMutableData*)theData;

-(IBAction)selectorDependencies:(id)sender;

- (void)animateEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

- (void)animateEntireViewForEditing:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

- (void)animateEditingComplete:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

- (void)animateEntireViewForEditingCompleted:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;

@end
