//
//  SubmitCellReportViewController.h
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/4/13.
//
//

#import <UIKit/UIKit.h>
#import "ValueSelectionViewController.h"


@protocol CellReportSubmissionCompleteDelegate

-(void)submissionCompleted:(NSNumber*)theCountry theUserFirstname:(NSString*)theFirstname theUserLastname:(NSString*)theLastname;


-(void)addRecordToTable:(NSString*)theFirstname theUserLastname:(NSString*)theLastname theUserTitle:(NSString*)theTitle;

-(void)activateTheIndicator;

-(void)deActivateTheIndicator;

-(void)deActivateThePopup;

@end



@interface SubmitCellReportViewController : UIViewController<UITextViewDelegate, NSURLConnectionDelegate, UIPopoverControllerDelegate, CountryUpdaterDelegate, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>{
    
    id <CellReportSubmissionCompleteDelegate> delegate;
    
    IBOutlet UITextView *cellLeadersComment;
    IBOutlet UITableView *attendanceTable;
    IBOutlet UIButton *meetingTypeButton;
    IBOutlet UILabel *meetingTypeLabel;
    __weak IBOutlet UIButton *yearButton;
    __weak IBOutlet UIButton *monthButton;
     __weak IBOutlet UIButton *dayButton;
    __weak IBOutlet UIButton *ampmButton;
    __weak IBOutlet UIButton *meetingHeldButton;
    __weak IBOutlet UIButton *offeringSubmittedButton;
    __weak IBOutlet UILabel *yearLabel;
    __weak IBOutlet UILabel *monthLabel;
    __weak IBOutlet UILabel *dayLabel;
    __weak IBOutlet UILabel *ampmLabel;
    __weak IBOutlet UILabel *meetingHeldLabel;
    __weak IBOutlet UILabel *offeringSubmittedLabel;
    __weak IBOutlet UITextField *hourField;
    __weak IBOutlet UITextField *minutesField;
    __weak IBOutlet UITextField *secondsField;
    __weak IBOutlet UITextField *noofFirstTimersField;
    __weak IBOutlet UITextField *newConvertsField;
    __weak IBOutlet UITextField *firstTimersCaledField;
    __weak IBOutlet UITextField *minMaterialTargetField;
    __weak IBOutlet UITextField *minMaterialBoughtField;
    __weak IBOutlet UITextField *partnershipTargetField;
    __weak IBOutlet UITextField *partnershipGivingField;
    __weak IBOutlet UITextField *attendanceField;
    __weak IBOutlet UITextField *offeringField;
        
    __weak IBOutlet UITextField *followupCardRecieved;
    __weak IBOutlet UITextField *firstTimersVisitedField;
    IBOutlet UILabel *attendanceLabel;
    IBOutlet UIView *theMainView;
    
    NSString *theValue;
    NSString *encodedusername;
    NSString *theEntityValue;
     NSString *theentityname;
    
    
    NSString *theResult;
    NSString *submissionEntityValue;
    NSMutableDictionary *theTitleAndObject;
    
    
    NSMutableData *webData;
    
    NSMutableArray *totalCellMembers;
    
    NSMutableArray *cellMembersPresent;
    
    NSArray *meetingType;
    
    NSMutableArray *totalCellMembersPresent;
    
    int theURLRequestChecker;
    int attendanceIndicator;
    
    BOOL theError;
    
}
@property (nonatomic, retain) UIPopoverController *popoverController2;
@property int theDayOfTheWeek;
@property (retain) id delegate;

-(IBAction)selectorDependencies:(id)sender;

- (void)initForCellReportSubmission;

- (void)interpreteTheData:(NSMutableData*)theData;

- (void)interpreteSubmitData:(NSMutableData*)theData;

@end
