//
//  CSCommentPageViewController.h
//  ImmStreamingApp2
//
//  Created by Christian Isaac on 10/4/12.
//  Copyright (c) 2012 Emerging Technologies & Re-engineering. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
//#import "AppDelegate.h"
//#import "ViewController.h"
//#import "CommunionServicePlayerPage.h"

@protocol CountryUpdaterDelegate

-(void)updateCountry:(NSString*)theCountry;

@end

@interface CSCommentPageViewController : UITableViewController{
    
    NSMutableArray *regionItems;
    //AppDelegate *theDelegate;
    
    id <CountryUpdaterDelegate> delegate;
    
}
@property (retain) id delegate;

@end