//
//  AddNewMemberViewController.m
//  Cell Leaders Mobile
//
//  Created by ehiss on 4/1/13.
//
//

#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)

#import "AddNewMemberViewController.h"

@interface AddNewMemberViewController ()

@end

@implementation AddNewMemberViewController

@synthesize popoverController2, delegate;


-(void)updateCountry:(NSString*)theCountry{
    
        if([theValue isEqualToString:@"selecttitle"]){
            
            [theTitle setText:theCountry];
            [theTitle setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
            
            //NSNumber* theNumber = [theTitleAndObject objectForKey:theCountry];
            
            //NSLog(@"this is the id %@", theNumber);
        }
    
        else
            if([theValue isEqualToString:@"selectgender"]){
               
                [gender setText:theCountry];
                [gender setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
            }
            else
                if([theValue isEqualToString:@"selectcountry"]){
                    
                    [country setText:theCountry];
                    [country setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                    
                }
                else
                    if([theValue isEqualToString:@"bornagain"]){
                        
                        [bornAgainStatus setText:theCountry];
                        [bornAgainStatus setFont:[UIFont fontWithName:@"Helvetica Neue" size:14]];
                        
                    }
    
    
    [self.popoverController2 dismissPopoverAnimated:YES];
}

-(IBAction)selectorDependencies:(id)sender{
    
    if (theError){
        
        NSString *title = @"There is an issue connecting to the internet at this time and as a result, values can not be displayed. Please try again. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
    }
    
    theValue = [[sender titleLabel] text];
    
    //NSLog(@"this is the value selected %@", theValue);
    
    //if (self.popoverController3 == nil) {
    
            if([theValue isEqualToString:@"selecttitle"]){
                
                ValueSelectionViewController *MVC =
                [[ValueSelectionViewController alloc]
                 initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                
                MVC.navigationItem.title = @"Select Title";
                MVC.regionItems = [[NSMutableArray alloc] initWithArray:theTitlesArray copyItems:YES];
                //MVC.theResource = theValue;
                UINavigationController *navController =
                [[UINavigationController alloc]
                 initWithRootViewController:MVC];
                MVC.delegate = self;
                
                UIPopoverController *popover =
                [[UIPopoverController alloc]
                 initWithContentViewController:navController];
                
                popover.delegate = self;
                
                //[MVC release];
                //[navController release];
                
                self.popoverController2 = popover;
                //[popover release];
                //}
                
                CGRect popoverRect = [self.view convertRect:[yearButton frame] fromView:[yearButton superview]];
                
                popoverRect.size.width = MIN(popoverRect.size.width, 99);
                
                [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
            }
    
            else
                if([theValue isEqualToString:@"selectgender"]){
                    
                    ValueSelectionViewController *MVC =
                    [[ValueSelectionViewController alloc]
                     initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                    
                    MVC.navigationItem.title = @"Select Gender";
                    MVC.regionItems = [[NSMutableArray alloc] initWithArray:theGenderArray copyItems:YES];
                    UINavigationController *navController =
                    [[UINavigationController alloc]
                     initWithRootViewController:MVC];
                    MVC.delegate = self;
                    
                    UIPopoverController *popover =
                    [[UIPopoverController alloc]
                     initWithContentViewController:navController];
                    
                    popover.delegate = self;
                    
                    //[MVC release];
                    //[navController release];
                    
                    self.popoverController2 = popover;
                    //[popover release];
                    //}
                    
                    CGRect popoverRect = [self.view convertRect:[genderButton frame] fromView:[genderButton superview]];
                    
                    popoverRect.size.width = MIN(popoverRect.size.width, 99);
                    
                    [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                }

    
                else
                    if([theValue isEqualToString:@"selectcountry"]){
                        
                        ValueSelectionViewController *MVC =
                        [[ValueSelectionViewController alloc]
                         initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                        
                        MVC.navigationItem.title = @"Select Country";
                        MVC.regionItems = [[NSMutableArray alloc] initWithArray:theCountryArray copyItems:YES];
                       // MVC.theResource = theValue;
                        UINavigationController *navController =
                        [[UINavigationController alloc]
                         initWithRootViewController:MVC];
                        MVC.delegate = self;
                        
                        UIPopoverController *popover =
                        [[UIPopoverController alloc]
                         initWithContentViewController:navController];
                        
                        popover.delegate = self;
                        
                        //[MVC release];
                        //[navController release];
                        
                        self.popoverController2 = popover;
                        //[popover release];
                        //}
                        
                        CGRect popoverRect = [self.view convertRect:[statusButton frame] fromView:[statusButton superview]];
                        
                        popoverRect.size.width = MIN(popoverRect.size.width, 99);
                        
                        [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                    }

                    else
                        if([theValue isEqualToString:@"bornagain"]){
                            
                            ValueSelectionViewController *MVC =
                            [[ValueSelectionViewController alloc]
                             initWithNibName:@"ValueSelectionViewController" bundle:[NSBundle mainBundle]];
                            
                            MVC.navigationItem.title = @"Born Again?";
                            MVC.theResource = theValue;
                            UINavigationController *navController =
                            [[UINavigationController alloc]
                             initWithRootViewController:MVC];
                            MVC.delegate = self;
                            
                            UIPopoverController *popover =
                            [[UIPopoverController alloc]
                             initWithContentViewController:navController];
                            
                            popover.delegate = self;
                            
                            //[MVC release];
                            //[navController release];
                            
                            self.popoverController2 = popover;
                            //[popover release];
                            //}
                            
                            CGRect popoverRect = [self.view convertRect:[bornagainButton frame] fromView:[bornagainButton superview]];
                            
                            popoverRect.size.width = MIN(popoverRect.size.width, 99);
                            
                            [self.popoverController2 presentPopoverFromRect:popoverRect inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
                        }


    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    theEntityValue = [[NSUserDefaults standardUserDefaults] valueForKey: @"screenentity"];
    encodedusername = [[NSUserDefaults standardUserDefaults] valueForKey: @"encodedlogindetails"];
    
    self.contentSizeForViewInPopover = CGSizeMake(440.0, 450.0);
    
    UIBarButtonItem *anotherButton = [[UIBarButtonItem alloc] initWithTitle:
									  @"Clear" style:UIBarButtonItemStylePlain target:self action:@selector(clearFields:)];
	self.navigationItem.leftBarButtonItem = anotherButton;
    anotherButton.image = [UIImage imageNamed:@"btn_clear_dark.png"];
    //anotherButton.style =[UIBarButtonItemStyleDone]
	
    
    
    
    UIBarButtonItem *anotherButton2 = [[UIBarButtonItem alloc] initWithTitle:
                                       @"Done" style:UIBarButtonItemStylePlain target:self action:@selector(addMemberDetails:)];
	self.navigationItem.rightBarButtonItem = anotherButton2;
	anotherButton2.image = [UIImage imageNamed:@"btn_done_dark.png"];
    //anotherButton2.style = UIBarButtonItemStyleDone;
   
    [self initForCreate];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

/**-(void)viewDidAppear:(BOOL)animated{
    
    [self initForCreate];
    
}**/


- (void)initForCreate{
    
    NSLog(@"this is the entity value for add new member %@", theEntityValue);
    
    NSError* error;
    theURLRequestChecker = 1;
    
    [[self delegate] activateTheIndicator];
    
    @try{
        
        NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:
                              @"init", @"mode", nil];
        
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                           options:NSJSONWritingPrettyPrinted
                                                             error:&error];
        
        NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                        encoding:NSUTF8StringEncoding];
        
        //NSLog(@"the json string is %@", theJsonString);
        
        NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=create&content=%@", encodedusername, theJsonString];
        
        //online
        NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123/%@/create/", theEntityValue]]];
        
        //local
        
       // NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.3:8000/%@/create/", theEntityValue]]];
        
        // NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://192.168.0.2:8000/portal/"]];
        
        
        // Set the request's content type to application/x-www-form-urlencoded
        [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        // Designate the request a POST request and specify its body data
        [postRequest setHTTPMethod:@"POST"];
        [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
        
        
        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
        
        if(conn) {
            
            webData = [NSMutableData data] ;
        }
        
    }
    
    @catch (NSException *e){
        NSLog(@"Exception %@", e);
    }
    
    
    
}




-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData setLength:0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    
    [webData appendData:data];
    
    theError = FALSE;
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    theError = TRUE;
    
    NSString *title = @"There is an issue connecting to the internet at this time, please try again. Thank You";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];
    
    [[self delegate] deActivateTheIndicator];
    
    NSLog(@"ERROR with theConnection");
    NSLog(@"%@", error);
}

-(void)connectionDidFinishLoading:(NSURLConnection *) connection{
    
    [[self delegate] deActivateTheIndicator];
    theError = FALSE;
    
    NSLog(@"DONE, recieved Bytes: %d", [webData length]);
    
    if (theURLRequestChecker == 1) {
        [self interpreteTheData:webData];
    }
    
    if (theURLRequestChecker == 2) {
        [self interpretePostData:webData];
    }

}



- (void)interpreteTheData:(NSMutableData*)theData{
    
    theTitleAndObject = [[NSMutableDictionary alloc] init];
    theCountryAndObject = [[NSMutableDictionary alloc] init];
    theTitlesArray = [[NSMutableArray alloc] init];
    theGenderArray = [[NSMutableArray alloc] init];
    theCountryArray = [[NSMutableArray alloc] init];
    
    NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    NSLog(@"this is the feed back: %@", theXML);
    
    NSDictionary* json = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    entitySpecification = [json objectForKey:@"entitySpec"];
    theentityname = [json objectForKey:@"entity"];
    
    NSDictionary* dictionaryForTitle = [entitySpecification objectAtIndex:0];
    
    NSDictionary* dictionaryForGender = [entitySpecification objectAtIndex:3];
    
    NSDictionary* dictionaryForCountry = [entitySpecification objectAtIndex:5];
    
    NSArray* theTitles = [dictionaryForTitle objectForKey:@"options"];
    NSArray* theGender = [dictionaryForGender objectForKey:@"options"];
    NSArray* theCountry = [dictionaryForCountry objectForKey:@"options"];
    
    
    for(NSDictionary* theTitleOptions in theTitles){
        
        NSNumber* titleID = [theTitleOptions objectForKey:@"id"];
        
        NSString* titleLabel = [theTitleOptions objectForKey:@"label"];
       
        [theTitlesArray addObject:titleLabel];
        [theTitleAndObject setObject:titleID forKey:titleLabel];
        
        //NSLog(@"this is title %@ with id %@", titleLabel, titleID);
        
        
    }
    
    for(NSDictionary* theTitleOptions in theCountry){
        
        NSNumber* titleID = [theTitleOptions objectForKey:@"id"];
        
        NSString* titleLabel = [theTitleOptions objectForKey:@"label"];
        
        [theCountryArray addObject:titleLabel];
        [theCountryAndObject setObject:titleID forKey:titleLabel];
        
       // NSLog(@"this is title %@ with id %@", titleLabel, titleID);
        
        
    }
    
    for(NSString* theTitleOptions in theGender){
        
        [theGenderArray addObject:theTitleOptions];
        //[theTitleAndObject setObject:titleID forKey:titleLabel];
        
       // NSLog(@"this is the gender %@", theTitleOptions);
        
        
    }

    [[NSUserDefaults standardUserDefaults] setValue:theentityname forKey: @"cellmembersentity"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSLog(@"the add member entity name %@", theentityname);
}


- (void)interpretePostData:(NSMutableData*)theData{
    
    NSString *theXML = [[NSString alloc] initWithBytes:[theData mutableBytes] length:[theData length] encoding:NSUTF8StringEncoding];
    
    NSLog(@"this is the create user feed back: %@", theXML);
    
NSDictionary* postValue = [NSJSONSerialization JSONObjectWithData:theData options:kNilOptions error:nil];
    
    //id theresult = [postValue objectForKey:@"result"];
    NSString *entity = [postValue objectForKey:@"entity"];
    theEntityID = [postValue objectForKey:@"entityId"];
    NSString *theResult = [postValue objectForKey:@"result"];
    NSString *theErrorMessage;
    
    if([theResult isEqualToString:@"false"]){
        
        NSArray *theErrorNow = [postValue objectForKey:@"fault"];
        
        for(NSDictionary *theErrorValue in theErrorNow){
            
            theErrorMessage = [theErrorValue objectForKey:@"errorMessage"];
            
        }
       
        NSString *title = theErrorMessage;
        NSString *theMessage = [NSString stringWithFormat:@"%@ is not a valid email address. Please enter a valid email address and try again. Thank You", emailField.text];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:theMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
        
        
    }
    else{
    if ([entity isEqualToString:@"Member"]) {
        
        
        [[self delegate] addRecordToTable:firstName.text theUserLastname:lastName.text theUserTitle:theTitle.text];
        
        
        NSString *title = [NSString stringWithFormat:@"%@ %@ has been sucessfully added as a cell member", firstName.text,  lastName.text];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:@"Do you wish to add more cell members ?" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:@"Add More",nil];
        
        [alert show];
         
    }
    }
   // NSLog(@"this is the result %@", theresult);
    
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
   NSString *selectedBook = [alertView buttonTitleAtIndex:buttonIndex];
    
    if ([selectedBook isEqualToString:@"Add More"]) {
        [self clearTheFields];
         //[[self delegate] submissionCompleted:theEntityID];
    }
    else
        if ([selectedBook isEqualToString:@"Done"]) {
            
            NSLog(@"you selected done");
            [self clearTheFields];
            
            [[self delegate] submissionCompleted:theEntityID theUserFirstname:firstName.text theUserLastname:lastName.text];
            
        }
    
    
    
}

-(IBAction)clearFields:(UIBarButtonItem *)sender {
    
    NSLog(@"you want to clear the field");
    [firstName setText:@""];
    [lastName setText:@""];
    [midleName setText:@""];
    [theTitle setText:@"select title"];
    [gender setText:@"select gender"];
    [country setText:@"select country"];
    [emailField setText:@""];
    [followUpLabel setText:@""];
    [bornAgainStatus setText:@"select value"];
    
    [followUpLabel resignFirstResponder];
    
    
}

-(void) clearTheFields{
    
    [firstName setText:@""];
    [lastName setText:@""];
    [midleName setText:@""];
    [theTitle setText:@"select title"];
    [gender setText:@"select gender"];
    [country setText:@"select country"];
    [emailField setText:@""];
    [followUpLabel setText:@""];
    [bornAgainStatus setText:@"select value"];
    
    [followUpLabel resignFirstResponder];

    
}

-(IBAction)addMemberDetails:(UIBarButtonItem *)sender {
    
  NSString *theFirstName = firstName.text;
   NSString *theLastName = lastName.text;
   // NSString *theMiddleName = midleName.text;
   
    NSString *theTitle22 = theTitle.text;
    NSString *theGender = gender.text;
    NSString *theCountry = country.text;
   // NSString *theStatus = maritalStatus.text;
    NSString *usersEmail = emailField.text;
    NSString *theFollowUp= followUpLabel.text;
    NSString *theBornAgainStatus = bornAgainStatus.text;
    
   // NSArray *theEmailEntity = [usersEmail componentsSeparatedByString:@"@"];
    
    if ([theFirstName isEqualToString:@""] || [theLastName isEqualToString:@""] || [theGender isEqualToString:@"select gender"] || [usersEmail isEqualToString:@""] || [theFollowUp isEqualToString:@""] || [theBornAgainStatus isEqualToString:@"select value"] || [theTitle22 isEqualToString:@"select title"] || [theCountry isEqualToString:@"select country"]) {
        
        
        NSString *title = @"Some fields have not been properly filled, please ensure all fields are filled. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
    }
   /** else
        if([theEmailEntity count] == 0){
            
            NSString *title = @"Invalid email address !!";
            NSString *theMessage = [NSString stringWithFormat:@"%@ is not a valid email address. Please enter a valid email address and tyr again. thank you", usersEmail];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:theMessage delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            
            [alert show];
            
        }**/
    
    else{
    
        NSError* error;
        theURLRequestChecker = 2;
        [[self delegate] activateTheIndicator];
        
        @try{
            
            NSDictionary *entitySpec = [NSDictionary dictionaryWithObjectsAndKeys:theFirstName, @"first_name", theLastName, @"last_name", [theTitleAndObject objectForKey:theTitle22], @"title", theGender, @"gender", usersEmail, @"email_address", [theCountryAndObject objectForKey:theCountry], @"country", nil];
            
            //NSArray *theentitySpecArray = [[NSArray alloc] in]
            
           /** NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:
                                  @"save", @"mode", theFirstName, @"first_name", theLastName, @"last_name", [theTitleAndObject objectForKey:theTitle22], @"title", theGender, @"gender", usersEmail, @"email_address", [theCountryAndObject objectForKey:theCountry], @"country", theentityname, @"entityName", nil];**/
            
            NSDictionary* info = [NSDictionary dictionaryWithObjectsAndKeys:
                                  @"save", @"mode", entitySpec, @"entitySpec", theentityname, @"entityName", nil];
            
            
            NSData* jsonData = [NSJSONSerialization dataWithJSONObject:info
                                                               options:NSJSONWritingPrettyPrinted
                                                                 error:&error];
            
            NSString *theJsonString = [[NSString alloc] initWithData:jsonData
                                                            encoding:NSUTF8StringEncoding];
            
            //NSLog(@"the json string is %@", theJsonString);
            
            NSString *bodyData = [NSString stringWithFormat:@"authorization=%@&action=create&content=%@", encodedusername, theJsonString];
            
            //online
            NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://162.242.238.123/%@/create/", theEntityValue]]];
            
            
            //local http://192.168.0.2:8000
            
           // NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://192.168.0.3:8000/%@/create/", theEntityValue]]];
            
            
            // Set the request's content type to application/x-www-form-urlencoded
            [postRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            
            // Designate the request a POST request and specify its body data
            [postRequest setHTTPMethod:@"POST"];
            [postRequest setHTTPBody:[NSData dataWithBytes:[bodyData UTF8String] length:[bodyData length]]];
            
            
            NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:postRequest delegate:self];
            
            if(conn) {
                
                webData = [NSMutableData data] ;
            }
            
        }
        
        @catch (NSException *e){
            NSLog(@"Exception %@", e);
        }
        

        
        
        

        
    }
    
   //NSLog(@"you want to add member details");
    
}

- (void)fetchedData:(NSData *)responseData {
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    //dayButton = nil;
    //monthButton = nil;
    yearButton = nil;
    genderButton = nil;
    statusButton = nil;
    bornagainButton = nil;
    [super viewDidUnload];
}
@end
