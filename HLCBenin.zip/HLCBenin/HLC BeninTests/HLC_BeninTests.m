//
//  HLC_BeninTests.m
//  HLC BeninTests
//
//  Created by AKEJU on 1/15/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import "HLC_BeninTests.h"

@implementation HLC_BeninTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in HLC BeninTests");
}

@end
