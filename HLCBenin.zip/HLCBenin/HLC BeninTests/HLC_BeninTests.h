//
//  HLC_BeninTests.h
//  HLC BeninTests
//
//  Created by AKEJU on 1/15/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface HLC_BeninTests : SenTestCase

@end
