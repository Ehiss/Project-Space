//
//  InviteViewController.h
//  HLC Benin
//
//  Created by AKEJU on 1/22/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>


@interface InviteViewController : UIViewController<MFMailComposeViewControllerDelegate>{

IBOutlet UITextField* textfield2;
    
    IBOutlet UITextField* textfield3;
    
    IBOutlet UITextField* nameLabel ;
	IBOutlet UITextField* friendsnameLabel;
	IBOutlet UITextField* emailLabel ;

    
    
    
    
}

@end
