//
//  MenuViewController.h
//  HLC Benin
//
//  Created by AKEJU on 1/20/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MenuViewController : UIViewController

{
    
    NSArray *menuimages;
    
  NSMutableArray *menuitems;

}
@property (retain) id delegate;
@end
