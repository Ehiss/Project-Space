//
//  PWSendBadgeRequest.h
//  Pushwoosh SDK
//  (c) Pushwoosh 2012
//

#import "PWRequest.h"

@interface PWSendBadgeRequest : PWRequest

@property (nonatomic) NSInteger badge;

@end
