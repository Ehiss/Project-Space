//
//  ViewnoteViewController.m
//  HLC Benin
//
//  Created by AKEJU on 1/31/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import "ViewnoteViewController.h"

@implementation ViewnoteViewController

//[noteViewController hidenote];




-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    
    return NO;
}

-(IBAction)btnDone:(id)sender{
    
    
    //[self dismissViewControllerAnimated:YES completion:nil];
    //[self dismissModalViewControllerAnimated:YES];
    
    //[self.navigationController popViewControllerAnimated:YES];
    
    [self.navigationController popToRootViewControllerAnimated:YES];
    
    
   
    
    
    
	
	NSLog(@"done");
}

-(IBAction)btnEdit:(id)sender{
	NSString *operation = [[sender titleLabel] text];
	
	if([operation isEqualToString:@"Edit"]){
        [displayTable setEditing:YES animated:YES];
        
		
	}
	else
		if([operation isEqualToString:@"Done Editing"]){
			[displayTable setEditing:NO animated:YES];
			
		}
	
}

- (void)viewDidLoad {
    
	//NSLog(@"This is the correct Date: %@", dateString);
	AppDelegate *appDelegateforNote = [[UIApplication sharedApplication] delegate];
	
	
    generalSettingsItems = [[NSMutableArray alloc] initWithArray:appDelegateforNote.viewController.noteTitleandAuthors copyItems:YES];
   	dateItems = [[NSMutableArray alloc] initWithArray:appDelegateforNote.viewController.noteDateandTime copyItems:YES];
    [super viewDidLoad];
    //self.clearsSelectionOnViewWillAppear = NO;
	
}


-(void)viewDidAppear:(BOOL)animated{
	
	//self.navigationController.navigationBarHidden = YES;
	
}



#pragma mark -
#pragma mark Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [generalSettingsItems count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
        cell = [[UITableViewCell alloc]
                initWithStyle:UITableViewCellStyleSubtitle
                reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
	cell.textLabel.text = [generalSettingsItems objectAtIndex:indexPath.row];
	//NSString *theDay;
	//NSString *dateString = [today stringFromDate];
    
	cell.detailTextLabel.text = [dateItems objectAtIndex:indexPath.row];
	//cell.textLabel.text.size = 40;
	cell.textLabel.font = [UIFont fontWithName:@"Trebuchet-Ms" size:40];
	
	//if(indexPath.row == 0 || indexPath.row == 3)
    //cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	
    return cell;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
	
	if (editingStyle == UITableViewCellEditingStyleDelete) {
		// Delete the row from the data source.
		AppDelegate *appDelegateforDelete =
		[[UIApplication sharedApplication] delegate];
		
		[generalSettingsItems removeObjectAtIndex:indexPath.row];
		[appDelegateforDelete.viewController.noteTitleandAuthors removeObjectAtIndex:indexPath.row];
		[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
	}
	else if (editingStyle == UITableViewCellEditingStyleInsert) {
		// Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
		//[predictSearchItems replaceObjectAtIndex:indexPath.row withObject:[predictSearchItems objectAtIndex:indexPath.row]];
		//[tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
	}
}


-(UITableViewCellEditingStyle) tableView:(UITableView *)
tableView editingStyleForRowAtIndexPath: (NSIndexPath *) indexPath {
	return UITableViewCellEditingStyleDelete;
	//return UITableViewCellEditingStyleInsert;
}




// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
	AppDelegate *appDelegateforMove =
	[[UIApplication sharedApplication] delegate];
	
	id object = [generalSettingsItems objectAtIndex:fromIndexPath.row];
	[generalSettingsItems removeObjectAtIndex:fromIndexPath.row];
	[generalSettingsItems insertObject:object atIndex:toIndexPath.row];
	
	
	id object2 =[appDelegateforMove.viewController.noteTitleandAuthors objectAtIndex:fromIndexPath.row];
	[appDelegateforMove.viewController.noteTitleandAuthors removeObjectAtIndex:fromIndexPath.row];
	[appDelegateforMove.viewController.noteTitleandAuthors insertObject:object2 atIndex:toIndexPath.row];
	
}




// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
	// Return NO if you do not want the item to be re-orderable.
	return YES;
}


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	AppDelegate *appDelegateForNotes =
	[[UIApplication sharedApplication] delegate];
	appDelegateForNotes.viewController.getNote = [generalSettingsItems objectAtIndex:indexPath.row];
	//NSLog(@"this is the table value: %@", [generalSettingsItems objectAtIndex:indexPath.row]);
	appDelegateForNotes.viewController.readNoteChecker = 2;
	
	CreatenoteViewController *noteViewController =
	[[CreatenoteViewController alloc]
	 initWithNibName:@"CreatenoteViewController" bundle:nil];
	
	[self.navigationController
	 pushViewController:noteViewController animated:YES];
	
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	
}


@end
