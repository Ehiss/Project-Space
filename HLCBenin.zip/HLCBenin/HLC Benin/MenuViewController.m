//
//  MenuViewController.m
//  HLC Benin
//
//  Created by AKEJU on 1/20/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import "MenuViewController.h"
#import "ViewController.h"



@implementation MenuViewController
@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //theDelegate = [[UIApplication sharedApplication] delegate];
    
    menuitems = [[NSMutableArray alloc] initWithObjects:@"Hotels in Benin",
                   @"Previous Events",
                   @"E-store",@"Contact Us",@"Ministry Websites",@"Share App", @"Close",nil];
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Override to allow orientations other than the default portrait orientation.
    return YES;
}


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [menuitems count];
	
}


// Customize the appearance of table view cells.

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	
	if (cell == nil) {
		
		cell = [[UITableViewCell alloc]
                initWithStyle:UITableViewCellStyleDefault
                reuseIdentifier:CellIdentifier];
        /**cell = [[[UITableViewCell alloc]
		 initWithStyle:UITableViewCellStyleSubtitle
		 reuseIdentifier:CellIdentifier] autorelease];**/
    }
	
	
    // Configure the cell...
	
	
	if (tableView.tag==1){
        
        cell.textLabel.text = [menuitems objectAtIndex:indexPath.row];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.textLabel.font = [UIFont fontWithName:@"Arial" size:13];
        
        UIView *bgColorView = [[UIView alloc] init];
        
        bgColorView.backgroundColor = [UIColor whiteColor];
        
        cell.selectedBackgroundView = bgColorView;
        
        if (indexPath.row == 0) {
            UIImage *image = [UIImage imageNamed:@"accommodationbenin-1.png"];
            cell.imageView.image = image;
            
        }
        
        if (indexPath.row == 1) {
            UIImage *image = [UIImage imageNamed:@"previousbenin-1.png"];
            cell.imageView.image = image;
        }
        
        if (indexPath.row == 2) {
            UIImage *image = [UIImage imageNamed:@"estorebenin-1.png"];
            cell.imageView.image = image;
        }
        if (indexPath.row == 3) {
            UIImage *image = [UIImage imageNamed:@"contactbenin-1.png"];
            cell.imageView.image = image;
        }
        if (indexPath.row == 4) {
            UIImage *image = [UIImage imageNamed:@"minweb-1.png"];
            cell.imageView.image = image;
        }
        if (indexPath.row == 5) {
            UIImage *image = [UIImage imageNamed:@"shareapp-1.png"];
            cell.imageView.image = image;
       
        }

    
        if (indexPath.row == 6) {
            UIImage *image = [UIImage imageNamed:@"exitbenin-1.png"];
            cell.imageView.image = image;
            
        }
        


            }
    
    return cell;
    
}


/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */


/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }
 else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }
 }
 */


/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */


/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
    AppDelegate *theDelegate = [[UIApplication sharedApplication] delegate];
	
	NSString* eventSelected = [menuitems objectAtIndex:indexPath.row];
	
	[theDelegate.viewController performActionMenu:eventSelected];
    
    [self dismissModalViewControllerAnimated:YES];
    
    
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
