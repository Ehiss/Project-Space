//
//  NotedController.h
//  HLC Benin
//
//  Created by AKEJU on 1/31/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "ViewController.h"

@interface NotedController : UIViewController<UIAlertViewDelegate>{


    //notes
    IBOutlet UITextField *noteTitle;
    IBOutlet UIButton *create;
    IBOutlet UIButton *cancel;
    IBOutlet UIView *noteContainer;
    


}

-(void)openNotes;
-(void)makeNewNote;
-(IBAction)createNote: (id)sender;
-(IBAction)cancelNote: (id)sender;
-(IBAction)Exit: (id)sender;

@end
