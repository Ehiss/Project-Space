//
//  ViewController.m
//  HLC Benin
//
//  Created by AKEJU on 1/15/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//
//#define kOFFSET_FOR_KEYBOARD 80.0

#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
#import "ViewController.h"
#import "MenuViewController.h"
#import "InviteViewController.h"
#import <Social/Social.h>
#import "yookoscell.h"
#import "CreatenoteViewController.h"
#import "ViewnoteViewController.h"
#import "CreateNoteViewController.h"
#import "AppDelegate.h"
#import "NotedController.h"
//#import <Twitter/Twitter.h>

@implementation ViewController

@synthesize popoverController;
@synthesize hasRated,rateChecker,checker,another,noteDateandTime,noteTitleandAuthors,readNoteChecker,getNote,alertIndexNumber,alertIndexNumber2,alertItem,alertItem2,alertString,theTitle;


- (void)alertView:(UIAlertView *)alert clickedButtonAtIndex:(NSInteger)buttonIndex
{
	
	NSString *selectedBook = [alert buttonTitleAtIndex:buttonIndex];
    
    if([selectedBook isEqualToString:@"Rate Now"]){
        
        hasRated = 1;
        [[NSUserDefaults standardUserDefaults] setInteger: hasRated forKey: @"hasRatedCheck"];
		[[NSUserDefaults standardUserDefaults] synchronize];
        
        NSURL *theURL = [NSURL URLWithString:@"http://videoshare.loveworldapis.com/rateApp/hlcbenin2014.php"] ;
        
        
        [[UIApplication sharedApplication] openURL:theURL];
        
    }
}


-(void)viewDidAppear:(BOOL)animated{
	
	//self.navigationController.navigationBarHidden = YES;
	
	
	NSString *fileName2 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/lastArray.txt"];
	
	if(noteTitleandAuthors == nil){
		noteTitleandAuthors = [[NSMutableArray alloc] initWithContentsOfFile:fileName2];
		
	}
	
	NSString *fileName3 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/dateArray.txt"];
	
	if(noteDateandTime == nil){
		noteDateandTime = [[NSMutableArray alloc] initWithContentsOfFile:fileName3];
		
	}
	
	NSString *fileName4 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/alertItems.txt"];
	
	if(alertItem == nil){
		alertItem = [[NSMutableArray alloc] initWithContentsOfFile:fileName4];
		
	}
	
	NSString *fileName5 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/alertNumber.txt"];
	
	if(alertIndexNumber == nil){
		alertIndexNumber = [[NSMutableArray alloc] initWithContentsOfFile:fileName5];
		
	}
	
	NSString *fileName6 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/alertItems2.txt"];
	
	if(alertItem2 == nil){
		alertItem2 = [[NSMutableArray alloc] initWithContentsOfFile:fileName6];
		
	}
	
	NSString *fileName7 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/alertNumber2.txt"];
	
	if(alertIndexNumber2 == nil){
		alertIndexNumber2 = [[NSMutableArray alloc] initWithContentsOfFile:fileName7];
		
	}
	
}



-(IBAction)website:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://higherlifeconferencebenincity.org/"]];


}


- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    //[noteArea resignFirstResponder];
    return NO;
}
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
        
        [textView resignFirstResponder];
    return YES;;
}
- (void)playVideo:(NSString*)theVideoUrl{
    
	NSURL *url22 = [NSURL URLWithString: theVideoUrl];
    
    moviePlayer =
    [[MPMoviePlayerController alloc]
     initWithContentURL:url22];
    [moviePlayer prepareToPlay];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:moviePlayer];
    
    moviePlayer.controlStyle = MPMovieControlStyleDefault;
    [moviePlayer setMovieSourceType:MPMovieSourceTypeStreaming];
    moviePlayer.shouldAutoplay = YES;
	moviePlayer.view.frame = CGRectMake(0, 0, 251, 186);
	[thePlayerView addSubview:moviePlayer.view];
    //[moviePlayer prepareToPlay];
    
}
- (void)playVideo2:(NSString*)theVideoUrl2{
    
	NSURL *url22 = [NSURL URLWithString: theVideoUrl2];
    
    moviePlayer =
    [[MPMoviePlayerController alloc]
     initWithContentURL:url22];
    [moviePlayer prepareToPlay];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:moviePlayer];
    
    moviePlayer.controlStyle = MPMovieControlStyleDefault;
    [moviePlayer setMovieSourceType:MPMovieSourceTypeStreaming];
    moviePlayer.shouldAutoplay = YES;
	moviePlayer.view.frame = CGRectMake(0, 0, 251, 186);
	[thePlayerView2 addSubview:moviePlayer.view];
    //[moviePlayer prepareToPlay];
    
}

- (void)playVideo3:(NSString*)theVideoUrl3{
    
	NSURL *url22 = [NSURL URLWithString: theVideoUrl3];
    
    moviePlayer =
    [[MPMoviePlayerController alloc]
     initWithContentURL:url22];
    [moviePlayer prepareToPlay];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:moviePlayer];
    
    moviePlayer.controlStyle = MPMovieControlStyleDefault;
    [moviePlayer setMovieSourceType:MPMovieSourceTypeStreaming];
    moviePlayer.shouldAutoplay = YES;
	moviePlayer.view.frame = CGRectMake(0, 0, 251, 186);
	[thePlayerView3 addSubview:moviePlayer.view];
    //[moviePlayer prepareToPlay];
    
}

- (void)playVideo4:(NSString*)theVideoUrl4{
    
	NSURL *url22 = [NSURL URLWithString: theVideoUrl4];
    
    moviePlayer =
    [[MPMoviePlayerController alloc]
     initWithContentURL:url22];
    [moviePlayer prepareToPlay];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:moviePlayer];
    
    moviePlayer.controlStyle = MPMovieControlStyleDefault;
    [moviePlayer setMovieSourceType:MPMovieSourceTypeStreaming];
    moviePlayer.shouldAutoplay = YES;
	moviePlayer.view.frame = CGRectMake(0, 0, 251, 186);
	[thePlayerView4 addSubview:moviePlayer.view];
    //[moviePlayer prepareToPlay];
    
}


- (void) moviePlayBackDidFinish:(NSNotification*)notification {
	
    moviePlayer = [notification object];
	
    [[NSNotificationCenter defaultCenter] removeObserver:self
													name:MPMoviePlayerPlaybackDidFinishNotification
												  object:moviePlayer];
	
	if ([moviePlayer
		 respondsToSelector:@selector(setFullscreen:animated:)])
	{
		[moviePlayer.view removeFromSuperview];
	}	
}




-(IBAction)backtoprevbtn:(id)sender{
    
    if(moviePlayer != nil){
        
        [moviePlayer stop];
        
    }

    [mainview addSubview:previouseventscroll];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [contactusscroll setHidden:YES];
    [menupopview setHidden:YES];
    [estoreview setHidden:YES];
    [previouseventscroll setHidden:NO];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    [minsitescroll setHidden:YES];


}
-(IBAction)backtoprevbtn2:(id)sender{

    if(moviePlayer != nil){
        
        [moviePlayer stop];
        
    }


    [mainview addSubview:previouseventscroll];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [contactusscroll setHidden:YES];
    [menupopview setHidden:YES];
    [estoreview setHidden:YES];
    [previouseventscroll setHidden:NO];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    [minsitescroll setHidden:YES];
}
-(IBAction)backtoprevbtn3:(id)sender{

    if(moviePlayer != nil){
        
        [moviePlayer stop];
        
    }

    [mainview addSubview:previouseventscroll];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [contactusscroll setHidden:YES];
    [menupopview setHidden:YES];
    [estoreview setHidden:YES];
    [previouseventscroll setHidden:NO];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    [minsitescroll setHidden:YES];
}
-(IBAction)backtoprevbtn4:(id)sender{

    if(moviePlayer != nil){
        
        [moviePlayer stop];
        
    }

    [mainview addSubview:previouseventscroll];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [contactusscroll setHidden:YES];
    [menupopview setHidden:YES];
    [estoreview setHidden:YES];
    [previouseventscroll setHidden:NO];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    [minsitescroll setHidden:YES];


}


-(IBAction)HLCusabtn:(id)sender{


    [mainview addSubview:hlcusaview];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [contactusscroll setHidden:YES];
    [menupopview setHidden:YES];
    [estoreview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    [hlcusaview setHidden:NO];
    [hlclagosview setHidden:YES];
    [minsitescroll setHidden:YES];
    
    [self playVideo:@"http://wpc.1f21.edgecastcdn.net/001F21/hlc/ios2/hlcUSA.mp4"];
    //[self playVideo2:@""];
    //[self playVideo3:@""];
    //[self playVideo4:@""];



}

-(IBAction)HLClagosbtn:(id)sender{

    [mainview addSubview:hlclagosview];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [contactusscroll setHidden:YES];
    [menupopview setHidden:YES];
    [estoreview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    [hlcusaview setHidden:YES];
    [hlclagosview setHidden:NO];
    [hlcukview setHidden:YES];
    [hlccanadaview setHidden:YES];
    [minsitescroll setHidden:YES];
    
    //[self playVideo:@""];
    [self playVideo2:@"http://wpc.1f21.edgecastcdn.net/001F21/hlc/ios2/hlcLAGOS.mp4"];
    
    //[self playVideo3:@""];
    //[self playVideo4:@""];




}
-(IBAction)HLCukbtn:(id)sender{


    [mainview addSubview:hlcukview];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [contactusscroll setHidden:YES];
    [menupopview setHidden:YES];
    [estoreview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    [hlcusaview setHidden:YES];
    [hlcukview setHidden:NO];
    [hlclagosview setHidden:YES];
    [hlccanadaview setHidden:YES];
    [minsitescroll setHidden:YES];
    
    //[self playVideo:@""];
    //[self playVideo2:@""];
    
    [self playVideo3:@"http://wpc.1f21.edgecastcdn.net/001F21/hlc/ios2/hlcUK.mp4"];
    //[self playVideo4:@""];



}

-(IBAction)HLCcanadabtn:(id)sender{
    
    [mainview addSubview:hlccanadaview];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [contactusscroll setHidden:YES];
    [menupopview setHidden:YES];
    [estoreview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    [hlcusaview setHidden:YES];
    [hlccanadaview setHidden:NO];
    [hlclagosview setHidden:YES];
    [hlcukview setHidden:YES];
    [minsitescroll setHidden:YES];
    
   // [self playVideo:@""];
    //[self playVideo2:@""];
    //[self playVideo3:@""];
    [self playVideo4:@"http://wpc.1f21.edgecastcdn.net/001F21/hlc/ios2/hlcCANADA.mp4"];

}

-(IBAction)mail:(id)sender{
    
    if([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *composer = [[MFMailComposeViewController alloc] init];
        composer.mailComposeDelegate = self;
        
        [composer setSubject:@""];
        [composer setToRecipients:[NSArray arrayWithObject:@"hlcbenin2014@loveworldmail.org.za"]];
        [composer setModalPresentationStyle:UIModalPresentationFormSheet];
        [composer setMessageBody:@"" isHTML:NO];
        
        [self presentViewController:composer animated:YES completion:nil];
        
        
        //[poopoverDelegate.detailViewController.popoverController3 dismissPopoverAnimated:YES];
        //[composer release];
    }
    
    else {
        
        NSString *title = @"Your Device can not send mails at this time, please configure an e-mail account on this device to be able to send mail. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        //[alert release];
        //[title release];
    }}


-(IBAction)sendMail:(id)sender{
    
    /** if (theDelegate.viewController.popoverController8 != nil) {
     [theDelegate.viewController.popoverController8 dismissPopoverAnimated:YES];
     }**/
    
    if([MFMailComposeViewController canSendMail]) {
		MFMailComposeViewController *composer = [[MFMailComposeViewController alloc] init];
		composer.mailComposeDelegate = self;
		
		[composer setSubject:@"Higher Life Conference,Benin-city App"];
		//[composer setToRecipients:[NSArray arrayWithObject:@""]];
        [composer setModalPresentationStyle:UIModalPresentationFullScreen];
		[composer setMessageBody:@"Dearly Beloved, \n\n This is introducing the Higher Life Conference,Benin-city app! \n\n A resourceful event management application built specifically for the Higher Life Conference,Benin-city app. This application is a must-get app as it has several features that makes it very useful before, during and after the event. \n\n For more information please visit http://bit.ly/hlcbenincitymobileapp" isHTML:NO];
		
		[self presentViewController:composer animated:YES completion:nil];
        
		//[composer release];
        
        
	}
	
	else {
		
		NSString *title = @"Your Device can not send mails at this time, please configure an e-mail account on this device to be able to send mail. Thank You";
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
		[alert show];
		//[alert release];
		//[title release];
		
	}
}

- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
	
	switch (result)
    {
        case MFMailComposeResultCancelled:{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Mail Cancelled:"
															message:@"You cancelled the operation, so no email message was queued or sent Thank You."
														   delegate:nil
												  cancelButtonTitle:@"OK"
												  otherButtonTitles:nil];
			[alert show];
			//[alert release];
		}
            break;
        case MFMailComposeResultSaved:{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Mail Saved:"
															message:@"Your message has been saved to your drafts folder. Thank You"
														   delegate:nil
												  cancelButtonTitle:@"OK"
												  otherButtonTitles:nil];
			[alert show];
			//[alert release];
		}
			
            break;
        case MFMailComposeResultSent:{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Thank You!"
															message:@"Your message has been sent successfully."
														   delegate:nil
												  cancelButtonTitle:@"OK"
												  otherButtonTitles:nil];
			[alert show];
			//[alert release];
		}
            break;
        case MFMailComposeResultFailed:{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Mail Failed:"
															message:@"Your email message was not saved or queued, possibly due to an error. Please try again. Thank You"
														   delegate:nil
												  cancelButtonTitle:@"OK"
												  otherButtonTitles:nil];
			[alert show];
			//[alert release];
		}
			
            break;
        default:
            NSLog(@"Mail not sent.");
            break;
    }
	
	
	
	[self dismissViewControllerAnimated:YES completion:nil];
	
	/**UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Thank You For Contacting Flaires!"
     message:@"Your message has been sent successfully."
     delegate:nil
     cancelButtonTitle:@"OK"
     otherButtonTitles:nil];
     [alert show];
     [alert release];**/
}

-(IBAction)postToFacebook:(id)sender{
    
    if ([deviceOSVersion isEqualToString:@"6.1"] || [deviceOSVersion isEqualToString:@"6.0"]){

    
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook]) {
        
        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        
        [controller setInitialText:@"This is introducing the Higher Life Conference,Benin-City! A resourceful event management application built specifically for the Higher Life Conference,Benin-city app."];
        [controller addURL:[NSURL URLWithString:@"http://bit.ly/hlcbenincitymobileapp"]];
        [controller addImage:[UIImage imageNamed:@"57_icon_hlcbenin-1.png"]];
        
        [self presentViewController:controller animated:YES completion:Nil];
        

    }
    else{
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Unable to share on facebook at this time, please ensure you are logged into your facebook account from the facebook App settings on your device. Thank You!!"
                                                        message:nil
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        //[alert release];
    }
    }
    else{
        
        NSString *title = @"You require iPad IOS 6 to perform sharing operations, please upgrade to the latest iPad OS and try again. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];

        
    }
}

-(IBAction)postToTwitter:(id)sender{
    
    if ([deviceOSVersion isEqualToString:@"6.1"] || [deviceOSVersion isEqualToString:@"6.0"]){
    
    if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter])
        
    {
        SLComposeViewController *tweetSheet = [SLComposeViewController
                                               composeViewControllerForServiceType:SLServiceTypeTwitter];
        [tweetSheet setInitialText:@"This is introducing the Higher Life Conference,Benin-City IOS app! Get yours now."];
        [tweetSheet addURL:[NSURL URLWithString:@"http://bit.ly/hlcbenincitymobileapp"]];
        [tweetSheet addImage:[UIImage imageNamed:@"57_icon_hlcbenin-1.png"]];
        
        [self presentViewController:tweetSheet animated:YES completion:nil];
        
        
    }
    else{
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Unable to share on twitter at this time, please ensure you are logged into your twitter account from the twitter App settings on your device. Thank You!!"
                                                            message:nil
                                                           delegate:nil
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
            //[alert release];
        }
    }
    else{
        
        NSString *title = @"You require iPad IOS 6 to perform sharing operations, please upgrade to the latest iPad OS and try again. Thank You";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        
        [alert show];
    }
    }

-(IBAction)takenote:(id)sender{
    
    
    NotedController *noteViewController2 =
	[[NotedController alloc]
	 initWithNibName:@"NotedController" bundle:nil];
	
	[self.navigationController
	 pushViewController:noteViewController2 animated:YES];
    
   //NSString *theTitle = @"Diary";
	
	/**UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:nil delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Open a Note", @"New Note", nil];
	[alert show];**/
	

    
    //[writecomment setText:@""];
   // [countryfield setText:@"   Country"];

   /** [mainview addSubview:takenoteview];
     [aboutview setHidden:YES];
     [regview setHidden:YES];
     [Testview setHidden:YES];
     [Expview setHidden:YES];
     [salview setHidden:YES];
     [Highview setHidden:YES];
     [scheduleview setHidden:YES];
     [contactusscroll setHidden:YES];
     [menupopview setHidden:YES];
     [estoreview setHidden:YES];
    [minsitescroll setHidden:YES];
    [takenoteview setHidden:NO];**/
    
    //[takenoteview setHidden:YES];
    
    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    //[taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_on_tk.png"] forState:UIControlStateNormal];
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];

}









-(IBAction)invitefriends:(id)sender{
    
   /** [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_on_iv_friends.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];**/



    InviteViewController *witness =[[InviteViewController alloc] initWithNibName:@"InviteViewController" bundle:nil];
    UINavigationController *tatNavcon2 = [[UINavigationController alloc] initWithRootViewController:witness];
    //[invite release];
    tatNavcon2.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    tatNavcon2.modalPresentationStyle = UIModalPresentationFormSheet;
    //[self presentModalViewController:tatNavcon2 animated:YES];
    [self presentViewController:tatNavcon2 animated:YES completion:nil];


}

-(void)performActionMenu:(NSString*)Menuevents{


    NSString* theEvent = Menuevents ;
        
    
    if([theEvent isEqualToString:@"Hotels in Benin"]){
        
        [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
        [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
        [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
        [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
        
        [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
        
        [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
        [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
        [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
        [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
        [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];
        
        [mainview addSubview:Hotelscrollview];
        [aboutview setHidden:YES];
        [regview setHidden:YES];
        [Testview setHidden:YES];
        [Expview setHidden:YES];
        [salview setHidden:YES];
        [Highview setHidden:YES];
        [scheduleview setHidden:YES];
        [contactusscroll setHidden:YES];
        [menupopview setHidden:YES];
        [estoreview setHidden:YES];
        [Hotelscrollview setHidden:NO];
        [previouseventscroll setHidden:YES];
        [shareappview setHidden:YES];
        [minsitescroll setHidden:YES];
        

        
         NSLog(@"hotels");
    }
    
    else
        if([theEvent isEqualToString:@"Previous Events"]){
            
            [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
            [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
            [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
            [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
            
            [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
            
            [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
            [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
            [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
            [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
            [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];

            
            [mainview addSubview:previouseventscroll];
            [aboutview setHidden:YES];
            [regview setHidden:YES];
            [Testview setHidden:YES];
            [Expview setHidden:YES];
            [salview setHidden:YES];
            [Highview setHidden:YES];
            [scheduleview setHidden:YES];
            [contactusscroll setHidden:YES];
            [menupopview setHidden:YES];
            [estoreview setHidden:YES];
            [previouseventscroll setHidden:NO];
            [Hotelscrollview setHidden:YES];
            [shareappview setHidden:YES];
            [minsitescroll setHidden:YES];
            
            
            
            NSLog(@"previous");
        }
    
        else
            if([theEvent isEqualToString:@"Program Schedule"]){
                
                [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
                [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
                [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
                [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
                
                [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
                
                [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
                [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
                [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
                [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
                [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];

                
                [aboutview setHidden:YES];
                [regview setHidden:YES];
                [Testview setHidden:YES];
                [Expview setHidden:YES];
                [salview setHidden:YES];
                [Highview setHidden:YES];
                [scheduleview setHidden:YES];
                [contactusscroll setHidden:YES];
                [menupopview setHidden:YES];
                [estoreview setHidden:YES];
                [previouseventscroll setHidden:YES];
                [Hotelscrollview setHidden:YES];
                [shareappview setHidden:YES];
                [minsitescroll setHidden:YES];

                

                
                 NSLog(@"program");
                
                
                            }
    
    
            else
                if([theEvent isEqualToString:@"E-store"]){
                    
                    
                    /**[taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
                    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
                    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
                    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
                    
                    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
                    
                    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
                    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
                    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
                    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];**/


                    
                    
                    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                                  @"https://itunes.apple.com/ng/app/pastor-chris-digital-library/id649362246?mt=8"]];
                    
                    

                    
                    /**[mainview addSubview:estoreview];
                    [aboutview setHidden:YES];
                    [regview setHidden:YES];
                    [Testview setHidden:YES];
                    [Expview setHidden:YES];
                    [salview setHidden:YES];
                    [Highview setHidden:YES];
                    [scheduleview setHidden:YES];
                    [contactusscroll setHidden:YES];
                    [menupopview setHidden:YES];
                    [estoreview setHidden:NO];**/
                    

                    
                    NSLog(@"estore");
                    
                    
                }
    
                else
                    if([theEvent isEqualToString:@"Contact Us"]){
                        
                        [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
                        [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
                        [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
                        [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
                        
                        [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
                        
                        [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
                        [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
                        [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
                        [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
                        [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];

                        
                        [mainview addSubview:contactusscroll];
                        [aboutview setHidden:YES];
                        [regview setHidden:YES];
                        [Testview setHidden:YES];
                        [Expview setHidden:YES];
                        [salview setHidden:YES];
                        [Highview setHidden:YES];
                        [scheduleview setHidden:YES];
                        [contactusscroll setHidden:NO];
                        [menupopview setHidden:YES];
                        [estoreview setHidden:YES];
                        [previouseventscroll setHidden:YES];
                        [Hotelscrollview setHidden:YES];
                        [shareappview setHidden:YES];
                        [minsitescroll setHidden:YES];
                        
                        
                        NSLog(@"contact");
                        
                        
                    }

                    else
                        if([theEvent isEqualToString:@"Ministry Websites"]){
                            
                            [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
                            [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
                            [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
                            [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
                            
                            [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
                            
                            [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
                            [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
                            [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
                            [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
                            [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];

                            
                            [mainview addSubview:minsitescroll];
                            [aboutview setHidden:YES];
                            [regview setHidden:YES];
                            [Testview setHidden:YES];
                            [Expview setHidden:YES];
                            [salview setHidden:YES];
                            [Highview setHidden:YES];
                            [scheduleview setHidden:YES];
                            [contactusscroll setHidden:YES];
                            [menupopview setHidden:NO];
                            [estoreview setHidden:YES];
                            [previouseventscroll setHidden:YES];
                            [Hotelscrollview setHidden:YES];
                            [shareappview setHidden:YES];
                            [minsitescroll setHidden:NO];

                            
                            NSLog(@"min web");
                            
                            
                        }
    
                        else
                            if([theEvent isEqualToString:@"Share App"]){
                                
                                [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
                                [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
                                [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
                                [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
                                
                                [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
                                
                                [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
                                [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
                                [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
                                [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
                                [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];

                                
                                [mainview addSubview:shareappview];
                                [aboutview setHidden:YES];
                                [regview setHidden:YES];
                                [Testview setHidden:YES];
                                [Expview setHidden:YES];
                                [salview setHidden:YES];
                                [Highview setHidden:YES];
                                [scheduleview setHidden:YES];
                                [contactusscroll setHidden:YES];
                                [menupopview setHidden:YES];
                                [estoreview setHidden:YES];
                                [previouseventscroll setHidden:YES];
                                [Hotelscrollview setHidden:YES];
                                [shareappview setHidden:NO];
                                [minsitescroll setHidden:YES];

                                
                                NSLog(@"share");
                                
                                
                            }
    
                            else
                                if([theEvent isEqualToString:@"Close"]){
                                    
                                    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
                                    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_on_abt2.png"] forState:UIControlStateNormal];
                                    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
                                    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
                                    
                                    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
                                    
                                    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
                                    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
                                    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
                                    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"]
                                                   forState:UIControlStateNormal];
                                    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];
                                    
                                    NSURLRequest *urlReq = [[NSURLRequest alloc] initWithURL:[NSURL fileURLWithPath:
                                                                                              [[NSBundle mainBundle] pathForResource:
                                                                                               @"aboutimage" ofType:@"html"]isDirectory:NO]];
                                    
                                    [aboutwebview loadRequest:urlReq];
                                    
                                    
                                    [mainview addSubview:aboutwebview];
                                    [aboutview setHidden:NO];
                                    [regview setHidden:YES];
                                    [Testview setHidden:YES];
                                    [Expview setHidden:YES];
                                    [salview setHidden:YES];
                                    [Highview setHidden:YES];
                                    [scheduleview setHidden:YES];
                                    [previouseventscroll setHidden:YES];
                                    [Hotelscrollview setHidden:YES];
                                    [shareappview setHidden:YES];

                                    
                                    
                                    NSLog(@"exit");
                                    
                                    
                                }
    



}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    
    return YES;
}


-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
    
    NSString *title = @"Your device is not connected to the internet. Please ensure you have a good internet connection and try again. Thank You";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    [alert show];
    
   // [aboutactivity setHidden:YES];
    
}

-(void)webViewDidStartLoad:(UIWebView *)webView{
    
    [aboutactivity startAnimating];
    [aboutactivity setHidden:NO];
    
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    
    
    [aboutactivity stopAnimating];
    [aboutactivity setHidden:YES];
    
}

-(IBAction)hlcreport:(id)sender{

    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_on_hlc_rep.png"] forState:UIControlStateNormal];

    
    
    [mainview addSubview:reportsview];
    
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    [reportsview setHidden:NO];

    [reportswebview loadRequest:[NSURLRequest requestWithURL:
                             [NSURL URLWithString:
                              @"http://higherlifeconferencebenincity.org/category/hlc-reports/"]]];
    

}


-(IBAction)expectbtn:(id)sender{

    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_on_exp.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];


    
    [Expwebview loadRequest:[NSURLRequest requestWithURL:
                                [NSURL URLWithString:
                                 @"http://higherlifeconferencebenincity.org/expectations/"]]];
    
    [mainview addSubview:Expview];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:NO];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];

}

-(IBAction)salvationebtn:(id)sender{
    
    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_on_sal.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];


    [salwebview loadRequest:[NSURLRequest requestWithURL:
                               [NSURL URLWithString:
                                @"http://www.christembassy.org/hikanotes/salvationcall#.Ut7M-WTTky4"]]];
    
    
    
    [mainview addSubview:salview];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:NO];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];

    
}
-(IBAction)testimbtn:(id)sender{

    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_on_tst.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];

    
    [Testwebview loadRequest:[NSURLRequest requestWithURL:
                             [NSURL URLWithString:
                              @"http://videoshare.loveworldapis.com/hlcbenin/testimonies.php"]]];
    
    [mainview addSubview:Testview];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:NO];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];

    
}

-(IBAction)highlightbtn:(id)sender{
    
    
    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_on_hig.png"] forState:UIControlStateNormal];
    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];


    [Highwebview loadRequest:[NSURLRequest requestWithURL:
                               [NSURL URLWithString:
                                @"http://videoshare.loveworldapis.com/ippc2013/highlights.php"]]];
    
    
    
    [mainview addSubview:Highwebview];
    
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:NO];
    [scheduleview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
    


}

-(IBAction)regbtn:(id)sender{
    
   // [self showCustom];
    
    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_on_reg.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];
    
    [regwebview loadRequest:[NSURLRequest requestWithURL:
                              [NSURL URLWithString:
                               @"http://hlcbenin.loveworldapis.com/registration/"]]];

    
    
    [mainview addSubview:regview];
    [aboutview setHidden:YES];
    [regview setHidden:NO];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];

}

-(IBAction)schedulebtn:(id)sender{
    
    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_off_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_on_sch.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];
    
    NSURLRequest *urlReq = [[NSURLRequest alloc] initWithURL:[NSURL fileURLWithPath:
                                                              [[NSBundle mainBundle] pathForResource:
                                                               @"schedule" ofType:@"html"]isDirectory:NO]];
    [schedulewebview loadRequest:urlReq];
    
    [mainview addSubview:scheduleview];

    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:NO];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];

}

-(IBAction)aboutbtn:(id)sender{
    
    [taknoteoutletbtn setImage:[UIImage imageNamed:@"ic_off_tk2.png"] forState:UIControlStateNormal];
    [abtoutletbtn setImage:[UIImage imageNamed:@"ic_on_abt2.png"] forState:UIControlStateNormal];
    [testoutletbtn setImage:[UIImage imageNamed:@"ic_off_tst2.png"] forState:UIControlStateNormal];
    [expectoutletbtn setImage:[UIImage imageNamed:@"ic_off_exp2.png"] forState:UIControlStateNormal];
    
    [inviteoutletbtn setImage:[UIImage imageNamed:@"ic_off_iv_friends2.png"] forState:UIControlStateNormal];
    
    [schoutletbtn setImage:[UIImage imageNamed:@"ic_off_sch2.png"] forState:UIControlStateNormal];
    [saloutletbtn setImage:[UIImage imageNamed:@"ic_off_sal2.png"] forState:UIControlStateNormal];
    [regoutletbtn setImage:[UIImage imageNamed:@"ic_off_reg2.png"] forState:UIControlStateNormal];
    [Highoutletbtn setImage:[UIImage imageNamed:@"ic_off_hig2.png"] forState:UIControlStateNormal];
    [reportoutletbtn setImage:[UIImage imageNamed:@"ic_off_hlc_rep-1.png"] forState:UIControlStateNormal];

    NSURLRequest *urlReq = [[NSURLRequest alloc] initWithURL:[NSURL fileURLWithPath:
                                                              [[NSBundle mainBundle] pathForResource:
                                                               @"aboutimage" ofType:@"html"]isDirectory:NO]];
    
    [aboutwebview loadRequest:urlReq];

    
    [mainview addSubview:aboutwebview];
    [aboutview setHidden:NO];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [previouseventscroll setHidden:YES];
    [Hotelscrollview setHidden:YES];
    [shareappview setHidden:YES];
}


-(IBAction)Menupop:(id)sender{
    [aboutactivity stopAnimating];
    [aboutactivity setHidden:YES];

   /** if ([menupopview isHidden]) {
            
        [menupopview setHidden:NO];
       
            
    }
    
    else{
        
        
        [menupopview setHidden:YES];
        
        
        
    }**/
    
    
    //MenuViewController *display = [[MenuViewController alloc] init];
   // [self.navigationController pushViewController:display animated:YES];
    
    //[self.popoverController dismissPopoverAnimated:YES];
    
    
    //MenuViewController *login =[[MenuViewController alloc] initWithNibName:@"MenuViewController" bundle:nil];
	//UINavigationController *tatNavcon2 = [[UINavigationController alloc] initWithRootViewController:login];
	//[login release];
   // login.delegate = self;
	//login.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	//login.modalPresentationStyle = UIModalPresentationFormSheet;
	//[self presentModalViewController:login animated:YES];
    //[self.presentingViewController:login animated:YES];
    
	//[tatNavcon2 release];

    
    MenuViewController *login =[[MenuViewController alloc] initWithNibName:@"MenuViewController" bundle:nil];
	//UINavigationController *tatNavcon2 = [[UINavigationController alloc] initWithRootViewController:login];
	//[login release];
    login.delegate = self;
	login.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	login.modalPresentationStyle = UIModalPresentationFormSheet;
	[self presentModalViewController:login animated:YES];
	//[tatNavcon2 release];

    
    
    
}

-(IBAction)button1:(id)sender{

    NSLog(@"Button1");
}


-(IBAction)button2:(id)sender{
    
    NSLog(@"Button2");
    
}

 



- (void)viewDidLoad

{
    
    
    self.navigationController.navigationBarHidden = YES;
    
    UIDevice *dev = [UIDevice currentDevice];
    
    deviceOSVersion = dev.systemVersion;
    
    [[NSUserDefaults standardUserDefaults] setValue:deviceOSVersion forKey: @"deviceosversion"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
        
        [contactusscroll setScrollEnabled:YES];
        contactusscroll.contentSize = CGSizeMake(320*0.0, 372);
        contactusscroll.pagingEnabled = NO;
        contactusscroll.scrollEnabled = YES;
    
    
   [Hotelscrollview setScrollEnabled:YES];
    Hotelscrollview.contentSize = CGSizeMake(320*0.0, 372);
    Hotelscrollview.pagingEnabled = NO;
    Hotelscrollview.scrollEnabled = YES;
    //Hotelscrollview.clipsToBounds = YES;
    
    [minsitescroll setScrollEnabled:YES];
    minsitescroll.contentSize = CGSizeMake(320*0.0, 372);
    minsitescroll.pagingEnabled = NO;
    minsitescroll.scrollEnabled = YES;
    
    [previouseventscroll setScrollEnabled:YES];
    previouseventscroll.contentSize = CGSizeMake(320*0.0, 372);
    previouseventscroll.pagingEnabled = NO;
    previouseventscroll.scrollEnabled = YES;
    // Hotelscrollview.clipsToBounds = NO;
    
    
    [Menuscrollview setScrollEnabled:YES];
    Menuscrollview.contentSize = CGSizeMake(320*2.4, 49);
    Menuscrollview.pagingEnabled = NO;
    Menuscrollview.scrollEnabled = YES;
    
    
    
    
    [hlccanadaview setScrollEnabled:YES];
    hlccanadaview.contentSize = CGSizeMake(320*0.0, 372);
    hlccanadaview.pagingEnabled = NO;
    hlccanadaview.scrollEnabled = YES;
    
    
    [hlclagosview setScrollEnabled:YES];
    hlclagosview.contentSize = CGSizeMake(320*0.0, 372);
    hlclagosview.pagingEnabled = NO;
    hlclagosview.scrollEnabled = YES;
    
    
    [hlcusaview setScrollEnabled:YES];
    hlcusaview.contentSize = CGSizeMake(320*0.0, 372);
    hlcusaview.pagingEnabled = NO;
    hlcusaview.scrollEnabled = YES;

    
    [hlcukview setScrollEnabled:YES];
    hlcukview.contentSize = CGSizeMake(320*0.0, 372);
    hlcukview.pagingEnabled = NO;
    hlcukview.scrollEnabled = YES;
    
    [super viewDidLoad];
    
    NSURLRequest *urlReq = [[NSURLRequest alloc] initWithURL:[NSURL fileURLWithPath:
                                                              [[NSBundle mainBundle] pathForResource:
                                                               @"aboutimage" ofType:@"html"]isDirectory:NO]];
    
    [aboutwebview loadRequest:urlReq];
    
    
    [mainview addSubview:aboutwebview];
    [aboutwebview setHidden:NO];
    

    
    }


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    if(tableView.tag == 1){
        
        return [ministrysitesarray count];
    }
    else
        if(tableView.tag == 2){
            
            return [ministrysitesarray count];
        }
            else
                return [generalSettingsItems count];
}

- (UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
    static NSString* CellIdentifier = @"Cell";
    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        
    }
    
    NSString * cellValue=nil;
    NSString * celldetailValue=nil;
    
    if (tableView.tag==1){
        
        cell.textLabel.text = [ministrysitesarray objectAtIndex:indexPath.row];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.textLabel.font = [UIFont fontWithName:@"Arial" size:13];
        
        UIView *bgColorView = [[UIView alloc] init];
        
        bgColorView.backgroundColor = [UIColor darkGrayColor];
        
        cell.selectedBackgroundView = bgColorView;
        
        cellValue = [ministrysitesarray objectAtIndex:indexPath.row];
        //celldetailValue = [textArray objectAtIndex:indexPath.row];
        
        
        cell.textLabel.text=cellValue;
        cell.detailTextLabel.text = celldetailValue;
        
      // cell.imageView.image = [menuimages objectAtIndex:indexPath.row];
        cell.textLabel.font = [UIFont fontWithName:@"Arial Bold" size:17];
        
        
        if (indexPath.row == 0) {
            
            UIImage *image = [UIImage imageNamed:@"Untitled-12.png"];
            cell.imageView.image = image;
            
            //[menupopview setHidden:YES];
            
           
            
        }
        
        if (indexPath.row == 1) {
            
            UIImage *image = [UIImage imageNamed:@"wiki2.png"];
            cell.imageView.image = image;
            
            //[menupopview setHidden:YES];
            
          
            
        }
        if (indexPath.row == 2) {
            
            UIImage *image = [UIImage imageNamed:@"pcl2.png"];
            cell.imageView.image = image;
            
            //[menupopview setHidden:YES];
            
        }

        if (indexPath.row == 3) {
            
            UIImage *image = [UIImage imageNamed:@"pco2.png"];
            cell.imageView.image = image;
            
            //[menupopview setHidden:YES];
            
            
        }
        if (indexPath.row == 4) {
            
            UIImage *image = [UIImage imageNamed:@"eths2.png"];
            cell.imageView.image = image;
            
            //[menupopview setHidden:YES];
            
        }
    }
    if (indexPath.row == 5) {
        
        UIImage *image = [UIImage imageNamed:@"ror2.png"];
        cell.imageView.image = image;
        
        //[menupopview setHidden:YES];
        
    }
    if (indexPath.row == 6) {
        
        UIImage *image = [UIImage imageNamed:@"ism2.png"];
        cell.imageView.image = image;
        
        //[menupopview setHidden:YES];
        
            
        }
    if (indexPath.row == 7) {
        
        UIImage *image = [UIImage imageNamed:@"icm2.png"];
        cell.imageView.image = image;
        
        //[menupopview setHidden:YES];
        
    }
    if (indexPath.row == 8) {
        
        UIImage *image = [UIImage imageNamed:@"lwtv2.png"];
        cell.imageView.image = image;
        
        //[menupopview setHidden:YES];
        
    }
    
    if (indexPath.row == 9) {
        
        UIImage *image = [UIImage imageNamed:@"lwsat2.png"];
        cell.imageView.image = image;
        
        //[menupopview setHidden:YES];
        
    }
    if (indexPath.row == 10) {
        
        UIImage *image = [UIImage imageNamed:@"lwplus2.png"];
        cell.imageView.image = image;
        
        //[menupopview setHidden:YES];
        
    }
if (indexPath.row == 11) {
    
    UIImage *image = [UIImage imageNamed:@"onlinestore2.png"];
    cell.imageView.image = image;
    
    //[menupopview setHidden:YES];
    
}
if (indexPath.row == 12) {
    
    UIImage *image = [UIImage imageNamed:@"ic_min_web2.png"];
    cell.imageView.image = image;
    
    //[menupopview setHidden:YES];
    
}
    if (indexPath.row == 13) {
        
        UIImage *image = [UIImage imageNamed:@"yookos2.png"];
        cell.imageView.image = image;
        
        //[menupopview setHidden:YES];

    }
    
    else if (tableView.tag ==9){
        
    
        cell.textLabel.text = [generalSettingsItems objectAtIndex:indexPath.row];
        //NSString *theDay;
        //NSString *dateString = [today stringFromDate];
        
        cell.detailTextLabel.text = [dateItems objectAtIndex:indexPath.row];
        //cell.textLabel.text.size = 40;
        cell.textLabel.font = [UIFont fontWithName:@"Trebuchet-Ms" size:40];
    }

    return cell;

}

-(IBAction)btn1:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://www.christembassy.org"]];
    
    [menupopview setHidden:YES];
}
-(IBAction)btn2:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://www.wikisozo.com"]];
    

}
-(IBAction)btn3:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://www.yookos.com/pastorchrislive"]];
}
-(IBAction)btn4:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://www.pastorchrisonline.org"]];
    
    [menupopview setHidden:YES];

}
-(IBAction)btn5:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://www.enterthehealingschool.org"]];
    
    [menupopview setHidden:YES];
}
-(IBAction)btn6:(id)sender{


    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://rhapsodyofrealities.org"]];
    
    [menupopview setHidden:YES];

}
-(IBAction)btn7:(id)sender{


    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://christembassy-ism.org"]];
    
    [menupopview setHidden:YES];
}
-(IBAction)btn8:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://www.theinnercitymission.org"]];
    
    [menupopview setHidden:YES];
    

}
-(IBAction)btn9:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://www.loveworldtv.co.uk"]];
    
    [menupopview setHidden:YES];
}
-(IBAction)btn10:(id)sender{
    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://loveworldsat.org"]];

}
-(IBAction)btn11:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://loveworldplus.org"]];
    
    [menupopview setHidden:YES];
}
-(IBAction)btn12:(id)sender{
    
    
    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                                          @"http://www.christembassyonlinestore.org"]];
}
-(IBAction)btn13:(id)sender{

    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://www.blwcampusministry.org"]];
}
-(IBAction)btn14:(id)sender{


    [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                  @"http://www.yookos.com"]];

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }

    
    if(tableView.tag == 1){
        
        
    
   // NSString *theValue = [menuarray2 objectAtIndex:indexPath.row];

        if (indexPath.row == 0) {
            
            [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                          @"http://www.christembassy.org"]];
                        
            [menupopview setHidden:YES];
            
            NSLog(@"1new");
            
        }

        
    }
    
    if (indexPath.row == 1) {
        
        [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                      @"http://www.wikisozo.com"]];

        
        [menupopview setHidden:YES];
        
        NSLog(@"2");
        
    }
    if (indexPath.row == 2) {
        
        
        [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                      @"http://www.yookos.com/pastorchrislive"]];
        
        
        
        [menupopview setHidden:YES];
        
        NSLog(@"3");
                
    }
    
    if (indexPath.row == 3) {
        
        [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                      @"http://www.pastorchrisonline.org"]];
        
        [menupopview setHidden:YES];
        
        NSLog(@"4");
        
            }
    
    
    if (indexPath.row == 4) {
        
        [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                      @"http://www.enterthehealingschool.org"]];
        
        [menupopview setHidden:YES];
        
        NSLog(@"5");
               
        
    }
    
    if (indexPath.row == 5) {
        
        [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                      @"http://rhapsodyofrealities.org"]];
                
        [menupopview setHidden:YES];
        
        NSLog(@"6");
        
    }
    
    if (indexPath.row == 6) {
        
        [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                      @"http://christembassy-ism.org"]];
        
        [menupopview setHidden:YES];
        
        NSLog(@"7");
        
        
    }
            if (indexPath.row == 7) {
                
                [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                              @"http://www.theinnercitymission.org"]];
                
                [menupopview setHidden:YES];
                
                NSLog(@"1new");
                
            }

            
            if (indexPath.row == 8) {
                
                [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                              @"http://www.loveworldtv.co.uk"]];
                
                [menupopview setHidden:YES];
                
                NSLog(@"2");
                
            }
            if (indexPath.row == 9) {
                
                [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                              @"http://loveworldsat.org"]];
                
                [menupopview setHidden:YES];
                
                NSLog(@"3");
                
            }
            
            if (indexPath.row == 10) {
                
                [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                              @"http://loveworldplus.org"]];
                
                [menupopview setHidden:YES];
                
                NSLog(@"4");
                
            }
            
            
            if (indexPath.row == 11) {
                
                [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                              @"http://www.christembassyonlinestore.org"]];
                
                //[menupopview setHidden:YES];
                
                NSLog(@"5");
                
                
            }
            
            if (indexPath.row == 12) {
                
                [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                              @"http://www.blwcampusministry.org"]];
                
                //[menupopview setHidden:YES];
                
                NSLog(@"6");
                
            }
            
            if (indexPath.row == 13) {
                
                [[ UIApplication sharedApplication ] openURL:[NSURL URLWithString:
                                                              @"http://www.yookos.com"]];
                
                //[menupopview setHidden:YES];
                
                NSLog(@"7");
                
                
                

            
        }

            else if (tableView.tag==9){
            
            
                AppDelegate *appDelegateForNotes =
                [[UIApplication sharedApplication] delegate];
                appDelegateForNotes.viewController.getNote = [generalSettingsItems objectAtIndex:indexPath.row];
                //NSLog(@"this is the table value: %@", [generalSettingsItems objectAtIndex:indexPath.row]);
                appDelegateForNotes.viewController.readNoteChecker = 2;
                
                /**CreateViewController *NoteViewController =
                [[CreateViewController alloc]
                 initWithNibName:@"CreateViewController" bundle:nil];
                
                [self.navigationController
                 pushViewController:NoteViewController animated:YES];**/
            
            }

}
    

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
