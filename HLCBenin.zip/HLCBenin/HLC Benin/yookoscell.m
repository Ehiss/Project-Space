//
//  yookoscell.m
//  LoveworldSat
//
//  Created by AKEJU on 7/15/13.
//  Copyright (c) 2013 INTERNET MULTIMEDIA. All rights reserved.
//

#import "yookoscell.h"
#import "ViewController.h"

@implementation yookoscell
@synthesize YooksTitleLabel = _YooksTitleLabel;
@synthesize YooksDateLabel= _YooksDateLabel;
@synthesize YooksdescriptionLabel= _YooksdescriptionLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
