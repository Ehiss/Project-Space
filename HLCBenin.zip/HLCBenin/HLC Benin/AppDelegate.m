//
//  AppDelegate.m
//  HLC Benin
//
//  Created by AKEJU on 1/15/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import "AppDelegate.h"

#import "ViewController.h"

@implementation AppDelegate
@synthesize viewController;
@synthesize delegate;

- (void) saveState {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *fileName = [documentsDirectory stringByAppendingPathComponent:@"lastArray.txt"];
	NSString *dateFile = [documentsDirectory stringByAppendingPathComponent:@"dateArray.txt"];
	NSString *alertItemsFile = [documentsDirectory stringByAppendingPathComponent:@"alertItems.txt"];
	NSString *alertNumberFile = [documentsDirectory stringByAppendingPathComponent:@"alertNumber.txt"];
	NSString *alertItemsFile2 = [documentsDirectory stringByAppendingPathComponent:@"alertItems2.txt"];
	NSString *alertNumberFile2 = [documentsDirectory stringByAppendingPathComponent:@"alertNumber2.txt"];
	BOOL fileCreationSuccess = [fileManager createFileAtPath:fileName contents:nil attributes:nil];
	BOOL fileCreationSuccess2 = [fileManager createFileAtPath:dateFile contents:nil attributes:nil];
	BOOL fileCreationSuccess3 = [fileManager createFileAtPath:alertItemsFile contents:nil attributes:nil];
	BOOL fileCreationSuccess4 = [fileManager createFileAtPath:alertNumberFile contents:nil attributes:nil];
	BOOL fileCreationSuccess5 = [fileManager createFileAtPath:alertItemsFile2 contents:nil attributes:nil];
	BOOL fileCreationSuccess6 = [fileManager createFileAtPath:alertNumberFile2 contents:nil attributes:nil];
	if(fileCreationSuccess == YES || fileCreationSuccess2 == YES || fileCreationSuccess3 == YES || fileCreationSuccess4 == YES || fileCreationSuccess5 == YES || fileCreationSuccess6 == YES){
		NSLog(@"Directorys %@ and %@ created successfully!", fileName, dateFile);
		[viewController.noteTitleandAuthors writeToFile:fileName atomically:YES];
		[viewController.noteDateandTime writeToFile:dateFile atomically:YES];
		[viewController.alertItem writeToFile:alertItemsFile atomically:YES];
		[viewController.alertIndexNumber writeToFile:alertNumberFile atomically:YES];
		[viewController.alertItem2 writeToFile:alertItemsFile2 atomically:YES];
		[viewController.alertIndexNumber2 writeToFile:alertNumberFile2 atomically:YES];
	}
	
	
}



- (void)startupAnimationDone:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context {
	[splashView removeFromSuperview];
	
}

- (void) onPushAccepted:(PushNotificationManager *)pushManager withNotification:(NSDictionary *)pushNotification {
    NSLog(@"Push notification received");
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound)];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/lastArray.txt"];
	NSString *dateFile = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/dateArray.txt"];
	NSString *alertItemsFile = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/alertItems.txt"];
	NSString *alertNumberFile = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/alertNumber.txt"];
	NSString *alertItemsFile2 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/alertItems2.txt"];
	NSString *alertNumberFile2 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/alertNumber2.txt"];
	
	if (![fileManager fileExistsAtPath:fileName]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:fileName contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:fileName atomically:YES];
		}
	}
	
	if (![fileManager fileExistsAtPath:dateFile]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:dateFile contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:dateFile atomically:YES];
		}
	}
	
	
	if (![fileManager fileExistsAtPath:alertItemsFile]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:alertItemsFile contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:alertItemsFile atomically:YES];
		}
	}
	
	
	if (![fileManager fileExistsAtPath:alertNumberFile]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:alertNumberFile contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:alertNumberFile atomically:YES];
		}
	}
	
	
	if (![fileManager fileExistsAtPath:alertItemsFile2]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:alertItemsFile2 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:alertItemsFile2 atomically:YES];
		}
	}
	
	
	if (![fileManager fileExistsAtPath:alertNumberFile2]) {
		BOOL fileCreationSuccess = [fileManager  createFileAtPath:alertNumberFile2 contents:nil attributes:nil];
		initialiser = [[NSMutableArray alloc] init];
		if(fileCreationSuccess == YES){
			//NSLog(@"Directory %@ created successfully!", fileName);
			[initialiser writeToFile:alertNumberFile2 atomically:YES];
		}
	}
    
    
    sleep(3);
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.viewController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
    navcon = [[UINavigationController alloc] initWithRootViewController:self.viewController];
    
    self.window.rootViewController = navcon;
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *) application {
    //[self saveState];
    
    viewController.rateChecker++ ;
    
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}
- (void)applicationWillEnterForeground:(UIApplication *)application
{
    
    [self saveState];
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    viewController.hasRated = [[NSUserDefaults standardUserDefaults] integerForKey: @"hasRatedCheck"];
    
    if(viewController.rateChecker == 1 || viewController.rateChecker == 3 || viewController.rateChecker == 5 || viewController.rateChecker == 7 || viewController.rateChecker == 9){
        
        if(viewController.hasRated != 1){
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Kindly Rate HLC App!"
                                                            message:@"We would like you to kindly rate this App on the App Store. Thank You"
                                                           delegate:viewController
                                                  cancelButtonTitle:@"Rate Later"
                                                  otherButtonTitles:@"Rate Now", nil];
            [alert show];
            //[alert release];
            
        }
    }
    
}


- (void)applicationWillTerminate:(UIApplication *)application
{
    [self saveState];
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
