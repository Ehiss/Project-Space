//
//  NotedController.m
//  HLC Benin
//
//  Created by AKEJU on 1/31/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import "NotedController.h"
#import "CreatenoteViewController.h"



@implementation NotedController


- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    //[noteArea resignFirstResponder];
    return NO;
}
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
        
        [textView resignFirstResponder];
    return YES;;
}


-(void)openNotes{
	
	ViewnoteViewController *noteViewController =
	[[ViewnoteViewController alloc]
	 initWithNibName:@"ViewnoteViewController" bundle:nil];
	
	[self.navigationController
	 pushViewController:noteViewController animated:YES];
	
	
	
}


-(void)makeNewNote{
	
	[noteContainer setHidden:NO];
	/**[mainview addSubview:takenoteview];
    [aboutview setHidden:YES];
    [regview setHidden:YES];
    [Testview setHidden:YES];
    [Expview setHidden:YES];
    [salview setHidden:YES];
    [Highview setHidden:YES];
    [scheduleview setHidden:YES];
    [contactusscroll setHidden:YES];
    [menupopview setHidden:YES];
    [estoreview setHidden:YES];
    [minsitescroll setHidden:YES];
    [takenoteview setHidden:NO];**/
    
    
	
}

-(IBAction)createNote: (id)sender{
    AppDelegate *noteDelegate = [[UIApplication sharedApplication] delegate];
	noteDelegate.viewController.theTitle = noteTitle.text ;
	noteDelegate.viewController.checker = 2;
	noteDelegate.viewController.another = 2;
	
    [noteContainer setHidden:YES];
    
	CreatenoteViewController *noteViewController2 =
	[[CreatenoteViewController alloc]
	 initWithNibName:@"CreatenoteViewController" bundle:nil];
	
	[self.navigationController
	 pushViewController:noteViewController2 animated:YES];
	
	
	[noteTitle resignFirstResponder];
    
}


-(IBAction)cancelNote: (id)sender{
	
	[noteContainer setHidden:YES];
    
	
    //[takenoteview setHidden:YES];
	
	//[self dismissViewControllerAnimated:YES completion:nil];
    
    [self.navigationController popViewControllerAnimated:YES];

	
}

- (void)viewDidLoad
{
    
    
    NSString *theTitle = @"Diary";
	
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:theTitle message:nil delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Open a Note", @"New Note", nil];
	[alert show];
	
	
	
    [super viewDidLoad];
    
    self.navigationController.navigationBarHidden = YES;
    // Do any additional setup after loading the view from its nib.
}
-(IBAction)Exit: (id)sender{[self.navigationController popViewControllerAnimated:YES];}

- (void)alertView:(UIAlertView *)alert clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        //[self dismissViewControllerAnimated:YES completion:nil];
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if (buttonIndex == 1)
    {
        [self openNotes];
    }
	else if (buttonIndex == 2)
    {
        [self makeNewNote];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	
	
    return NO;
	
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
