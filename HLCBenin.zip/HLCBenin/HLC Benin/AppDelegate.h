//
//  AppDelegate.h
//  HLC Benin
//
//  Created by AKEJU on 1/15/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "PushNotificationManager.h"

@class ViewController;

@interface AppDelegate : NSObject <UIApplicationDelegate>{

      ViewController *viewController;
    
    UIImageView *splashView;
    
    NSMutableArray *initialiser;
    
    UINavigationController *navcon;

}
- (void) saveState;
@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;
@property (retain) id delegate;

@end
