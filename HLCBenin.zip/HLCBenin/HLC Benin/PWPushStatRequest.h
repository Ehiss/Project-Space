//
//  PWPushStatRequest
//  Pushwoosh SDK
//  (c) Pushwoosh 2012
//

#import "PWRequest.h"

@interface PWPushStatRequest : PWRequest

@property (nonatomic, copy) NSString *hash;

@end
