//
//  ViewnoteViewController.h
//  HLC Benin
//
//  Created by AKEJU on 1/31/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "ViewController.h"
#import "CreatenoteViewController.h"

@interface ViewnoteViewController : UIViewController{


NSMutableArray *generalSettingsItems;
NSMutableArray *dateItems;
IBOutlet UITableView *displayTable;
IBOutlet UIButton *editButton;
//NSString *dateString;
}
-(IBAction)btnDone:(id)sender;
-(IBAction)btnEdit:(id)sender;



@end
