//
//  CreatenoteViewController.h
//  HLC Benin
//
//  Created by AKEJU on 1/31/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "ViewController.h"
#import "ViewnoteViewController.h"

@interface CreatenoteViewController : UIViewController<UITextFieldDelegate, UIAlertViewDelegate,UIPopoverControllerDelegate>{
    
    IBOutlet UITextField *noteTitle;
	IBOutlet UITextField *noteHeaderTitle;
	IBOutlet UIButton *create;
	IBOutlet UIButton *cancel;
	IBOutlet UIView *noteContainer;
	IBOutlet UILabel *noteLabel;
	IBOutlet UITextView *noteArea;
	//UIPopoverController *popoverController3 ;
    
    //IBOutlet UIButton *ShareNotePop;
    
	int noteTitlesChecker;
	NSString *filePath;
	NSString *filePathWithExtension;
    
    //NSString *deviceOS;
	
    
}

//@property (nonatomic, retain)  UIPopoverController *popoverController3 ;

-(IBAction)createNote: (id)sender;
-(IBAction)cancelNote: (id)sender;
-(IBAction)viewNote: (id)sender;
-(IBAction)createNewNote: (id)sender;
-(IBAction)done: (id)sender;




@end
