//
//  ViewController.h
//  HLC Benin
//
//  Created by AKEJU on 1/15/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <MessageUI/MessageUI.h>
#import <MediaPlayer/MediaPlayer.h>


@interface ViewController : UIViewController<UIPopoverControllerDelegate,UIWebViewDelegate,UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,UIScrollViewDelegate,MFMailComposeViewControllerDelegate,UITextFieldDelegate,UITextViewDelegate,UITableViewDataSource>{

   
    
    
    
   
	int noteTitlesChecker;
	NSString *filePath;
	NSString *filePathWithExtension;
    
    
    IBOutlet UIView *Createnoteview;
    NSString *alertString;
    NSMutableArray *alertItem;
	NSMutableArray *alertIndexNumber;
	NSMutableArray *alertItem2;
	NSMutableArray *alertIndexNumber2;
    
    
    
    NSMutableArray *generalSettingsItems;
    NSMutableArray *dateItems;
    IBOutlet UITableView *displayTable;
    IBOutlet UIButton *editButton;
    
    //IBOutlet UITextField *noteTitle;
    
    //IBOutlet UIView *noteContainer;



    
    IBOutlet UIView* thePlayerView ;
    
    MPMoviePlayerController *moviePlayer ;
    
    
    AppDelegate *theDelegate;
    
    IBOutlet UIActivityIndicatorView *aboutactivity;
    
    IBOutlet UIView *estoreview;
    IBOutlet UIWebView *estorewebview;
    IBOutlet UIActivityIndicatorView *estoreactivity;
    
    IBOutlet UIView *scheduleview;
    IBOutlet UIWebView *schedulewebview;
    
    IBOutlet UIView *regview;
    IBOutlet UIView *salview;
    IBOutlet UIView *aboutview;
    
    
    IBOutlet UIView *Expview;
    IBOutlet UIView *Testview;
    IBOutlet UIView *Highview;
    
    IBOutlet UIWebView *Expwebview;
    IBOutlet UIWebView *Testwebview;
    IBOutlet UIWebView *Highwebview;

    
    IBOutlet UIWebView *regwebview;
    IBOutlet UIWebView *salwebview;
    IBOutlet UIWebView *aboutwebview;
    
    IBOutlet UITableView *ministrysitestableview;
    IBOutlet UITableView *menutableview;
    NSArray *menuarray1;
    NSArray *ministryimages;
    
    
  
    NSMutableArray *ministrysitesarray;
    
    
    IBOutlet UIScrollView *Menuscrollview;
    IBOutlet UIView *mainview;
    UIPopoverController *popoverController;
   // IBOutlet UIButton* MenuPopUpButton;
    
    IBOutlet UIView *menupopview;
    
    IBOutlet UIScrollView *previouseventscroll;
    IBOutlet UIScrollView *contactusscroll;
    
    IBOutlet UIScrollView *Hotelscrollview;
    IBOutlet UIView *contactusview;
    
    IBOutlet UIView *ministryview;
    
    IBOutlet UIView *takenoteview;
    
    IBOutlet UIView *shareappview;
    
    int rateChecker;
    
    IBOutlet UIScrollView *hlcusaview;
    IBOutlet UIScrollView *hlcukview;
    IBOutlet UIScrollView *hlccanadaview;
    IBOutlet UIScrollView *hlclagosview;
    
    
    IBOutlet UIView* thePlayerView2 ;
    IBOutlet UIView* thePlayerView3 ;
    IBOutlet UIView* thePlayerView4 ;
    
    int another;
    int checker;
    
    IBOutlet UIButton* abtoutletbtn;
    IBOutlet UIButton* regoutletbtn;
    IBOutlet UIButton* schoutletbtn;
    
    IBOutlet UIButton* inviteoutletbtn;
    IBOutlet UIButton* testoutletbtn;
    
    IBOutlet UIButton* expectoutletbtn;
    IBOutlet UIButton* Highoutletbtn;
    
    IBOutlet UIButton* saloutletbtn;
    IBOutlet UIButton* taknoteoutletbtn;
    IBOutlet UIButton* reportoutletbtn;
    int hasRated;
    
   NSString *theTitle;
    
    
     IBOutlet UIScrollView *minsitescroll;
    
    IBOutlet UIView *viewnoteview;
    NSString *deviceOSVersion;
    
    NSMutableArray *noteDateandTime;
    NSMutableArray *noteTitleandAuthors;
    
    int readNoteChecker;
    NSString *getNote;
    
    
    IBOutlet UIView *reportsview;
    IBOutlet UIWebView *reportswebview;
    IBOutlet UITableView *yookosFeedView;
    IBOutlet UIView *yookosview;
    IBOutlet UIWebView *yookoswebview;
}
//notes


-(IBAction)hlcreport:(id)sender;



@property int readNoteChecker;
@property (nonatomic, retain) NSString *getNote;
@property (nonatomic, retain) NSMutableArray *noteDateandTime;
@property (nonatomic, retain) NSMutableArray *noteTitleandAuthors;



@property (nonatomic, retain) NSString *theTitle;
@property int checker;
@property int another;




@property (nonatomic, retain) NSString *alertString;
@property (nonatomic, retain) NSMutableArray *alertItem;
@property (nonatomic, retain) NSMutableArray *alertIndexNumber;
@property (nonatomic, retain) NSMutableArray *alertItem2;
@property (nonatomic, retain) NSMutableArray *alertIndexNumber2;

-(IBAction)btn1:(id)sender;
-(IBAction)btn2:(id)sender;
-(IBAction)btn3:(id)sender;
-(IBAction)btn4:(id)sender;
-(IBAction)btn5:(id)sender;
-(IBAction)btn6:(id)sender;
-(IBAction)btn7:(id)sender;
-(IBAction)btn8:(id)sender;
-(IBAction)btn9:(id)sender;
-(IBAction)btn10:(id)sender;
-(IBAction)btn11:(id)sender;
-(IBAction)btn12:(id)sender;
-(IBAction)btn13:(id)sender;
-(IBAction)btn14:(id)sender;






-(IBAction)website:(id)sender;
@property int rateChecker;
@property int hasRated;

-(IBAction)mail:(id)sender;

-(IBAction)sendMail:(id)sender;
-(IBAction)postToFacebook:(id)sender;
-(IBAction)postToTwitter:(id)sender;


-(IBAction)takenote:(id)sender;

-(IBAction)invitefriends:(id)sender;

-(void)performActionMenu:(NSString*)Menuevents;


//-(void)reloadmenuview;




//-(void)performActionMenu:(NSString*)Menuevents;

-(IBAction)Menupop:(id)sender;

@property (nonatomic, retain)  UIPopoverController *popoverController;

-(IBAction)button1:(id)sender;

-(IBAction)aboutbtn:(id)sender;

-(IBAction)regbtn:(id)sender;

-(IBAction)schedulebtn:(id)sender;

-(IBAction)expectbtn:(id)sender;

-(IBAction)salvationebtn:(id)sender;
-(IBAction)testimbtn:(id)sender;

-(IBAction)highlightbtn:(id)sender;

-(IBAction)HLCusabtn:(id)sender;

-(IBAction)HLClagosbtn:(id)sender;
-(IBAction)HLCukbtn:(id)sender;

-(IBAction)HLCcanadabtn:(id)sender;


-(IBAction)backtoprevbtn:(id)sender;
-(IBAction)backtoprevbtn2:(id)sender;
-(IBAction)backtoprevbtn3:(id)sender;
-(IBAction)backtoprevbtn4:(id)sender;




@end
