//
//  yookoscell.h
//  LoveworldSat
//
//  Created by AKEJU on 7/15/13.
//  Copyright (c) 2013 INTERNET MULTIMEDIA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface yookoscell : UITableViewCell{

IBOutlet UILabel *faith;
}


@property (nonatomic, weak) IBOutlet UILabel *YooksTitleLabel;
@property (nonatomic, weak) IBOutlet UILabel *YooksdescriptionLabel;
@property (nonatomic, weak) IBOutlet UILabel *YooksDateLabel;


@end
