//
//  CreatenoteViewController.m
//  HLC Benin
//
//  Created by AKEJU on 1/31/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import "CreatenoteViewController.h"

@implementation CreatenoteViewController

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    //[noteArea resignFirstResponder];
    return NO;
}
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
        
        [textView resignFirstResponder];
    return YES;;
}


-(IBAction)createNote: (id)sender{
	
	NSDate *today = [NSDate date];
	NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init] ;
	[dateFormatter setTimeStyle:NSDateFormatterMediumStyle];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
	NSString *dateString = [dateFormatter stringFromDate:today];
	
	
	AppDelegate *noteDelegate3 = [[UIApplication sharedApplication] delegate];
	
	
	filePath = [@"Documents/" stringByAppendingString:[noteLabel text]];
	filePathWithExtension = [filePath stringByAppendingString:@".txt"];
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:filePathWithExtension];
	NSData *data = [[noteArea text]
					dataUsingEncoding:NSASCIIStringEncoding];
	if(noteDelegate3.viewController.another == 2 || noteTitlesChecker == 2){
		BOOL fileCreationSuccess = [fileManager createFileAtPath:fileName contents:nil attributes:nil];
		if(fileCreationSuccess == YES){
			NSLog(@"%@ was successfully created", fileName);
		}
		noteDelegate3.viewController.another = 1;
		//noteTitlesChecker = 1;
	}
	[data writeToFile:fileName atomically:YES];
	if(noteDelegate3.viewController.checker == 2 || noteTitlesChecker == 2){
		[noteDelegate3.viewController.noteTitleandAuthors addObject:[noteLabel text]];
		[noteDelegate3.viewController.noteDateandTime addObject:dateString];
		noteDelegate3.viewController.checker = 1;
		
	}
	
	
	
	[noteHeaderTitle resignFirstResponder];
	
	
	noteTitlesChecker = 1;
	
	
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:
                                                             @"%@, Saved Successfully", noteLabel.text] message:nil delegate:nil cancelButtonTitle:
						  @"Continue" otherButtonTitles:nil];
	[alert show];
	
	
	
	
	
	[noteArea setText:@""];
	[noteTitle resignFirstResponder];
	[noteContainer setHidden:YES];
	
	[noteLabel setText:noteTitle.text];
	[noteHeaderTitle setText:noteTitle.text];
	
	noteDelegate3.viewController.another = 2;
	noteDelegate3.viewController.checker = 2;
	
	
	
}


-(IBAction)cancelNote: (id)sender{
	
	[noteContainer setHidden:YES];
	
	
}


-(IBAction)viewNote: (id)sender{
	ViewnoteViewController *noteViewController =
	[[ViewnoteViewController alloc]
	 initWithNibName:@"ViewnoteViewController" bundle:nil];
	
	[self.navigationController
	 pushViewController:noteViewController animated:YES];
	
	//[noteViewController ]
    
    //[noteViewController hidenote];
}


-(IBAction)createNewNote: (id)sender{
	[noteContainer setHidden:NO];
	
}


-(IBAction)done: (id)sender;{
	NSDate *today = [NSDate date];
	NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setTimeStyle:NSDateFormatterMediumStyle];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
	NSString *dateString = [dateFormatter stringFromDate:today];
	
	
	AppDelegate *noteDelegate3 = [[UIApplication sharedApplication] delegate];
	
	
	filePath = [@"Documents/" stringByAppendingString:[noteLabel text]];
	filePathWithExtension = [filePath stringByAppendingString:@".txt"];
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:filePathWithExtension];
	NSData *data = [[noteArea text]
					dataUsingEncoding:NSASCIIStringEncoding];
	if(noteDelegate3.viewController.another == 2 || noteTitlesChecker == 2){
		BOOL fileCreationSuccess = [fileManager createFileAtPath:fileName contents:nil attributes:nil];
		if(fileCreationSuccess == YES){
			NSLog(@"%@ was successfully created", fileName);
		}
		noteDelegate3.viewController.another = 1;
		//noteTitlesChecker = 1;
	}
	[data writeToFile:fileName atomically:YES];
	if(noteDelegate3.viewController.checker == 2 || noteTitlesChecker == 2){
		
		[noteDelegate3.viewController.noteTitleandAuthors addObject:[noteLabel text]];
		[noteDelegate3.viewController.noteDateandTime addObject:dateString];
		
		
		noteDelegate3.viewController.checker = 1;
		
	}
	
	
	
	[noteHeaderTitle resignFirstResponder];
	
	
	noteTitlesChecker = 1;
	
	
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:
                                                             @"%@, Saved Successfully", noteLabel.text] message:nil delegate:self cancelButtonTitle:@"Continue" otherButtonTitles:@"Exit", nil];
	[alert show];
	
	
	
    
	
}


-(void)alertView:(UIAlertView *)alert clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        
    }
    else if (buttonIndex == 1)
    {
		[noteArea setText:@""];
        [self dismissViewControllerAnimated:YES completion:nil];
        
        [self.navigationController popViewControllerAnimated:YES];
		
    }
}



-(void)textFieldDidEndEditing:(UITextField*)textField{
	
	AppDelegate *noteDelegate4 = [[UIApplication sharedApplication] delegate];
	noteTitlesChecker = 2;
	
	filePath = [@"Documents/" stringByAppendingString:[noteLabel text]];
	filePathWithExtension = [filePath stringByAppendingString:@".txt"];
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSString *fileName = [NSHomeDirectory() stringByAppendingPathComponent:filePathWithExtension];
	
	BOOL fileCreationSuccess = [fileManager removeItemAtPath:fileName error:nil];
	if(fileCreationSuccess == YES){
		[noteDelegate4.viewController.noteTitleandAuthors removeObject:[noteLabel text]];
	}
	//[notesLabel setText:[noteTitles text]];
	[noteLabel setText:noteHeaderTitle.text];
	
    // [noteDelegate4 release];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	
	
    return NO;
	
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
    //deviceOS = [[NSUserDefaults standardUserDefaults] valueForKey:@"ddeviceosversion"];
    
	AppDelegate *noteDelegate2 = [[UIApplication sharedApplication] delegate];
	
	if (noteDelegate2.viewController.readNoteChecker == 2) {
		[noteLabel setText:noteDelegate2.viewController.getNote];
		[noteHeaderTitle setText:noteDelegate2.viewController.getNote];
		
		filePath = [@"Documents/" stringByAppendingString:noteDelegate2.viewController.getNote];
		filePathWithExtension = [filePath stringByAppendingString:@".txt"];
		
		NSFileManager *fileManager = [NSFileManager defaultManager];
		NSData *data;
		//NSString *dataValue;
		NSString *fileName =
		[NSHomeDirectory() stringByAppendingPathComponent:filePathWithExtension];
		data = [fileManager contentsAtPath:fileName];
		NSString* aStr;
		aStr = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
		
		[noteArea setText:aStr];
		noteDelegate2.viewController.readNoteChecker = 1;
		noteDelegate2.viewController.getNote = nil;
        
        
        
		
	}
	
	else{
        NSString *ourLabel = noteDelegate2.viewController.theTitle ;
        [noteLabel setText:ourLabel];
        [noteHeaderTitle setText:ourLabel];
        [noteArea setText:@""];
		
	}


}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
