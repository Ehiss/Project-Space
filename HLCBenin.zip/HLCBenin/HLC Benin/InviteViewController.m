//
//  InviteViewController.m
//  HLC Benin
//
//  Created by AKEJU on 1/22/14.
//  Copyright (c) 2014 INTERNET MULTIMEDIA. All rights reserved.
//

#import "InviteViewController.h"

#import "ViewController.h"



@implementation InviteViewController

-(IBAction)btnsendMail:(id)sender{
	
	[emailLabel resignFirstResponder];
	
	
	if ([MFMailComposeViewController canSendMail])
    {
        // NSArray *theAddress = [emailLabel.text componentsSeparatedByString:@","];
        
		MFMailComposeViewController *mailer = [[MFMailComposeViewController alloc] init];
		
        mailer.mailComposeDelegate = self;
		
        [mailer setSubject:@"An Invitation To The Higher Life Conference,Benin-City."];
		
        //NSArray *toRecipients = [NSArray arrayWithObjects:[NSString stringWithFormat:@"%@", emailLabel.text], nil];
        NSArray *toRecipients = [emailLabel.text componentsSeparatedByString:@","];
        
        [mailer setToRecipients:toRecipients];
		
		
        NSString *emailBody = [NSString stringWithFormat:@"Hello, Warm Greetings. \n\n%@ is inviting you to the Higher Life Conference,Benin-Ciy,Nigeria on 7th to 9th of February, 2014. For details on how to attend, http://higherlifeconferencebenincity.org/ or download the HLC Benin-City iPhone application here: http://bit.ly/hlcbenincitymobileapp \n\n Thank You.", nameLabel.text];
        [mailer setMessageBody:emailBody isHTML:NO];
		
		mailer.modalPresentationStyle = UIModalPresentationPageSheet;
        //[self presentModalViewController:mailer animated:YES];
        
        [self presentViewController:mailer animated:YES completion:nil];
        
        
        /**[friendsnameLabel setText:@""];
         [nameLabel setText:@""];
         [emailLabel setText:@""];**/
		
		
        //[mailer release];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Failure"
                                                        message:@"Your device does not support mail sending"
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        //[alert release];
        
        [friendsnameLabel setText:@""];
        [nameLabel setText:@""];
        [emailLabel setText:@""];
    }
	
	
}



- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
	
	switch (result)
    {
        case MFMailComposeResultCancelled:{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Mail Cancelled:"
															message:@"You cancelled the operation, so no email message was queued or sent Thank You."
														   delegate:nil
												  cancelButtonTitle:@"OK"
												  otherButtonTitles:nil];
			[alert show];
			//[alert release];
		}
            break;
        case MFMailComposeResultSaved:{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Mail Saved:"
															message:@"Your message has been saved to your drafts folder. Thank You"
														   delegate:nil
												  cancelButtonTitle:@"OK"
												  otherButtonTitles:nil];
			[alert show];
			//[alert release];
		}
			
            break;
        case MFMailComposeResultSent:{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Thank You!"
															message:@"Your message has been sent successfully."
														   delegate:nil
												  cancelButtonTitle:@"OK"
												  otherButtonTitles:nil];
			[alert show];
			//[alert release];
		}
            break;
        case MFMailComposeResultFailed:{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Mail Failed:"
															message:@"Your email message was not saved or queued, possibly due to an error. Please try again. Thank You"
														   delegate:nil
												  cancelButtonTitle:@"OK"
												  otherButtonTitles:nil];
			[alert show];
			//[alert release];
		}
			
            break;
        default:
            NSLog(@"Mail not sent.");
            break;
    }
	
	
	
	[self dismissViewControllerAnimated:YES completion:nil];
	
	/**UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Thank You For Contacting Flaires!"
     message:@"Your message has been sent successfully."
     delegate:nil
     cancelButtonTitle:@"OK"
     otherButtonTitles:nil];
     [alert show];
     [alert release];**/
}


-(IBAction)btnDone:(id)sender{
	
	//[self dismissModalViewControllerAnimated:YES];
	[self dismissViewControllerAnimated:YES completion:nil];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    
	[textfield2 resignFirstResponder];
    [textfield3 resignFirstResponder];

}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField == textfield2) {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.5];
        [UIView setAnimationBeginsFromCurrentState:YES];
        textfield2.frame = CGRectMake(textfield2.frame.origin.x, (textfield2.frame.origin.y - 125.0), textfield2.frame.size.width, textfield2.frame.size.height);
        [UIView commitAnimations];
        
        
        
    }
    else if (textField == textfield3){
    
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDuration:0.5];
        [UIView setAnimationBeginsFromCurrentState:YES];
        textfield3.frame = CGRectMake(textfield3.frame.origin.x, (textfield3.frame.origin.y - 80.0), textfield3.frame.size.width, textfield3.frame.size.height);
        [UIView commitAnimations];

    
    }
}
- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField == textfield2) {
		[UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDuration:0.5];
		[UIView setAnimationBeginsFromCurrentState:YES];
		textfield2.frame = CGRectMake(textfield2.frame.origin.x, (textfield2.frame.origin.y + 125.0), textfield2.frame.size.width, textfield2.frame.size.height);
		[UIView commitAnimations];
	}
    
    else if (textField==textfield3){
    
        [UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDuration:0.5];
		[UIView setAnimationBeginsFromCurrentState:YES];
		textfield3.frame = CGRectMake(textfield3.frame.origin.x, (textfield3.frame.origin.y + 80.0), textfield3.frame.size.width, textfield3.frame.size.height);
		[UIView commitAnimations];
    
    }
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    
    return NO;
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{

        
    self.navigationController.navigationBarHidden = YES;
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
